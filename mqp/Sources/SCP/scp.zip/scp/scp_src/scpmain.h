/*>>> scpmain.h: ANSI prototypes for file scpmain.c */

/* Revised: 1993.03.14 */

int main(int argc, charptrT argv[]);

/*<<< scpmain.h: EOF */
