/*>>> scpmain.c: main file for the John Stanback chessplaying program */

/* Revised: 1993.03.15 */

/*

This chessplaying program was originally written by John Stanback at
Hewlett Packard.  This copy was last revised by him on 1987.03.10; it
has changed somewhat over the years.  This program served as the basis
for the GNUChess program.

The source later appeared in several places.  This copy is based on a
version from an early Fish Disk, a set of PD software for the Commodore
Amiga.  A number of people were involved with various modifications, but
it is uncertain exactly who contributed what; most later work dealt with
interface issues rather than chess playing.

The source from the Amiga version later appeared as part of the PD
collection loosely supported by the Mark Williams Company, the authors
of the Coherent (Unix clone) operating system.  This in turn was ported
by Steven Edwards to produce an ANSI C version.  The main motivation for
this work was to provide a vehicle for demonstration and experimentation
for the SAN Kit chess programming project.

The SAN Kit project, started by Edwards, is an effort designed to assist
chess programmers with a uniform ANSI C development platform for various
projects.  The assistance is intended to cover several areas by
providing code for universal, unambiguous, ASCII notation for: 1) SAN
(Standard Algebraic Notation), for chess moves; 2) PGN (Portable Game
Notation), for chess game recording and archiving; 3) FEN
(Forsyth-Edwards Notation), for storage of chess position data; and 4)
IPCC (Inter Process Chess Communication), for dynamic control of
networked chess software.  The assistance takes the form of complete, PD
ASNI C source and testing data sets.  This chess program by Stanback has
been ported to be part of the SAN Kit package as an example of
integrating a chessplaying program into the command processor that is
also included in the SAN Kit.

The SAN Kit can be found at various ftp sites and was last spotted as
the file SAN.tar.Z at valkyries.andrew.cmu.edu somewhere in the
/pub/chess directory.  This included chess program, once named "CHESS",
has been renamed "scp" (Stanback Chess Program) and all of the source
file names have the three letter sequence "scp" as a suffix.

Of course, as with all of the SAN Kit source, this program is being
distributed on an "as is" basis with no warranty whatsoever.  Neither
the original author, nor any later contributor take any responsibility
for its use.  We've tried hard, but let the user beware.

*/

/*

This port also included some minor reformatting.  As with the SAN Kit
ANSI C code, the following goals were used for the source files:

1) Full and strict ANSI C checking.

2) Uniform tabulation every four columns, useful for complex C programs.

3) Reasonable maximum line length less than eighty characters.

4) No spaces or tabs immediately prior to a newline character.

5) No spaces immediately prior to a tab character.

6) Maximum of one statement per line.

7) Statement indentation, one additional tab character per level.

8) Vertical alignment of brace pair members.

9) Exactly one return statement per function.

10) Each return statement always appears at bottom of its function.

11) No "goto" statements.

12) No "continue" statements.

13) No "break" statements outside of case bodies.

14) Exactly one "break" statement at the end of each case body.

15) Every "switch" statement has a default case body as the last body.

16) Avoidance of implicit typing for function formal parameters.

17) Avoidance of implicit typing for function return values.

18) For each ".c" file, prototypes appear in a separate ".h" file.

19) Each function starts with an easily located stylized format.

20) Function name scope explicity declared in all cases.

21) No empty control subparts in "for" statements.

22) Long expression lines break after an operator and before an operand.

23) Relational expressions are parethesized if used with "&&" or "||".

24) Arithmetic expressions are parethesized if used with "&&" or "||".

25) File scope variables are all declared with "static" attribute.

26) Native types are covered with typedef constructs for portability.

27) "struct" and "union" declarations are covered inside of typedefs.

28) Preprocessor constant length/limit names all end with "L".

29) Preprocessor constant shift width names all end with "W".

30) Preprocessor constant bitfield mask names all end with "M".

31) Preprocessor constant base two log names all end with "Q".

32) Struct names all end with "S".

33) Union names all end with "U".

34) Typedef names all end with "T".

35) Pointer typedef names all end with "ptrT".

36) Avoidance of host/target machine hardware idiosycratic behavior.

37) Avoidance of host/target machine software idiosycratic behavior.

As stated above, the listed criteria are goals and so it may be the case
that some further work could be done to make a more standard and a more
easily understood program.

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include <sys/time.h>  
#include <unistd.h>

#include "scpdefs.h"

#include "scpmain.h"

/* Note: tabs are set at every four columns */

/**** Local items */

/* SAN Kit integration indicator */

double time_splits[100000];
double time_evals[100000];
int count_time_split = 0;
int count_time_eval = 0;

#define SAN_Kit 0

/* file names for opening books, list file, and save file */

static charptrT fn_opn = "scp.opn";
static charptrT fn_aux = "scp.aux";
static charptrT fn_lst = "scp.lst";
static charptrT fn_sav = "scp.sav";

static char mvstr1[algnotL], mvstr2[algnotL];

static leafT Tree[treeL];
static leafptrT root;

static siT TrPnt[plyL];

static rankT rankv[sqL];
static fileT filev[sqL];
static sqT sqv[rankL][fileL];

static siT Index[sqL];

static cpevT svalue[sqL];
static cpevT mtl[sidesL], pmtl[sidesL], emtl[sidesL];

static sqT PieceList[sidesL][pmaxL];
static siT PieceCnt[sidesL];
static siT castld[sidesL], kingmoved[sidesL];
static siT hung[sidesL];

static siT mate, post, xkillr, ykillr, opponent, computer, Sdepth;

static secT time0, response_time, extra_time, timeout, et, et0;

static siT quit, reverse, bothsides, InChk, player;
static liT NodeCnt, srate;

static sqT atak[sidesL][sqL];

static siT PawnCnt[sidesL][fileL];

static cpevT PPscore[plyL];

static siT ChkFlag[plyL], CptrFlag[plyL], PawnThreat[plyL];

static siT BookSize, BookDepth;
static usiT Book[bklinesL][bkdepthL];

static sqT epsq;

static siT GameCnt, Game50;
static usiT GameList[gameL];
static siT GameScore[gameL], GamePc[gameL], GameClr[gameL];

static char cx[] = " wb";
static char px[] = " PNBRQK";
static char qx[] = " pnbrqk";
static char rx[] = "12345678";
static char fx[] = "abcdefgh";

static siT otherside[sidesL] = {neutral, black, white};

static cpevT value[piecesL] = {0, 100, 330, 330, 500, 950, 999};

static cpevT passed_pawn1[rankL] = {0, 3, 4, 8, 14, 24, 40, 80};
static cpevT passed_pawn2[rankL] = {0, 2, 3, 4,  6,  9, 13, 80};
static cpevT passed_pawn3[rankL] = {0, 1, 2, 3,  4,  5,  6, 80};

static xsqT map[sqL];
static sqT unmap[xsqL];

static siT edge[sqL] =
	{
	0, 1, 2, 3, 3, 2, 1, 0,
	1, 2, 3, 4, 4, 3, 2, 1,
	2, 3, 4, 5, 5, 4, 3, 2,
	3, 4, 5, 6, 6, 5, 4, 3,
	3, 4, 5, 6, 6, 5, 4, 3,
	2, 3, 4, 5, 5, 4, 3, 2,
	1, 2, 3, 4, 4, 3, 2, 1,
	0, 1, 2, 3, 3, 2, 1, 0
	};

static cpevT pknight[sqL] =
	{
	 0,  6, 11, 14, 14, 11,  6,  0,
	 6, 12, 22, 25, 25, 22, 12,  6,
	11, 20, 30, 36, 36, 30, 20, 11,
	14, 25, 36, 44, 44, 36, 25, 14,
	14, 25, 36, 44, 44, 36, 25, 14,
	11, 20, 30, 36, 36, 30, 20, 11,
	 6, 12, 22, 25, 25, 22, 12,  6,
	 0,  6, 11, 14, 14, 11,  6,  0
	};

static cpevT pbishop[sqL] =
	{
	14, 14, 14, 14, 14, 14, 14, 14,
	14, 18, 18, 18, 18, 18, 18, 14,
	14, 18, 22, 22, 22, 22, 18, 14,
	14, 18, 22, 22, 22, 22, 18, 14,
	14, 18, 22, 22, 22, 22, 18, 14,
	14, 18, 22, 22, 22, 22, 18, 14,
	14, 18, 18, 18, 18, 18, 18, 14,
	14, 14, 14, 14, 14, 14, 14, 14
	};

static siT board[sqL];
static siT color[sqL];

static siT sweep[piecesL] = {0, 0, 0, 1, 1, 1, 0};
static siT Dstpwn[sidesL] = {0, 4, 6};
static siT Dstart[piecesL] = {6, 4, 8, 4, 0, 0, 0};
static siT Dstop[piecesL] = {7, 5, 15, 7, 3, 7, 7};

static siT Dir[pmaxL] =
	{
	  1,  12,  -1, -12,  11,  13, -11, -13,
	 10, -10,  14, -14,  23, -23,  25, -25
	};

static usiT PV, Swag1, Swag2;
static usiT killr1[plyL], killr2[plyL], killr3[plyL], Qkillr[plyL];
static usiT Ckillr[sidesL], prvar[plyL];

static siT prc_cand, prc_iter, prc_pvar, prc_time;

/**** forward declaration(s) */

static
void
Search(siT side, siT ply, siT depth, siT alpha, siT beta, usiptrT bstline);

/*--> ReadLine: read a line */
static
void
ReadLine(charptrT prompt, charptrT p)
{
	int a;
	double mins = 6000;
	double maxs = -6000;
	double aves = 0;
	double mine = 6000;
	double maxe = -6000;
	double avee = 0;

	for (a=0; a < count_time_split; a++) {		
		if (time_splits[a] < mins) mins = time_splits[a];
		if (time_splits[a] > maxs) maxs = time_splits[a];
		aves = aves + time_splits[a];
	}
	aves = aves / count_time_split;
	count_time_split = 0;	
	
	for (a=0; a < count_time_eval; a++) {		
			if (time_evals[a] < mine) mine = time_evals[a];
			if (time_evals[a] > maxe) maxe = time_evals[a];
			avee = avee + time_evals[a];
		}
	avee = avee / count_time_eval;
	count_time_eval = 0;	
	
	printf("%f - %f : %f | %f - %f : %f \n\n", mins, maxs, aves, mine, maxe, avee);

	printf("%s", prompt);
	gets(p);


return;
}

/*--> PrintBoard: print the board */
static
void
PrintBoard(void)
{
rankT rank;
fileT file;
sqT sq;

for (rank = rank_8; rank >= rank_1; rank--)
	{
	for (file = file_a; file <= file_h; file++)
		{
		sq = MapRankFile(rank, file);
		switch (color[sq])
			{
			case neutral:
				if ((rank % 2) == (file % 2))
					putchar(' ');
				else
					putchar(':');
				break;

			case white:
			case black:
				putchar(cx[color[sq]]);
				break;

			default:
				putchar('?');
				break;
			};

		switch (board[sq])
			{
			case vacant:
				if ((rank % 2) == (file % 2))
					putchar(' ');
				else
					putchar(':');
				break;

			case pawn:
			case knight:
			case bishop:
			case rook:
			case queen:
			case king:
				putchar(px[board[sq]]);
				break;

			default:
				putchar('?');
				break;
			};
		};
	putchar('\n');
	};

return;
}

/*--> ElapsedTime: set elapsed time */
static
void
ElapsedTime(siT iop)
{
liT minute, second;

et = time(NULL) - time0;
if (et < et0)
	et0 = 0;

if ((et > et0) || (iop == 1))
	{
	if (et > (response_time + extra_time))
		timeout = 1;

	et0 = et;

	if (iop == 1)
		{
		et0 = 0;
		time0 = time(NULL);
		};

	minute = et / 60;
	second = et - (60 * minute);
	if (prc_time)
		printf("%3ld:%02ld\n", minute, second);

	if (et > 0)
		srate = NodeCnt / et;
	else
		srate = 0;

	if (prc_time)
		if (post)
			printf("Nodes/Sec: %ld\n", srate);
	};

return;
}

/*--> SetSquare: set a square with a value */
static
void
SetSquare(sqT sq, siT c, siT p)
{
color[sq] = c;
board[sq] = p;

return;
}

/*--> ResetPosition: reset the position to be the initial position */
static
void
ResetPosition(void)
{
sqT sq;
fileT file;

/* clear */

for (sq = sq_a1; sq <= sq_h8; sq++)
	SetSquare(sq, vacant, vacant);

/* pieces */

SetSquare(sq_a1, white, rook);
SetSquare(sq_b1, white, knight);
SetSquare(sq_c1, white, bishop);
SetSquare(sq_d1, white, queen);
SetSquare(sq_e1, white, king);
SetSquare(sq_f1, white, bishop);
SetSquare(sq_g1, white, knight);
SetSquare(sq_h1, white, rook);

SetSquare(sq_a8, black, rook);
SetSquare(sq_b8, black, knight);
SetSquare(sq_c8, black, bishop);
SetSquare(sq_d8, black, queen);
SetSquare(sq_e8, black, king);
SetSquare(sq_f8, black, bishop);
SetSquare(sq_g8, black, knight);
SetSquare(sq_h8, black, rook);

/* pawns */

for (file = file_a; file <= file_h; file++)
	{
	SetSquare(MapRankFile(rank_2, file), white, pawn);
	SetSquare(MapRankFile(rank_7, file), black, pawn);
	};

return;
}

/*--> InitializeStats: initialize statistics */
static
void
InitializeStats(void)
{
fileT file;
sqT sq;

time0 = time(NULL);

for (file = file_a; file <= file_h; file++)
	PawnCnt[white][file] = PawnCnt[black][file] = 0;

mtl[white] = mtl[black] = pmtl[white] = pmtl[black] = 0;
PieceCnt[white] = PieceCnt[black] = 0;

for (sq = sq_a1; sq <= sq_h8; sq++)
	if (color[sq] != neutral)
		{
		mtl[color[sq]] += value[board[sq]];

		if (board[sq] == pawn)
			{
			pmtl[color[sq]] += value[pawn];
			PawnCnt[color[sq]][filev[sq]]++;
			};

		if (board[sq] == king)
			Index[sq] = 0;
		else
			Index[sq] = ++PieceCnt[color[sq]];

		PieceList[color[sq]][Index[sq]] = sq;
		};

return;
}

/*--> Parse: parse opening book fragment */
static
void
Parse(charptrT s, usiptrT m)
{
rankT r1, r2;
fileT f1, f2;

if (s[4] == 'o')
	*m = byteM;
else
	if (s[0] == 'o')
		*m = 0xff00;
	else
		{
		f1 = s[0] - 'a';
		r1 = s[1] - '1';
		f2 = s[2] - 'a';
		r2 = s[3] - '1';
		*m = (sqv[r1][f1] << byteW) + sqv[r2][f2];
		};

return;
}

/*--> LoadOpenings: load the opening book */
static
void
LoadOpenings(void)
{
FILE *fp;
int c, j;
char s[bklinesL];
charptrT p;

if (((fp = fopen(fn_opn, "r")) == NULL) &&
	((fp = fopen(fn_aux, "r")) == NULL))
	{
	fprintf(stderr, "Can't open opening book file: %s\n", fn_opn);
	exit(1);
	};

BookSize = 0;
BookDepth = bkdepthL;
j = -1;
c = '?';
while (c != EOF)
	{
	p = s;

	while ((c=getc(fp)) != EOF)
		if (c == '\n')
			break;
		else
			*(p++) = c;

	*p = '\0';

	if (c != EOF)
		if (s[0] == '!')
			{
			while (j < BookDepth)
				Book[BookSize][j++] = 0;
			BookSize++;
			j = -1;
			}
		else
			if (j < 0)
				j++;
			else
				{
				Parse(&s[0], &Book[BookSize][j++]);
				Parse(&s[6], &Book[BookSize][j++]);
				};
	};

fclose(fp);

return;
}

/*--> NewGame: set up for a new game */
static
void
NewGame(void)
{
sqT sq;
rankT rank;
fileT file;

ResetPosition();
mate = quit = reverse = bothsides = post = 0;
epsq = sq_nil;
NodeCnt = xkillr = 0;
GameCnt = Game50 = -1;
castld[white] = castld[black] = 0;
kingmoved[white] = kingmoved[black] = 0;
opponent = white;
computer = black;

for (rank = rank_1; rank <= rank_8; rank++)
	for (file = file_a; file <= file_h; file++)
		{
		sq = MapRankFile(rank, file);
		sqv[rank][file] = sq;
		rankv[sq] = rank;
		filev[sq] = file;
		};

response_time = default_timeL;

InitializeStats();
ElapsedTime(1);
LoadOpenings();
PrintBoard();

return;
}

/*--> InitProgram: one time program initialization */
static
void
InitProgram(void)
{
fileT file;
rankT rank;
xsqT xsq;

/* map board */

for (rank = rank_1; rank <= rank_8; rank++)
	for (file = file_a; file <= file_h; file++)
		{
		xsq = (xfileL * marginL) + (xfileL * rank) + marginL + file;
		map[MapRankFile(rank, file)] = xsq;
		};

/* unmap board */

for (xsq = 0; xsq < xsqL; xsq++)
	unmap[xsq] = sq_nil;

for (rank = rank_1; rank <= rank_8; rank++)
	for (file = file_a; file <= file_h; file++)
		{
		xsq = (xfileL * marginL) + (xfileL * rank) + marginL + file;
		unmap[xsq] = MapRankFile(rank, file);
		};

prc_cand = 0;
prc_iter = 1;
prc_pvar = 1;
prc_time = 0;

NewGame();

return;
}

/*--> LocateAttacker: locate and place lowest attacker */
static
void
LocateAttacker(siT side, sqptrT a)
{
/*
	Place the lowest value piece attacking a square into array atak[][].
*/

sqT u;
siT d, j;
xsqT m, m0;
siT piece, i;
sqptrT sqptr;
siptrT s;

memset(a, 0, sqL * sizeof(siT));
Dstart[pawn] = Dstpwn[side];
Dstop[pawn] = Dstart[pawn] + 1;
sqptr = &PieceList[side][0];

for (i = 0; i <= PieceCnt[side]; i++)
	{
	piece = board[*sqptr];
	m0 = map[*sqptr];
	s = &svalue[*sqptr];
	*s = 0;
	sqptr++;

	if (sweep[piece])
		{
		for (j = Dstart[piece]; j <= Dstop[piece]; j++)
			{
			d = Dir[j];
			m = m0 + d;
			u = unmap[m];
			while (u >= 0)
				{
				*s += 2;

				if ((a[u] == 0) || (piece < a[u]))
					a[u] = piece;

				if (color[u] == neutral)
					{
					m += d;
					u = unmap[m];
					}
				else
					u = -1;
				};
			};
		}
	else
		{
		for (j = Dstart[piece]; j <= Dstop[piece]; j++)
			if ((u = unmap[m0 + Dir[j]]) >= 0)
				if ((a[u] == 0) || (piece < a[u]))
					a[u] = piece;
		};
	};

return;
}

/*--> LinkMove: add a move to the local tree */
static
void
LinkMove(siT ply, sqT frsq, sqT tosq, siT side, siT xside)
{
/*

Add a move to the tree.
Assign a bonus (in an attempt to improve move ordering)
if move is a principle variation, "killer", or capturing move.

*/

siT s;
usiT mv;
leafptrT node;

node = &Tree[TrPnt[ply + 1]];
TrPnt[ply + 1]++;
node->flags = node->reply = 0;
node->frsq = frsq;
node->tosq = tosq;
mv = (frsq << byteW) + tosq;

if ((frsq == 255) || (tosq == 255))
	s = 100;
else
	{
	s = 0;
	if (mv == PV)
		s = 150;
	else
		if (mv == killr1[ply])
			s = 90;
		else
			if (mv == killr2[ply])
				s = 70;
			else
				if (mv == killr3[ply])
					s = 50;
				else
					if (mv == Swag1)
						s = 30;
					else
						if (mv == Swag2)
							s = 20;

	if (color[tosq] != neutral)
		{
		node->flags |= capture;

		if (tosq == xkillr)
			s += 400;

		if (atak[xside][tosq] == 0)
			s += value[board[tosq]] - board[frsq];
		else
			if (board[tosq] > board[frsq])
				s += value[board[tosq]] - value[board[frsq]];
			else
				s += 15;
		};

	if (board[frsq] == pawn)
		{
		if ((rankv[tosq] == 0) || (rankv[tosq] == 7))
			node->flags |= promote;
		else
			if ((rankv[tosq] == 1) || (rankv[tosq] == 6))
				node->flags |= pwnthrt;
			else
				if (tosq == epsq)
					node->flags |= epmask;
		};

	if (atak[xside][frsq] > 0)
		s += 15;

	if (atak[xside][tosq] > 0)
		s -= 20;

	if (InChk)
		{
		if ((board[frsq] == king) && (atak[xside][tosq] == 0))
			s += 600;

		if (mv == Qkillr[ply])
			s += 100;
		};
	};

node->score = s - 20000;

return;
}

/*--> GenMoves: generate moves */
static
void
GenMoves(siT ply, sqT sq, siT side, siT xside)
{
/*

Generate moves for a piece. The from square is mapped onto a 12 by
12 board and offsets (taken from array Dir[]) are added to the
mapped location. Array unmap[] maps the move back onto array
board[] (yielding a value of -1 if the to square is off the board).
This process is repeated for bishops, rooks, and queens until a
piece is encountered or the the move falls off the board. Legal
moves are then linked into the tree.

*/

siT d;
sqT u;
xsqT m, m0;
siT i, piece;

piece = board[sq];
m0 = map[sq];

if (sweep[piece])
	{
	for (i = Dstart[piece]; i <= Dstop[piece]; i++)
		{
		d = Dir[i];
		m = m0 + d;
		u = unmap[m];

		while (u >= 0)
			if (color[u] == neutral)
				{
				LinkMove(ply, sq, u, side, xside);
				m += d;
				u = unmap[m];
				}
			else
				if (color[u] == xside)
					{
					LinkMove(ply, sq, u, side, xside);
					u = -1;
					}
				else
					u = -1;
		};
	}
else
	if (piece == pawn)
		{
		if ((side == white) && (color[sq + 8] == neutral))
			{
			LinkMove(ply, sq, sq + 8, side, xside);
			if (rankv[sq] == 1)
				if (color[sq + 16] == neutral)
					LinkMove(ply, sq, sq + 16, side, xside);
			}
		else
			if ((side == black) && (color[sq - 8]) == neutral)
				{
				LinkMove(ply, sq, sq - 8, side, xside);
				if (rankv[sq] == 6)
					if (color[sq - 16] == neutral)
						LinkMove(ply, sq, sq - 16, side, xside);
				};

		for (i = Dstart[piece]; i <= Dstop[piece]; i++)
			if ((u = unmap[m0 + Dir[i]]) >= 0)
				if ((color[u] == xside) || (u == epsq))
					LinkMove(ply, sq, u, side, xside);
		}
	else
		{
		for (i = Dstart[piece]; i <= Dstop[piece]; i++)
			if ((u = unmap[m0 + Dir[i]]) >= 0)
				if (color[u] != side)
					LinkMove(ply, sq, u, side, xside);
		};

return;
}

/*--> Castle: generate castling move */
static
void
Castle(siT side, sqT frsq, sqT tosq, siT iop, siptrT ok)
{
sqT e;
sqT k1, k2, r1, r2, c1, c2;
siT i, t0, xside;

xside = otherside[side];

if (side == white)
	e = sq_a1;
else
	e = sq_a8;

if (frsq == 255)
	{
	k1 = e + 4;
	k2 = e + 6;

	r1 = e + 7;
	r2 = e + 5;

	c1 = k1;
	c2 = r1;
	}
else
	{
	k1 = e + 4;
	k2 = e + 2;

	r1 = e;
	r2 = e + 3;

	c1 = r1;
	c2 = k1;
	};

if (iop == 0)
	{
	*ok = 0;

	if ((board[k1] == king) && (board[r1] == rook))
		*ok = 1;

	for (i = c1; i <= c2; i++)
		if (atak[xside][i] > 0)
			*ok = 0;

	for (i = c1 + 1; i < c2; i++)
		if (color[i] != neutral)
			*ok = 0;
	}
else
	{
	if (iop == 1)
		castld[side] = 1;
	else
		castld[side] = 0;

	if (iop == 2)
		{
		t0 = k1;
		k1 = k2;
		k2 = t0;

		t0 = r1;
		r1 = r2;
		r2 = t0;
		};

	board[k2] = king;
	color[k2] = side;
	Index[k2] = 0;

	board[k1] = vacant;
	color[k1] = neutral;

	board[r2] = rook;
	color[r2] = side;
	Index[r2] = Index[r1];

	board[r1] = vacant;
	color[r1] = neutral;

	PieceList[side][Index[k2]] = k2;
	PieceList[side][Index[r2]] = r2;
	};

return;
}

/*--> SortSegment: sort a tree segment */
static
void
SortSegment(siT p1, siT p2)
{
siT p, p0;
cpevT s;
leafT temp;

s = 32000;
while (p1 < p2)
	if (Tree[p1].score >= s)
		p1++;
	else
		{
		s = Tree[p1].score;
		p0 = p1;

		for (p = (p1 + 1); p <= p2; p++)
			if (Tree[p].score > s)
				{
				s = Tree[p].score;
				p0 = p;
				};

		temp = Tree[p1];
		Tree[p1] = Tree[p0];
		Tree[p0] = temp;
		p1++;
		};

return;
}

/*--> MoveList: generate a movelist into the global tree vector */
static
void
MoveList(siT side, siT ply)
{
/*

Fill the array Tree[] with all available moves for side to
play. Array TrPnt[ply] contains the index into Tree[]
of the first move at a ply.

*/

siT i;
siT ok, xside;

xside = otherside[side];
TrPnt[ply + 1] = TrPnt[ply];
Dstart[pawn] = Dstpwn[side];
Dstop[pawn] = Dstart[pawn] + 1;

for (i = 0; i <= PieceCnt[side]; i++)
	GenMoves(ply, PieceList[side][i], side, xside);

if (kingmoved[side] == 0)
	{
	Castle(side, 255, 0, 0, &ok);
	if (ok)
		LinkMove(ply, 255, 0, side, xside);

	Castle(side, 0, 255, 0, &ok);
	if (ok)
		LinkMove(ply, 0, 255, side, xside);
	};

SortSegment(TrPnt[ply], TrPnt[ply + 1] - 1);

return;
}

/*--> OpeningBook: select a movefrom the opening book */
static
void
OpeningBook(siT side)
{
siT i, j, pnt;
usiT m, r, r0;

srand(time(NULL));
r0 = m = 0;

for (i = 0; i < BookSize; i++)
	{
	for (j = 0; j <= GameCnt; j++)
		if (GameList[j] != Book[i][j])
			break;

	if (j > GameCnt)
		if ((r=rand()) > r0)
			{
			r0 = r;
			m = Book[i][GameCnt + 1];
			};
	};

for (pnt = TrPnt[1]; pnt < TrPnt[2]; pnt++)
	if (((Tree[pnt].frsq << byteW) + Tree[pnt].tosq) == m)
		Tree[pnt].score = 0;

SortSegment(TrPnt[1], TrPnt[2] - 1);

if (Tree[TrPnt[1]].score < 0)
	BookDepth = -1;

return;
}

/*--> Coordinate: construct somewhat nonstandard "algebraic notation" */
static
void
Coordinate(sqT frsq, sqT tosq)
{
if (frsq == 255)
	{
	strcpy(mvstr1, "o-o");
	strcpy(mvstr2, "O-O");
	}
else
	if (tosq == 255)
		{
		strcpy(mvstr1, "o-o-o");
		strcpy(mvstr2, "O-O-O");
		}
	else
		{
		mvstr1[0] = fx[filev[frsq]];
		mvstr1[1] = rx[rankv[frsq]];
		mvstr1[2] = fx[filev[tosq]];
		mvstr1[3] = rx[rankv[tosq]];
		mvstr1[4] = '\0';

		mvstr2[0] = qx[board[frsq]];
		mvstr2[1] = fx[filev[tosq]];
		mvstr2[2] = rx[rankv[tosq]];
		mvstr2[3] = '\0';
		};

return;
}

/*--> UpdatePieceList: update the piece list */
static
void
UpdatePieceList(siT side, sqT sq, siT iop)
{
/*

Array PieceList[side][indx] contains the location of all the pieces of
either side. Array Index[sq] contains the indx into PieceList for a
given square.

*/

siT i;

if (iop == 1)
	{
	PieceCnt[side]--;

	for (i = Index[sq]; i <= PieceCnt[side]; i++)
		{
		PieceList[side][i] = PieceList[side][i + 1];
		Index[PieceList[side][i]] = i;
		};
	}
else
	{
	PieceCnt[side]++;
	PieceList[side][PieceCnt[side]] = sq;
	Index[sq] = PieceCnt[side];
	};

return;
}

/*--> EnPassant: handle an en passant move */
static
void
EnPassant(siT side, siT xside, sqT frsq, sqT tosq, siT iop)
{
siT l;

if (tosq > frsq)
	l = tosq - 8;
else
	l = tosq + 8;

if (iop == 1)
	{
	board[l] = vacant;
	color[l] = neutral;
	}
else
	{
	board[l] = pawn;
	color[l] = xside;
	};

InitializeStats();

return;
}

/*--> MakeMove: make a move */
static
void
MakeMove(siT side, leafptrT node, siptrT tempb, siptrT tempc)
{
/*

Update Arrays board[], color[], and Index[] to reflect the new
board position obtained after making the move pointed to by
node.  Also update miscellaneous stuff that changes when a move
is made.

*/

sqT frsq, tosq;
siT ok, xside;

xside = otherside[side];
frsq = node->frsq;
tosq = node->tosq;
epsq = sq_nil;
xkillr = tosq;
GameList[++GameCnt] = (frsq << byteW) + tosq;

if ((frsq == 255) || (tosq == 255))
	{
	GamePc[GameCnt] = vacant;
	GameClr[GameCnt] = neutral;
	Castle(side, frsq, tosq, 1, &ok);
	}
else
	{
	*tempc = color[tosq];
	*tempb = board[tosq];
	GamePc[GameCnt] = *tempb;
	GameClr[GameCnt] = *tempc;

	if (*tempc != neutral)
		{
		UpdatePieceList(*tempc, tosq, 1);

		if (*tempb == pawn)
			PawnCnt[*tempc][filev[tosq]]--;

		if (board[frsq] == pawn)
			{
			PawnCnt[side][filev[frsq]]--;
			PawnCnt[side][filev[tosq]]++;
			};

		mtl[xside] -= value[*tempb];

		if (*tempb == pawn)
			pmtl[xside] -= value[pawn];
		};

	color[tosq] = color[frsq];
	board[tosq] = board[frsq];
	Index[tosq] = Index[frsq];
	PieceList[side][Index[tosq]] = tosq;

	color[frsq] = neutral;
	board[frsq] = vacant;

	if (board[tosq] == pawn)
		if ((tosq - frsq) == 16)
			epsq = frsq + 8;
		else
			if ((frsq - tosq) == 16)
				epsq = frsq - 8;

	if (node->flags & promote)
		{
		board[tosq] = queen;
		mtl[side] += value[queen] - value[pawn];
		pmtl[side] -= value[pawn];
		};

	if (board[tosq] == king)
		kingmoved[side]++;

	if (node->flags & epmask)
		EnPassant(side, xside, frsq, tosq, 1);
	};

return;
}

/*--> Distance: compute distace between two squares */
static
siT
Distance(sqT sq1, sqT sq2)
{
siT d1, d2, dist;

d1 = filev[sq1] - filev[sq2];
if (d1 < 0)
	d1 = -d1;

d2 = rankv[sq1] - rankv[sq2];
if (d2 < 0)
	d2 = -d2;

if (d1 > d2)
	dist = d1;
else
	dist = d2;

return (dist);
}

/*--> ScorePosition: score a position */
static
void
ScorePosition(siT side, cpevptrT score)
{
/*

Calculate a positional score for each piece as follows:

	pawns:
		material value     : 100 pts
		d,e file, not moved: -10 pts
			& also blocked : -10 pts
		doubled            : -12 pts (each pawn)
		isolated           : -24 pts
		backward           : -8  pts
			& attacked     : -6  pts
		passed             : depends on rank, material balance,
							position of opponents king, blocked

	knights:
		material value     : 330 pts
		centre proximity   : array pknight

	bishops:
		material value     : 330 pts
		discourage edges   : array pbishop
		mobility           : +2 pts per move

	rooks:
		material value     : 500 pts
		mobility           : +2 pts per move
		open file          : +12 pts
		half open          : +6 pts

	queen:
		material value     : 950 pts

	king:
		castled            : ~ +10 pts (depends on material)
		king moved         : ~ -15 pts (depends on material)
		adjacent pawn      : +5 pts before endgame
		attacks to         : -5 pts each if more than 1 attack
		adjacent square        before endgame
		pawn missing from  : -10 pts before endgame
			adjacent file
		centre proximity   : -2 pts before endgame, during endgame
							switches to a bonus for center proximity
							dependent on opponents control of adjacent
							squares

	"hung" pieces          : -8  (1 hung piece)
							-24 (more than 1)

*/

sqT sq;
rankT r, rank;
fileT file;
siT i, j, a;
xsqT m0;
siT e, u, piece, wking, bking, cwking, cbking;
siT db, dw, s, stage1, stage2, c1, c2, a1, a2;
siT xside, in_square;
cpevT pscore[sidesL];

e = 0;
xside = otherside[side];
pscore[white] = pscore[black] = 0;

emtl[white] = mtl[white] - pmtl[white] - value[king];
emtl[black] = mtl[black] - pmtl[black] - value[king];

wking = PieceList[white][0];
bking = PieceList[black][0];
cwking = filev[wking];
cbking = filev[bking];

stage1 = 10 - (emtl[white] + emtl[black]) / 670;
stage2 = (stage1 * stage1) / 10;

for (c1 = white; c1 <= black; c1++)
	{
	c2 = otherside[c1];

	for (i = 0; i <= PieceCnt[c1]; i++)
		{
		sq = PieceList[c1][i];
		piece = board[sq];

		a1 = atak[c1][sq];
		a2 = atak[c2][sq];

		rank = rankv[sq];
		file = filev[sq];

		s = svalue[sq];

		if ((piece == pawn) && (c1 == white))
			{
			if ((file == file_d) || (file == file_e))
				if (rank == rank_2)
					{
					s -= 10;
					if (color[sq + 8] == white)
						s -=10;
					}
				else
					if ((rank == rank_5) && (a1 == pawn))
						s += 8;

			if (((file - cwking) > 1) || ((cwking - file) > 1))
				s += stage1 * rank;

			if (PawnCnt[white][file] > 1)
				s -= 12;

			if ((file > file_a) && (PawnCnt[white][file - 1] == 0) &&
				(file < file_h) && (PawnCnt[white][file + 1] == 0))
				s -= 24;

			if ((a1 != pawn) && (atak[c1][sq + 8] != pawn))
				{
				s -= 8;
				if (a2 > 0)
					s -= 6;
				};

			if (PawnCnt[black][file] == 0)
				{
				dw = Distance(sq, wking);
				db = Distance(sq, bking);
				s += stage2 * (db - dw);

				if (side == white)
					r = rank - 1;
				else
					r = rank;

				if ((rankv[bking] >= r) && (db < (8 - r)))
					in_square = 1;
				else
					in_square = 0;

				e = 0;
				for (a = sq + 8; a < 64; a += 8)
					if (atak[black][a] == pawn)
						a = 99;
					else
						if ((atak[black][a] > 0) || (color[a] != neutral))
							e = 1;

				if (a == 99)
					s += stage1 * passed_pawn3[rank];
				else
					if (in_square || (e == 1))
						s += stage1 * passed_pawn2[rank];
					else
						s += stage1 * passed_pawn1[rank];
				};
			}
		else
			if ((piece == pawn) && (c1 == black))
				{
				if ((file == file_d) || (file == file_e))
					if (rank == rank_7)
						{
						s -= 10;
						if (color[sq - 8] == black)
							s -= 10;
						}
					else
						if ((rank == rank_4) && (a1 == pawn))
							s += 8;

				if (((file - cbking) > 1) || ((cbking - file) > 1))
					s += stage1 * (7 - rank);

				if (PawnCnt[black][file] > 1)
					s -= 12;

				if ((file > 0) && (PawnCnt[black][file - 1] == 0) &&
					(file < 7) && (PawnCnt[black][file + 1] == 0))
					s -= 24;

				if ((a1 != pawn) && (atak[c1][sq - 8]) != pawn)
					{
					s -= 8;
					if (a2 > 0)
						s -= 6;
					};

				if (PawnCnt[white][file] == 0)
					{
					dw = Distance(sq, wking);
					db = Distance(sq, bking);
					s += stage2 * (dw - db);

					if (side == black)
						r = rank + 1;
					else
						r = rank;

					if ((rankv[wking] <= r) && (dw < (r + 1)))
						in_square = 1;
					else
						in_square = 0;

					e = 0;
					for (a = sq - 8; a >= 0 ; a -= 8)
						if (atak[white][a] == pawn)
							a = -99;
						else
							if ((atak[white][a] > 0) ||
								(color[a] != neutral))
								e = 1;

					if (a == -99)
						s += stage1 * passed_pawn3[7 - rank];
					else
						if (in_square || (e == 1))
							s += stage1 * passed_pawn2[7 - rank];
						else
							s += stage1 * passed_pawn1[7 - rank];
					};
				}
			else
				if (piece == knight)
					s = pknight[sq];
				else
					if (piece == bishop)
						s += pbishop[sq];
					else
						if (piece == rook)
							{
							if (PawnCnt[white][file] == 0)
								s += 6;
							if (PawnCnt[black][file] == 0)
								s += 6;
							}
						else
							if (piece == queen)
								s = s / 3;
							else
								if (piece == king)
									{
									m0 = map[sq];
									if (castld[c1])
										s += (20 / (stage1 + 1));
									else
										if (kingmoved[c1] > 0)
											s -= (30 / (stage1 + 1));

									if (emtl[c1] > 1300)
										{
										s -= 2 * edge[sq];
										a = 0;
										for (j = Dstart[king];
											j <= Dstop[king]; j++)
											if ((u = unmap[m0 + Dir[j]]) >=
												0)
												{
												if (atak[c2][u] > 0)
													a++;
												if (board[u] == pawn)
													s += 5;
												};

										if (a > 1)
											s -= 5*a;

										if ((file > 0) &&
											(PawnCnt[c1][file - 1] == 0))
											s -= 10;

										if ((file < 7) &&
											(PawnCnt[c1][file + 1] == 0))
											s -= 10;

										if (PawnCnt[c1][file] == 0)
											s -= 12;
										}
									else
										{
										e = edge[sq];
										for (j = Dstart[king];
											j <= Dstop[king]; j++)
											if ((u = unmap[m0 + Dir[j]]) >=
												0)
												if (atak[c2][u] == 0)
													e += edge[u];

										s += (e *
											((1300 - emtl[c1]) / 100))
											/ 8;
										};

									if ((mtl[c1] < 1000) &&
										(mtl[c2] < 1990) &&
										(Distance(wking, bking) == 2) &&
										(e < 12))
										s -= 30;
									};

		if ((a2 > 0) && ((a1 == 0) || (a2 < piece)))
			hung[c1]++;

		if (a2 > 0)
			s -= 3;

		pscore[c1] += s;
		svalue[sq] = s;
		};
	};

if (hung[side] > 1)
	pscore[side] -= 12;
if (hung[xside] == 1)
	pscore[xside] -= 8;
if (hung[xside] > 1)
	pscore[xside] -= 24;

*score = mtl[side] - mtl[xside] + pscore[side] - pscore[xside] - 5;

if ((*score > 0) && (pmtl[side] == 0) && (emtl[side] <= value[bishop]))
	*score = 0;
if ((*score < 0) && (pmtl[xside] == 0) && (emtl[xside] <= value[bishop]))
	*score = 0;

return;
}

/*--> LinkCapture: link in a capture move */
static
void
LinkCapture(siT ply, sqT frsq, sqT tosq, siT ck)
{
leafptrT node;

node = &Tree[TrPnt[ply + 1]];
TrPnt[ply + 1]++;
node->flags = node->reply = 0;
node->frsq = frsq;
node->tosq = tosq;

if ((tosq == ykillr) || (tosq == ck))
	node->score = value[board[tosq]] - board[frsq];
else
	node->score = value[board[tosq]] - value[board[frsq]];

return;
}

/*--> CaptureList: generate capture move list */
static
void
CaptureList(siT side, siT xside, siT ply)
{
/*

Generate a list of captures similiarly to GenMoves.

*/

siT  u, d;
xsqT m, m0;
siT i, j, piece, ck;
sqptrT aloc;

ck = Ckillr[side] & byteM;
TrPnt[ply + 1] = TrPnt[ply];
Dstart[pawn] = Dstpwn[side];
Dstop[pawn] = Dstart[pawn] + 1;
aloc = &PieceList[side][0];

for (i = 0; i <= PieceCnt[side]; i++)
	{
	piece = board[*aloc];
	m0 = map[*aloc];

	if (sweep[piece])
		for (j = Dstart[piece]; j <= Dstop[piece]; j++)
			{
			d = Dir[j];
			m = m0 + d;
			u = unmap[m];

			while (u >= 0)
				if (color[u] == neutral)
					{
					m += d;
					u = unmap[m];
					}
				else
					{
					if (color[u] == xside)
						LinkCapture(ply, *aloc, u, ck);
					u = -1;
					};
			}
		else
			for (j = Dstart[piece]; j <= Dstop[piece]; j++)
				if ((u = unmap[m0 + Dir[j]]) >= 0)
					if (color[u] == xside)
						LinkCapture(ply, *aloc, u, ck);

		aloc++;
		};

SortSegment(TrPnt[ply], TrPnt[ply + 1] - 1);

return;
}

/*--> CaptureSearch: conduct quiescence search */
static
void
CaptureSearch(siT side, siT xside, siT ply, siT depth,
	siT alpha, siT beta, siT qscore, siptrT best, usiptrT bstline)
{
/*

Perform alpha-beta search on captures up to 9 ply past
nominal search depth.

*/

sqT frsq, tosq;
siT j, v, q, pnt, tempb, tempc, pbst, sv;
usiT nxtline[plyL];
leafptrT node;

*best = -qscore;
bstline[ply] = 0;
CaptureList(side, xside, ply);
pnt = TrPnt[ply];
pbst = 0;

while ((pnt < TrPnt[ply + 1]) && (*best <= beta))
	{
	node = &Tree[pnt];
	pnt++;
	frsq = node->frsq;
	tosq = node->tosq;
	v = value[board[tosq]] - qscore + svalue[tosq];

	if (v > alpha)
		{
		if (board[tosq] == king)
			node->score = 10000;
		else
			if (depth == 1)
				node->score = v;
			else
				{
				ykillr = tosq;
				NodeCnt++;

				sv = svalue[tosq];
				svalue[tosq] = svalue[frsq];

				tempb = board[tosq];
				tempc = color[tosq];
				UpdatePieceList(tempc, tosq, 1);

				board[tosq] = board[frsq];
				color[tosq] = color[frsq];
				Index[tosq] = Index[frsq];
				PieceList[side][Index[tosq]] = tosq;

				board[frsq] = vacant;
				color[frsq] = neutral;

				CaptureSearch(xside, side, ply + 1, depth - 1,
					-beta, -alpha, v, &q, nxtline);
				node->score = -q;

				board[frsq] = board[tosq];
				color[frsq] = color[tosq];
				Index[frsq] = Index[tosq];
				PieceList[side][Index[frsq]] = frsq;

				board[tosq] = tempb;
				color[tosq] = tempc;
				UpdatePieceList(xside, tosq, 2);

				svalue[frsq] = svalue[tosq];
				svalue[tosq] = sv;
				};

		if (node->score > *best)
			{
			pbst = pnt;
			*best = node->score;

			if (*best > alpha)
				alpha = *best;

			for (j = ply; j < plyL; j++)
				bstline[j] = nxtline[j];

			bstline[ply] = (frsq << byteW) + tosq;
			};
		};
	};

if (pbst == 0)
	Ckillr[side] = -1;
else
	Ckillr[side] = (Tree[pbst].frsq << byteW) + Tree[pbst].tosq;

return;
}

/*--> RepetitionCheck: check for a repetition */
static
void
RepetitionCheck(leafptrT node)
{
/*

Check for draw by threefold repetition or 50 move rule.

*/

sqT frsq, tosq;
siT i, c, r, b[sqL];
usiT m;

r = c = 0;
memset(b, 0, sqL * sizeof(siT));

for (i = GameCnt; i > Game50; i--)
	{
	m = GameList[i];
	frsq = m >> byteW;
	tosq = m & byteM;

	if ((tosq != 255) && (frsq != 255))
		{
		b[frsq]++;
		b[tosq]--;

		if (b[frsq] == 0)
			c--;
		else
			c++;

		if (b[tosq] == 0)
			c--;
		else
			c++;

		if (c == 0)
			r++;
		};
	};

if (r == 1)
	if (node->score > 0)
		node->score -= 20;
	else
		node->score += 20;

if (((GameCnt - Game50) > 99) || (r == 2))
	{
	node->score = 0;
	node->flags |= exact;
	node->flags |= draw;
	};

return;
}

/*--> Evaluate: evaluate a node */
static
void
Evaluate(siT side, leafptrT node, siT ply, siT depth,
	siT alpha, siT beta, usiptrT nxtline)
{
/*

See if either king is in check.  If positional score estimate
passed forward from previous ply warrants, score the position.
If positional score is greater than alpha, perform CaptureSearch
to modify score based on ensuing capture sequence.

*/

siT xside, s, x, t;

hung[white] = hung[black] = 0;
xside = otherside[side];
LocateAttacker(xside, atak[xside]);

if (atak[xside][PieceList[side][0]] > 0)
	{
	node->score = ply - 10000;
	node->flags |= incheck;
	node->flags |= exact;
	}
else
	{
	LocateAttacker(side, atak[side]);

	if (atak[side][PieceList[xside][0]])
		node->flags |= check;

	if (ply > Sdepth)
		t = 0;
	else
		t = 90;

	s = -PPscore[ply - 1] + mtl[side] - mtl[xside];

	if (((s + t) > alpha) || (node->flags & check) ||
		(node->flags & pwnthrt))
		ScorePosition(side, &s);

	PPscore[ply] = s - mtl[side] + mtl[xside];

	if ((s < alpha) || (depth > 1))
		{
		if (node->score < -12000)
			node->score = s;
		}
	else
		{
		ykillr = xkillr;
		CaptureSearch(xside, side, ply + 1, 9, -s - 1,
			-alpha, s, &x, nxtline);
		node->score = -x;
		node->reply = nxtline[ply + 1];
		};

	RepetitionCheck(node);
	};

return;
}

/*--> ExpandNode: generate score by node expansion */
static
void
ExpandNode(siT side, leafptrT node, siT depth, siT ply,
	siT alpha, siT beta, usiptrT nxtline)
{
/*

Generate a score for current position by calling Search routine
to generate opponents best response.

*/

siT s, xside;
leafptrT reply;

xside = otherside[side];
nxtline[ply] = (node->frsq << byteW) + node->tosq;
nxtline[ply + 1] = node->reply;
Search(xside, ply + 1, depth - 1, -beta, -alpha, nxtline);

if (!timeout)
	{
	reply = &Tree[TrPnt[ply + 1]];
	s = -reply->score;

	if ((s >= alpha) && (s <= beta))
		node->score = s;
	else
		if ((s < alpha) && (s < node->score))
			node->score = s;
		else
			if ((s > beta) && (s > node->score))
				node->score = s;

	if ((reply->flags & incheck) && !(node->flags & check))
		{
		node->flags |= draw;
		node->score = 0;
		};

	if ((node->flags & draw) || (node->score <= -9000) ||
		(node->score >= 9000))
		node->flags |= exact;

	node->reply = nxtline[ply + 1];
	};

return;
}

/*--> UnmakeMove: unmake a move */
static
void
UnmakeMove(siT side, leafptrT node, siptrT tempb, siptrT tempc)
{
/*

Take back the move pointed to by node.

*/

sqT frsq, tosq;
siT ok, xside;

xside = otherside[side];
frsq = node->frsq;
tosq = node->tosq;
epsq = sq_nil;
GameCnt--;

if ((frsq == 255) || (tosq == 255))
	Castle(side, frsq, tosq, 2, &ok);
else
	{
	color[frsq] = color[tosq];
	board[frsq] = board[tosq];
	Index[frsq] = Index[tosq];
	PieceList[side][Index[frsq]] = frsq;

	color[tosq] = *tempc;
	board[tosq] = *tempb;

	if (*tempc != neutral)
		{
		UpdatePieceList(*tempc, tosq, 2);

		if (*tempb == pawn)
			PawnCnt[*tempc][filev[tosq]]++;

		if (board[frsq] == pawn)
			{
			PawnCnt[side][filev[tosq]]--;
			PawnCnt[side][filev[frsq]]++;
			};

		mtl[xside] += value[*tempb];

		if (*tempb == pawn)
			pmtl[xside] += value[pawn];
		};

	if (node->flags & promote)
		{
		board[frsq] = pawn;
		mtl[side] += value[pawn] - value[queen];
		pmtl[side] += value[pawn];
		};

	if (board[frsq] == king)
		kingmoved[side]--;

	if (node->flags & epmask)
		EnPassant(side, xside, frsq, tosq, 2);
	};

return;
}


double getutime(void)
{
	double curtime;
	struct timeval tm;
	struct timezone tz;
	gettimeofday(&tm,&tz);
	curtime = (tm.tv_sec * 1000.0) + (tm.tv_usec / 1000.0);
	return(curtime);
}

/*--> PostVariation: post a variation to the display */
static
void
PostVariation(leafptrT node)
{
siT ply;

if (prc_pvar)
	{
	ply = 1;
	printf("Score: %hd   PV:", node->score);

	while (prvar[ply] > 0)
		{
		Coordinate(prvar[ply] >> byteW, prvar[ply] & byteM);
		printf(" %s", mvstr1);
		ply++;
		};
	putchar('\n');
	};

return;
}

/*--> Search: search for a move */
static
void
Search(siT side, siT ply, siT depth, siT alpha, siT beta, usiptrT bstline)
{
/*

Perform the main alpha-beta search.  Extensions up to 3 ply
beyond the nominal iterative search depth MAY occur for checks,
check evasions,  pawn promotion threats,  and threats to multiple
pieces.

*/

siT j;
siT best, tempb, tempc, xside, pnt, pbst, hhh, d;
usiT mv, nxtline[plyL];
leafptrT node;
double tstart;
xside = otherside[side];

if (ply == 1)
	InChk = 0;
else
	InChk = ChkFlag[ply - 1];
PV = bstline[ply];

if (ply < 3)
	Swag1 = Swag2 = 0;
else
	{
	Swag1 = (Tree[TrPnt[ply - 2]].frsq << byteW) +
		Tree[TrPnt[ply - 2]].tosq;
	Swag2 = (Tree[TrPnt[ply - 2] + 1].frsq << byteW) +
		Tree[TrPnt[ply - 2] + 1].tosq;
	};

if (ply > 1) {
	tstart = getutime();
	MoveList(side, ply);
	time_splits[count_time_split] = getutime() - tstart;
	if (count_time_split < 100000) count_time_split++;
}

best = -12000;
PPscore[ply] = -PPscore[ply - 1];
pnt = TrPnt[ply];
pbst = pnt;

while ((pnt < TrPnt[ply + 1]) && (best <= beta) && !timeout)
	{
	node = &Tree[pnt];
	NodeCnt++;
	nxtline[ply + 1] = 0;

	if (ply == 1)
		{
		d = node->score-best;
		if (pnt == TrPnt[ply])
			extra_time = 0;
		else
			if (d < -50)
				extra_time = -response_time / 3;
			else
				if (d < 20)
					extra_time = 0;
				else
					if (d < 60)
						extra_time = response_time / 3;
					else
						if (d < 200)
							extra_time = response_time;
						else
							extra_time = 2 * response_time;
		};

	if (node->flags & capture)
		CptrFlag[ply] = 1;
	else
		CptrFlag[ply] = 0;

	if (node->flags & pwnthrt)
		PawnThreat[ply] = 1;
	else
		PawnThreat[ply] = 0;

	if ((ply == 1) && prc_cand)
		{
		Coordinate(node->frsq, node->tosq);
		printf("CM: %s\n", mvstr1);
		};

	if ((node->flags & exact) == 0)
		{
		MakeMove(side, node, &tempb, &tempc);
	
		tstart = getutime();
		Evaluate(side, node, ply, depth, alpha, beta, nxtline);		
		time_evals[count_time_eval] = getutime() - tstart;
		if (count_time_eval < 100000) count_time_eval++;
		if ((hung[xside] > 1) && (ply <= Sdepth))
			hhh = 1;
		else
			hhh = 0;

		if (node->flags & check)
			ChkFlag[ply] = 1;
		else
			ChkFlag[ply] = 0;

		if ((node->flags & exact) == 0)
			{
			if (depth > 1)
				ExpandNode(side, node, depth, ply, alpha, beta, nxtline);

			if ((node->score <= beta) &&
				(PawnThreat[ply] ||
				((ChkFlag[ply] || hhh) && (depth == 1))))
				ExpandNode(side, node, depth + 1, ply,
					alpha, beta, nxtline);
			else
				if ((ChkFlag[ply - 1] || PawnThreat[ply - 1]) &&
					(ply <= (Sdepth + 2)) && (Sdepth > 1) &&
					((ply > Sdepth) || CptrFlag[ply - 1] ||
					((ply > 3) &&
					(ChkFlag[ply - 3] || CptrFlag[ply - 3])) ||
					(hung[side] > 1)))
					ExpandNode(side, node, depth + 1, ply,
						alpha, beta, nxtline);
			};

		UnmakeMove(side, node, &tempb, &tempc);
		};

	if (node->score > best && !timeout)
		{
		if ((ply == 1) && (depth > 1) && (node->score > alpha) &&
			(node->flags & exact) == 0)
			node->score += 5;

		best = node->score;
		pbst = pnt;

		if (best > alpha)
			alpha = best;

		for (j = ply; j < plyL; j++)
			bstline[j] = nxtline[j];

		bstline[ply] = (node->frsq << byteW) + node->tosq;

		if (ply == 1 && post)
			PostVariation(node);
		};

	if ((pnt & byteM) == 0)
		ElapsedTime(0);

	pnt++;

	if (best > 9000)
		beta = 0;
	};

if (timeout)
	pnt--;

if (ply == 1)
	SortSegment(TrPnt[ply], pnt - 1);
else
	Tree[TrPnt[ply]] = Tree[pbst];

node = &Tree[TrPnt[ply]];
mv = (node->frsq << byteW) + node->tosq;

if (node->tosq != (GameList[GameCnt] & byteM))
	if (best > beta)
		killr1[ply] = mv;
	else
		if (mv != killr2[ply])
			{
			killr3[ply] = killr2[ply];
			killr2[ply] = mv;
			};

if (InChk && best > -9000)
	Qkillr[ply] = mv;

return;
}

/*--> SelectMove: select a move for the given side */
static
void
SelectMove(siT side)
{
/*

Select a move by calling function Search() at progressively deeper
ply until time is up or a mate or draw is reached. An alpha-beta
window of -0, +75 points is set around the score returned from the
previous iteration.

*/

siT i, alpha, beta, tempb, tempc;

timeout = 0;
player = side;

for (i = 0; i < plyL; i++)
	prvar[i] = killr1[i] = killr2[i] = killr3[i] = 0;

PPscore[0] = -5000;
alpha = -9999;
beta = 9999;
NodeCnt = Sdepth = extra_time = 0;
LocateAttacker(white, atak[white]);
LocateAttacker(black, atak[black]);
TrPnt[1] = 0;
root = &Tree[0];
MoveList(side, 1);

if (GameCnt < BookDepth)
	OpeningBook(side);
else
	BookDepth = -1;

if (BookDepth > 0)
	timeout = 1;

while (!timeout && (Sdepth < plyL))
	{
	Sdepth++;
	if (prc_iter)
		printf("Iteration: %d\n", Sdepth);
	Search(side, 1, Sdepth, alpha, beta, prvar);

	if (root->score < alpha)
		{
		if (prc_iter)
			printf("Iteration: %d-\n", Sdepth);
		Search(side, 1, Sdepth, -12000, alpha, prvar);
		};

	if ((root->score > beta) && !(root->flags & exact))
		{
		if (prc_iter)
			printf("Iteration: %d+\n", Sdepth);
		Search(side, 1, Sdepth, beta, 12000, prvar);
		};

	beta = root->score + 75;

	if (root->flags & exact)
		timeout = 1;
	};

if (root->score > -9999)
	{
	MakeMove(side, root, &tempb, &tempc);
	Coordinate(root->frsq, root->tosq);
	PrintBoard();
	printf("My move is: %s\n", mvstr1);
	};

ElapsedTime(1);
printf("Nodes: %ld   Nodes/Sec: %ld\n", NodeCnt, srate);

if (root->flags & draw)
	printf("draw game!\n");

if (root->score < -9000)
	printf("opponent will soon mate!\n");

if (root->score > 9000)
	printf("computer will soon mate!\n");

if (root->score == -9999)
	{
	printf("opponent mates!!\n");
	mate = 1;
	};

if (root->score == 9998)
	{
	printf("computer mates!!\n");
	mate = 1;
	};

putchar('\n');

if (post)
	PostVariation(root);

if ((root->frsq == 255) || (root->tosq == 255))
	Game50 = GameCnt;
else
	if ((board[root->tosq] == pawn) || (root->flags & capture))
		Game50 = GameCnt;

GameScore[GameCnt] = root->score;

if (GameCnt > (gameL - 2))
	quit = 1;

player = otherside[side];

return;
}

/*--> VerifyMove: check user move for legality */
static
void
VerifyMove(charptrT s, siptrT ok)
{
/*

See if the opponents move is legal, if so, make it.

*/

siT x, pnt, cnt, tempb, tempc;
usiT nxtline[plyL];
leafptrT node, xnode;

*ok = 0;
cnt = 0;
xnode = NULL;
MoveList(opponent, 2);
pnt = TrPnt[2];

while (pnt < TrPnt[3])
	{
	node = &Tree[pnt];
	pnt++;
	Coordinate(node->frsq, node->tosq);
	if ((strcmp(s, mvstr1) == 0) || (strcmp(s, mvstr2) == 0))
		{
		xnode = node;
		cnt++;
		};
	};

if (cnt == 1)
	{
	MakeMove(opponent, xnode, &tempb, &tempc);
	CaptureSearch(computer, opponent, 3, 1, -9999, 9999, 0, &x, nxtline);

	if (x == 10000)
		UnmakeMove(opponent, xnode, &tempb, &tempc);
	else
		{
		*ok = 1;
		PrintBoard();

		if ((xnode->frsq == 255) || (xnode->tosq == 255))
			Game50 = GameCnt;
		else
			if ((board[xnode->tosq] == pawn) || (xnode->flags & capture))
				Game50 = GameCnt;
		};
	};

return;
}

/*--> SetBoard: set up a position */
static
void
SetBoard(void)
{
siT a, r, c;
sqT sq;
char s[tL];

PrintBoard();
a = white;
do
	{
	printf(".    Exit to Main\n");
	printf("#    Clear Board\n");
	ReadLine("Enter piece & location: ", s);

	if (s[0] == '#')
		{
		for (sq = sq_a1; sq <= sq_h8; sq++)
			{
			board[sq] = vacant;
			color[sq] = neutral;
			};
		PrintBoard();
		};

	if ((s[0] == 'c') || (s[0] == 'C'))
		a = otherside[a];

	c = s[1] - 'a';
	r = s[2] - '1';

	if ((c >= 0) && (c < 8) && (r >= 0) && (r < 8))
		{
		sq = sqv[r][c];
		color[sq] = a;

		if (s[0] == 'p')
			board[sq] = pawn;
		else
			if (s[0] == 'n')
				board[sq] = knight;
		else
			if (s[0] == 'b')
				board[sq] = bishop;
			else
				if (s[0] == 'r')
					board[sq] = rook;
				else
					if (s[0] == 'q')
						board[sq] = queen;
					else
						if (s[0] == 'k')
							board[sq] = king;
						else
							{
							board[sq] = vacant;
							color[sq] = neutral;
							};
		};
	}
while (s[0] != '.');

if (board[4] != king)
	kingmoved[white] = 10;
if (board[61] != king)
	kingmoved[black] = 10;

GameCnt = -1;
Game50 = -1;
BookDepth = 0;
InitializeStats();
PrintBoard();

return;
}

/*--> Help: display command help */
static
void
Help(void)
{
char buff[tL];

printf("This program attempts to play chess.\n");
putchar('\n');

printf("To make a move, enter the file (labelled 'a' - 'h') and\n");
printf("rank (labelled '1' - '8') of the 'from' and 'to' squares.\n");
printf("Example: to move the kings pawn forward 2 squares, type e2e4.\n");
putchar('\n');

printf("Other commands are:\n");
printf("\tboth    computer plays both sides\n");
printf("\tgo      skip your move\n");
printf("\thint    computer suggests your move\n");
printf("\tlist    list moves to file scp.lst\n");
printf("\tload    load game from disk\n");
printf("\tnew     set up for a new game\n");
printf("\to-o     castle king side\n");
printf("\to-o-o   castle queen side\n");
printf("\tpost    post best line of play\n");
printf("\tquit    exit CHESS\n");
printf("\tredraw  re-paint display\n");
printf("\treverse reverse board display\n");
printf("\tsave    save game to disk\n");
printf("\tset     set up a board position\n");
printf("\tswitch  switch sides with computer\n");
printf("\ttime    change response time\n");
putchar('\n');

ReadLine("Type return to proceed:", buff);

PrintBoard();

return;
}

/*--> SaveGame: save the game to a file */
static
void
SaveGame(char fname[tL])
{
FILE *fp;
sqT sq;
siT i;

if (fname[0] == '\0')
	strcpy(fname, fn_sav);

if ((fp = fopen(fname, "w")) == NULL)
	{
	fprintf(stderr, "cannot open \"%s\"\n", fname);
	exit(1);
	};

fprintf(fp, "%d %d\n", castld[white], castld[black]);
fprintf(fp, "%d %d\n", kingmoved[white], kingmoved[black]);

for (sq = sq_a1; sq <= sq_h8; sq++)
	fprintf(fp, "%d\n", 256 * board[sq] + color[sq]);

for (i = 0; i <= GameCnt; i++)
	fprintf(fp, "%d %d %d %d\n",
		GameList[i], GameScore[i], GamePc[i], GameClr[i]);

fclose(fp);

return;
}

/*--> LoadGame: load a game from a file */
static
void
LoadGame(char fname[tL])
{
FILE *fp;
int c;
siT sq;
usiT m;

if (fname[0] == '\0')
	strcpy(fname, fn_sav);

if ((fp = fopen(fname, "r")) != NULL)
	{
	fscanf(fp, "%hd%hd", &castld[white], &castld[black]);
	fscanf(fp, "%hd%hd", &kingmoved[white], &kingmoved[black]);

	for (sq = 0; sq < sqL; sq++)
		{
		fscanf(fp, "%hd", &m);
		board[sq] = (m >> byteW);
		color[sq] = (m & byteM);
		};

	GameCnt = -1;
	c = '?';

	while (c != EOF)
		c = fscanf(fp, "%hd%hd%hd%hd",
			&GameList[++GameCnt], &GameScore[GameCnt],
			&GamePc[GameCnt], &GameClr[GameCnt]);

	fclose(fp);
	};

return;
}

/*--> Command: handle command input */
static
void
Command(void)
{
sqT frsq, tosq;
siT ok, i;
char s[tL], fname[tL];
FILE *fp;

ok = quit = 0;
while (!(ok || quit))
	{
	ReadLine("Your move is? ", s);
	player = opponent;
	VerifyMove(s, &ok);

	if (strcmp(s, "both") == 0)
		{
		bothsides = !bothsides;
		SelectMove(opponent);
		ok = 1;
		};

	if (strcmp(s, "go") == 0)
		ok = 1;

	if (strcmp(s, "help") == 0)
		Help();

	if (strcmp(s, "hint") == 0)
		{
		Coordinate(prvar[2] >> byteW, prvar[2] & byteM);
		printf("try %s\n", mvstr1);
		};

	if (strcmp(s, "list") == 0)
		{
		if ((fp = fopen(fn_lst, "w")) == NULL)
			{
			fprintf(stderr, "Can't open list output file: %s\n", fn_lst);
			exit(1);
			};

		for (i = 0; i <= GameCnt; i++)
			{
			frsq = GameList[i] >> byteW;
			tosq = GameList[i] & byteM;
			Coordinate(frsq, tosq);
			if ((i % 2) == 0) fprintf(fp, "\n");
				fprintf(fp, " %5s  %6d     ", mvstr1, GameScore[i]);
			};

		fprintf(fp, "\n");
		fclose(fp);
		};

	if (strcmp(s, "load") == 0)
		{
		ReadLine("file name?  ", fname);
		LoadGame(fname);
		InitializeStats();
		PrintBoard();
		};

	if (strcmp(s, "new") == 0)
		NewGame();

	if (strcmp(s, "post") == 0)
		post = !post;

	if (strcmp(s, "quit") == 0)
		quit = 1;

	if (strcmp(s, "redraw") == 0)
		PrintBoard();

	if (strcmp(s, "reverse") == 0)
		{
		reverse = !reverse;
		PrintBoard();
		};

	if (strcmp(s, "save") == 0)
		{
		ReadLine("file name?  ", fname);
		SaveGame(fname);
		};

	if (strcmp(s, "set") == 0)
		SetBoard();

	if (strcmp(s, "switch") == 0)
		{
		computer = otherside[computer];
		opponent = otherside[opponent];
		ok = 1;
		};

	if (strcmp(s, "time") == 0)
		{
		ReadLine("enter time:  ", fname);
		response_time = atoi(fname);
		};

	if (strcmp(s, "undo") == 0 && (GameCnt > 0))
		{
		frsq = GameList[GameCnt] >> byteW;
		tosq = GameList[GameCnt] & byteM;

		board[frsq] = board[tosq];
		color[frsq] = color[tosq];

		board[tosq] = GamePc[GameCnt];
		color[tosq] = GameClr[GameCnt];

		GameCnt--;
		PrintBoard();
		InitializeStats();
		};
	};

ElapsedTime(1);

return;
}

/*--> main: main routine for standalone SCP */
nonstatic
int
main(int argc, charptrT argv[])
{
InitProgram();

while (!quit)
	{
	if (bothsides && !mate)
		SelectMove(opponent);
	else
		Command();

	if (!quit && !mate)
		SelectMove(computer);
	};

return (0);
}

/*<<< scpmain.c: EOF */
