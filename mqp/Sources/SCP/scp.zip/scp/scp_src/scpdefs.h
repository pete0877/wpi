/*>>> scpdefs.h: global definitions for the scp project */

/* Revised: 1993.03.15 */

/* the true NULL */

#ifdef NULL
#undef NULL
#endif
#define NULL ((void *) 0)

/* the antonym of "static" functions */

#define nonstatic

/* handy types for portability */

typedef short int siT, *siptrT;
typedef unsigned short int usiT, *usiptrT;
typedef long int liT, *liptrT;
typedef unsigned long int uliT, *uliptrT;
typedef void *voidptrT;
typedef char *charptrT;
typedef unsigned char byteT, *byteptrT;
typedef unsigned long int allocT;

/* useful constants */

#define bit 0x01

#define byteW 8
#define siW (2 * byteW)
#define liW (4 * byteW)

#define byteM 0x00ff

/* general text line buffer limit */

#define tL 256

/* seconds */

typedef liT secT;

/* chess definitions */

#define sidesL 3

#define piecesL 7

typedef siT fileT;
#define fileL 8
#define file_nil (-1)

#define file_a 0
#define file_b 1
#define file_c 2
#define file_d 3
#define file_e 4
#define file_f 5
#define file_g 6
#define file_h 7

typedef siT rankT;
#define rankL 8
#define rank_nil (-1)

#define rank_1 0
#define rank_2 1
#define rank_3 2
#define rank_4 3
#define rank_5 4
#define rank_6 5
#define rank_7 6
#define rank_8 7

#define MapRankFile(rank, file) (((rank) * fileL) + (file))

typedef siT sqT, *sqptrT;
#define sqL (rankL * fileL)
#define sq_nil (-1)

#define sq_a1 MapRankFile(rank_1, file_a)
#define sq_b1 MapRankFile(rank_1, file_b)
#define sq_c1 MapRankFile(rank_1, file_c)
#define sq_d1 MapRankFile(rank_1, file_d)
#define sq_e1 MapRankFile(rank_1, file_e)
#define sq_f1 MapRankFile(rank_1, file_f)
#define sq_g1 MapRankFile(rank_1, file_g)
#define sq_h1 MapRankFile(rank_1, file_h)

#define sq_a2 MapRankFile(rank_2, file_a)
#define sq_b2 MapRankFile(rank_2, file_b)
#define sq_c2 MapRankFile(rank_2, file_c)
#define sq_d2 MapRankFile(rank_2, file_d)
#define sq_e2 MapRankFile(rank_2, file_e)
#define sq_f2 MapRankFile(rank_2, file_f)
#define sq_g2 MapRankFile(rank_2, file_g)
#define sq_h2 MapRankFile(rank_2, file_h)

#define sq_a3 MapRankFile(rank_3, file_a)
#define sq_b3 MapRankFile(rank_3, file_b)
#define sq_c3 MapRankFile(rank_3, file_c)
#define sq_d3 MapRankFile(rank_3, file_d)
#define sq_e3 MapRankFile(rank_3, file_e)
#define sq_f3 MapRankFile(rank_3, file_f)
#define sq_g3 MapRankFile(rank_3, file_g)
#define sq_h3 MapRankFile(rank_3, file_h)

#define sq_a4 MapRankFile(rank_4, file_a)
#define sq_b4 MapRankFile(rank_4, file_b)
#define sq_c4 MapRankFile(rank_4, file_c)
#define sq_d4 MapRankFile(rank_4, file_d)
#define sq_e4 MapRankFile(rank_4, file_e)
#define sq_f4 MapRankFile(rank_4, file_f)
#define sq_g4 MapRankFile(rank_4, file_g)
#define sq_h4 MapRankFile(rank_4, file_h)

#define sq_a5 MapRankFile(rank_5, file_a)
#define sq_b5 MapRankFile(rank_5, file_b)
#define sq_c5 MapRankFile(rank_5, file_c)
#define sq_d5 MapRankFile(rank_5, file_d)
#define sq_e5 MapRankFile(rank_5, file_e)
#define sq_f5 MapRankFile(rank_5, file_f)
#define sq_g5 MapRankFile(rank_5, file_g)
#define sq_h5 MapRankFile(rank_5, file_h)

#define sq_a6 MapRankFile(rank_6, file_a)
#define sq_b6 MapRankFile(rank_6, file_b)
#define sq_c6 MapRankFile(rank_6, file_c)
#define sq_d6 MapRankFile(rank_6, file_d)
#define sq_e6 MapRankFile(rank_6, file_e)
#define sq_f6 MapRankFile(rank_6, file_f)
#define sq_g6 MapRankFile(rank_6, file_g)
#define sq_h6 MapRankFile(rank_6, file_h)

#define sq_a7 MapRankFile(rank_7, file_a)
#define sq_b7 MapRankFile(rank_7, file_b)
#define sq_c7 MapRankFile(rank_7, file_c)
#define sq_d7 MapRankFile(rank_7, file_d)
#define sq_e7 MapRankFile(rank_7, file_e)
#define sq_f7 MapRankFile(rank_7, file_f)
#define sq_g7 MapRankFile(rank_7, file_g)
#define sq_h7 MapRankFile(rank_7, file_h)

#define sq_a8 MapRankFile(rank_8, file_a)
#define sq_b8 MapRankFile(rank_8, file_b)
#define sq_c8 MapRankFile(rank_8, file_c)
#define sq_d8 MapRankFile(rank_8, file_d)
#define sq_e8 MapRankFile(rank_8, file_e)
#define sq_f8 MapRankFile(rank_8, file_f)
#define sq_g8 MapRankFile(rank_8, file_g)
#define sq_h8 MapRankFile(rank_8, file_h)

/* extended board items */

#define marginL 2
#define xfileL (marginL + fileL + marginL)
#define xrankL (marginL + rankL + marginL)
#define xsqL (xrankL * xfileL)

typedef siT xsqT;
typedef siT xrankT;
typedef siT xfileT;

/* centipawn unit evaluations */

typedef siT cpevT, *cpevptrT;

/* search items */

#define plyL 30

#define treeL 2000

#define gameL 240

#define default_timeL 360

#define pmaxL (fileL * 2)

/* opening book */

#define bklinesL 80
#define bkdepthL 24

#define algnotL 6

#define neutral 0
#define white   1
#define black   2

#define vacant 0
#define pawn   1
#define knight 2
#define bishop 3
#define rook   4
#define queen  5
#define king   6

#define capture (bit << 0)
#define check   (bit << 1)
#define draw    (bit << 2)
#define incheck (bit << 3)
#define epmask  (bit << 4)
#define exact   (bit << 5)
#define promote (bit << 6)
#define pwnthrt (bit << 7)

typedef struct leafS
	{
	siT   frsq;
	siT   tosq;
	cpevT score;
	siT   reply;
	usiT  flags;
	} leafT, *leafptrT;

/*<<< scpdefs.h: EOF */
