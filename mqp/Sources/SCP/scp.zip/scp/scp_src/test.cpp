#include <time.h>
#include <sys/time.h>  
#include <sys/timeb.h>  
#include <unistd.h>
#include <iostream.h>
#include <unistd.h> 
#include <stdlib.h>

double getutime(void)
{
	double curtime;
	struct timeval tm;
	struct timezone tz;
	gettimeofday(&tm,&tz);
	curtime = (tm.tv_sec * 1000.0) + (tm.tv_usec / 1000.0);
	return(curtime);
}

main () {
	int a;
	double t1,t2;
	do {
		t1 = getutime();
		usleep(5000);
		t2 = getutime();
		cout << "\n" << t2 - t1 << "   ";
		cin >> a;
	} while (1);
}



