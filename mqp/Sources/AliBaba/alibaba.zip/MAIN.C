/*----------------------------------------------------------------------
 | MAIN.C							940420
 |
 | Contains the main program.
 +----------------------------------------------------------------------*/


#include "var.h"


/*----------------------------------------------------------------------
 | Main program							940420
 +----------------------------------------------------------------------*/
void main( int argc, char *argv[] )
{
  char		command[ MaxCommandLength ];

  printf( "\n%s, (c) D.M. Breuker\n", version );
  if (sizeof( Unsigned1 ) != 1) {
    printf( "ERROR: (Un)signed1: %d\n", sizeof( Unsigned1 ) );
    exit( 0 );
  }
  if (sizeof( Unsigned2 ) != 2) {
    printf( "ERROR: (Un)signed2: %d\n", sizeof( Unsigned2 ) );
    exit( 0 );
  }
  if (sizeof( Unsigned4 ) != 4) {
    printf( "ERROR: (Un)signed4: %d\n", sizeof( Unsigned4 ) );
    exit( 0 );
  }
  Init();
  if (hashValue[ 0 ][ 0 ] != StartPositionHash) {
    printf( "WARNING: hash %lx != %lx\n", hashValue[ 0 ][ 0 ], StartPositionHash );
    printf( "Results will be somewhat different from published results\n" );
  }
  interActive = True;
  TestArguments( argc, argv );
  if (interActive) {
    for (Ever) {
      printf( "\n>" );
      command[ 0 ] = '\0';
      gets( command );
      if (InterpretCommand( command )) {
        break;
      }
    }
  }
  PrintAllocVariables();
} /* main */
