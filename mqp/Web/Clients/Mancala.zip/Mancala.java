/*
	A basic Java class stub for a Win32 Console Application.
 */

import java.net.*;
import java.io.*;
import java.util.*;

public class Mancala {
   
	public Mancala () {}

    static String readString(DataInputStream in) {
  
        int messageIndex = 0;
		char[] message = new char[4096];
		String result = new String("");
		try
		{
			do {
                message[messageIndex] = (char)in.readByte();
            } while(((int)message[messageIndex] != 0) && (++messageIndex < 4095));
			result = new String(message, 0, messageIndex);   
		} catch (Exception e) {}
		return result;
     }

    static public void main(String args[]) {
        Board mb = new Board();
        mb.reset();
        try {
            System.out.println("");
            OutputStream    outStr;
            DataInputStream inStr;
            String          s;
            Socket          socket;
            
        
            System.out.print("\n\nEnter Mancala server: ");
            DataInputStream keys    = new DataInputStream(System.in);                                        
            String ard = "";
            try {		            
		        ard = keys.readLine();	               
            } catch (Exception e) {}
            
            System.out.print("\n\nEnter eval time limit in sec: ");
            keys    = new DataInputStream(System.in);                                        
            String time_limit = "";
            try {		            
		        time_limit = keys.readLine();	               
            } catch (Exception e) {}            
            
            System.out.print("\n\nEnter ply: ");
            keys  = new DataInputStream(System.in);                                        
            String wanted_ply = "";
            try {		            
		        wanted_ply = keys.readLine();	               
            } catch (Exception e) {}                        
        
            socket = new Socket(ard, 23);
            outStr  = socket.getOutputStream();
            inStr   = new DataInputStream(socket.getInputStream());            
            
            s = readString(inStr);
            System.out.println(s);
            s = readString(inStr);
            System.out.println(s);
            
            s = "CLIENT_ENCODING";        
            outStr.write(s.getBytes());
            outStr.write(0);
            
            s = "MANCALA";        
            outStr.write(s.getBytes());
            outStr.write(0);
            
            s = readString(inStr);
            System.out.println(s);
            s = readString(inStr);
            System.out.println(s);            
            s = readString(inStr);
            System.out.println(s);
            s = readString(inStr);
            System.out.println(s);
            s = readString(inStr);
            System.out.println(s);
            
            s = "CLIENT_GAMETYPE";        
            outStr.write(s.getBytes());
            outStr.write(0);            
            
            s = "0";        
            outStr.write(s.getBytes());
            outStr.write(0);            
            
            s = "CLIENT_PLY";        
            outStr.write(s.getBytes());
            outStr.write(0);
            
            s = wanted_ply;        
            outStr.write(s.getBytes());
            outStr.write(0);
            
            s = "CLIENT_EVALTIME";        
            outStr.write(s.getBytes());
            outStr.write(0);
            
            s = time_limit;        
            outStr.write(s.getBytes());
            outStr.write(0);            
            
            s = readString(inStr);
            System.out.println(s);
            
            int number=1;
            byte[] message = new byte[4096];            
            String result = new String("");
            
            String stmp = "";
            boolean again;
            Integer i;
            while (!stmp.equals("0")) {           
                do {
                    mb.displayBoard();                            
                    System.out.print("\n\nEnter your move (1..6, 0=quit): ");
                
                    stmp = "";
		            try {		            
    		            stmp = keys.readLine();	               
	    	        } catch (Exception e) {}
		        
		            if (stmp.equals("0")) throw new Exception();		            		            
		            result = stmp;
    		        i = new Integer(stmp);    		        
                    again = mb.makeMove(i.intValue() + 2);
                    if (mb.isOver()) {                        
                        System.out.println("\n\n GAME OVER.");
                        throw new Exception();
                    }
                } while (again);
		        mb.displayBoard();            
		        System.out.print("\nPlease wait ... ");		            
                
                s = "CLIENT_GAMESTATE";        
                outStr.write(s.getBytes());
                outStr.write(0);
                    
                    
                s = mb.getBoard();
                outStr.write(s.getBytes());
                outStr.write(0);   
                                  
                s = readString(inStr);
                s = readString(inStr);
                s = readString(inStr);
                s = readString(inStr);                
                s = readString(inStr);       
                
                System.out.print("\nCOMPUTER'S MOVE: "); 
                StringTokenizer t = new StringTokenizer(s, ",");
                while (t.hasMoreElements()) {
                    String ss = (String) t.nextElement();
                    i = new Integer(ss);
                    Integer boardRef = new Integer(i.intValue() - 8);                    
                    System.out.print(boardRef.toString() + "  ");
                    mb.makeMove(i.intValue());   
                    if (mb.isOver()) {
                        mb.displayBoard();
                        System.out.println("\n\n GAME OVER.");
                        throw new Exception();
                    }
                }
                
                s = readString(inStr);                    
                s = readString(inStr);                    
            }
           
            socket.close();
        } catch (Exception e) {
            System.out.println("\n\n SERVER DISCONNECTED.");
        }
        mb.displayBoard();    
    }
    


	//{{DECLARE_CONTROLS
	//}}
}

