// COMLoadTester.cpp : Implementation of CCOMLoadTester
#include "stdafx.h"
#include "LTServer.h"
#include "COMLoadTester.h"

/////////////////////////////////////////////////////////////////////////////
// CCOMLoadTester


STDMETHODIMP CCOMLoadTester::goToSleep(int time)
{		
	Sleep(time);
	return S_OK;
}
