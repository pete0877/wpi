/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Feb 28 15:02:02 2000
 */
/* Compiler settings for E:\LoadTester\LTServer\LTServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ICOMLoadTester = {0x6D1C5A30,0xEE17,0x11D3,{0x91,0xEB,0x00,0x40,0x95,0x10,0x00,0x85}};


const IID LIBID_LTSERVERLib = {0x6D1C5A24,0xEE17,0x11D3,{0x91,0xEB,0x00,0x40,0x95,0x10,0x00,0x85}};


const CLSID CLSID_COMLoadTester = {0x6D1C5A31,0xEE17,0x11D3,{0x91,0xEB,0x00,0x40,0x95,0x10,0x00,0x85}};


#ifdef __cplusplus
}
#endif

