// COMLoadTester.h : Declaration of the CCOMLoadTester

#ifndef __COMLOADTESTER_H_
#define __COMLOADTESTER_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCOMLoadTester
class ATL_NO_VTABLE CCOMLoadTester : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CCOMLoadTester, &CLSID_COMLoadTester>,
	public ICOMLoadTester
{
public:
	CCOMLoadTester()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_COMLOADTESTER)
DECLARE_NOT_AGGREGATABLE(CCOMLoadTester)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCOMLoadTester)
	COM_INTERFACE_ENTRY(ICOMLoadTester)
END_COM_MAP()

// ICOMLoadTester
public:
	STDMETHOD(goToSleep)(int time);
};

#endif //__COMLOADTESTER_H_
