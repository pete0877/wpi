// LTClientDlg.h : header file
//

#if !defined(AFX_LTCLIENTDLG_H__6D1C5A39_EE17_11D3_91EB_004095100085__INCLUDED_)
#define AFX_LTCLIENTDLG_H__6D1C5A39_EE17_11D3_91EB_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "StringTool.h"

/////////////////////////////////////////////////////////////////////////////
// CLTClientDlg dialog

class CLTClientDlg : public CDialog
{
// Construction
public:
	CLTClientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLTClientDlg)
	enum { IDD = IDD_LTCLIENT_DIALOG };
	int		m_count;
	CString	m_server;
	int		m_time;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLTClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void SetCurrent(int a);
	HICON m_hIcon;
	static UINT CallThread(LPVOID pParam);

	// Generated message map functions
	//{{AFX_MSG(CLTClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	afx_msg void OnChangeTime();
	afx_msg void OnChangeServer();
	afx_msg void OnChangeCount();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LTCLIENTDLG_H__6D1C5A39_EE17_11D3_91EB_004095100085__INCLUDED_)
