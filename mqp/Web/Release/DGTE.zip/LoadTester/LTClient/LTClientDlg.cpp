// LTClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LTClient.h"
#include "LTClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "..\LTServer\LTServer_i.c"
#include "..\LTServer\LTServer.h"
#include <comdef.h>

typedef struct tagThreadParams {
	CSemaphore*			lock;
	int*				tCount;
	ICOMLoadTester*		COMObject;
	int					m_time;
} ThreadParams;


/////////////////////////////////////////////////////////////////////////////
// CLTClientDlg dialog

CLTClientDlg::CLTClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLTClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLTClientDlg)
	m_count = 50;
	m_server = _T("localhost");
	m_time = 20000;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLTClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLTClientDlg)
	DDX_Text(pDX, IDC_COUNT, m_count);
	DDV_MinMaxInt(pDX, m_count, 1, 100000);
	DDX_Text(pDX, IDC_SERVER, m_server);
	DDX_Text(pDX, IDC_TIME, m_time);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLTClientDlg, CDialog)
	//{{AFX_MSG_MAP(CLTClientDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_EN_CHANGE(IDC_TIME, OnChangeTime)
	ON_EN_CHANGE(IDC_SERVER, OnChangeServer)
	ON_EN_CHANGE(IDC_COUNT, OnChangeCount)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLTClientDlg message handlers

BOOL CLTClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLTClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CLTClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

UINT CLTClientDlg::CallThread(LPVOID pParam) {
	ThreadParams*		params		= (ThreadParams*) pParam;
	CSemaphore*			lock		= params->lock;
	int*				tCount		= params->tCount;
	int					m_time		= params->m_time;
	ICOMLoadTester*		COMObject	= params->COMObject;
	delete params;

	HRESULT hRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);
	if (FAILED(hRes))
	{
		_com_error e(hRes);
		AfxMessageBox(e.ErrorMessage());			
		return (UINT)0;
	}

	hRes = COMObject->goToSleep(m_time);
	if (FAILED(hRes))
	{
		_com_error e(hRes);
		AfxMessageBox(e.ErrorMessage());			
		return (UINT)0;
	}

	lock->Lock();
	*tCount = *tCount - 1;
	lock->Unlock();

	CoUninitialize();
	return (UINT)0;
}

void CLTClientDlg::OnStart() 
{
	// initialize com stuff:
	ICOMLoadTester* COMObject;
	vector<ICOMLoadTester*> vpCOMObjects;
	HRESULT hr;
	
	COSERVERINFO cs;
	memset(&cs, 0, sizeof(cs));
	cs.pwszName = _bstr_t(_T(m_server.GetBuffer(0))); 
 
	MULTI_QI qi[1];

	// create pointers
	for (int a=0; a<m_count; a++) {
		memset(qi, 0, sizeof(qi)); 
		qi[0].pIID = &IID_ICOMLoadTester;
		hr = CoCreateInstanceEx(CLSID_COMLoadTester, NULL, CLSCTX_SERVER, &cs, 1, qi);

		if( FAILED(hr) ) {
			_com_error e(hr);
			AfxMessageBox(e.ErrorMessage());	
			// TODO: RELEASE AQUIRED POINTERS
			return;
		}
		COMObject = (ICOMLoadTester*) qi[0].pItf;	
		vpCOMObjects.push_back(COMObject);
	}
	AfxMessageBox("Collected all object pointers. Ready to load!");

	// create all threads and make calls
	CSemaphore* lock = new CSemaphore();
	int tCount = m_count;
	for (a=0; a<m_count; a++) {
		COMObject = vpCOMObjects[a];
		ThreadParams* params = new ThreadParams;
		params->COMObject = COMObject;
		params->tCount	  = &tCount;
		params->lock	  = lock;
		params->m_time	  = m_time;
		AfxBeginThread(CallThread, (LPVOID) params);
	}

	// wait till all are done
	int checkDelay = 100;
	int screenRefresh = 500;
	bool keepwaiting = true;
	int c = 0;
	do {
		Sleep(checkDelay); // sleep 50 msec
		lock->Lock();
		if (tCount == 0) keepwaiting = false;		
		lock->Unlock();		
		if (c == (screenRefresh / checkDelay)) {
			// update the view every sec
			SetCurrent(tCount);
			c = 0;
		} else c++;
	} while (keepwaiting);  
	SetCurrent(0);
	AfxMessageBox("All calls came back");
	delete lock;
	
	// release pointers:
	for (a=0; a<m_count; a++) {
		COMObject = vpCOMObjects[a];
		COMObject->Release();
	}	
	AfxMessageBox("All pointers returned. We are done.");

}

void CLTClientDlg::OnChangeTime() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_TIME);
	textbox->GetWindowText(s);			
	try {
		m_time = s.toLong();	
	} catch (CException* e) {
		e->Delete();
		m_time = 0;
		textbox->SetWindowText("0");			
	}
}

void CLTClientDlg::OnChangeServer() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_SERVER);
	textbox->GetWindowText(s);		
	// this->m_time_limit = s.toLong();
	m_server = s;
}

void CLTClientDlg::OnChangeCount() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_COUNT);
	textbox->GetWindowText(s);			 
	try {
		m_count = s.toLong();	
	} catch (CException* e) {
		e->Delete();
		m_count = 0;
		textbox->SetWindowText("0");			
	}

}

void CLTClientDlg::SetCurrent(int a)
{
	char tmp[50];
	sprintf(tmp, "%d", a);
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_THREADS);
	textbox->SetWindowText(tmp);			
	RedrawWindow();
	
}
