/*     CONTENT: implementation of class GameServerConfiguration
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "GameServerConfiguration.h"
#include <afx.h>
#include "StringTool.h"

GameServerConfiguration::GameServerConfiguration()
{
	port					= 0;
    serverName				= "";
    serverDescription		= "";
	serverOwner				= "";
	maxClients				= 0;
	maxDecisionTime			= 0;
	maxGamePly				= 0;
}

GameServerConfiguration::GameServerConfiguration(const GameServerConfiguration& new_gameserverconfiguration)
{
	port					= new_gameserverconfiguration.port;
    serverName				= new_gameserverconfiguration.serverName;
    serverDescription		= new_gameserverconfiguration.serverDescription;
	serverOwner				= new_gameserverconfiguration.serverOwner;
	maxClients				= new_gameserverconfiguration.maxClients;
	maxDecisionTime			= new_gameserverconfiguration.maxDecisionTime;
	maxGamePly				= new_gameserverconfiguration.maxGamePly;
}

int GameServerConfiguration::getPort()
{
    return port;
}

void GameServerConfiguration::setPort(int new_port)
{
	port = new_port;
}

CString GameServerConfiguration::getServerName()
{
	return this->serverName;
}

void GameServerConfiguration::setServerName(const CString& new_servername)
{
	this->serverName = new_servername;
}

CString GameServerConfiguration::getServerDescription()
{	
	return this->serverDescription;
}

void GameServerConfiguration::setServerDescription(const CString& new_serverdescription)
{
	this->serverDescription = new_serverdescription;
}

CString GameServerConfiguration::getServerOwner()
{
	return this->serverOwner;
}

void GameServerConfiguration::setServerOwner(const CString& new_serverowner)
{
	this->serverOwner = new_serverowner;
}

int GameServerConfiguration::getMaxClients() 
{
	return this->maxClients;
}

void GameServerConfiguration::setMaxClients(int new_max) 
{
	this->maxClients = new_max;
}


long GameServerConfiguration::getMaxDecisionTime() 
{
	return this->maxDecisionTime;
}

void GameServerConfiguration::setMaxDecisionTime(long new_max) 
{
	this->maxDecisionTime = new_max;
}

int GameServerConfiguration::getMaxGamePly() 
{
	return this->maxGamePly;
}

void GameServerConfiguration::setMaxGamePly(int new_max) 
{
	this->maxGamePly = new_max;
}

CString GameServerConfiguration::getWelcomeMessage()
{
	CString result = "";
	result = result + "SERVER NAME: " + this->serverName + "\n";
	result = result + "OWNER      : " + this->serverOwner + "\n";
	result = result + "DESCRIPTION: " + this->serverDescription + "\n";
	return result;
}

void GameServerConfiguration::save()
{
	CFile f;
	f.Open("server.cfg", CFile::modeWrite | CFile::modeCreate);
	char tmp[500];

	strcpy(tmp,serverName.GetBuffer(0));
	f.Write((const void *) tmp, 500);

	strcpy(tmp,serverDescription.GetBuffer(0));
	f.Write((const void *) tmp, 500);

	strcpy(tmp,serverOwner.GetBuffer(0));
	f.Write((const void *) tmp, 500);

	sprintf(tmp,"%d",port);
	f.Write((const void *) tmp, 500);
	
	sprintf(tmp,"%d",maxClients);
	f.Write((const void *) tmp, 500);

	sprintf(tmp,"%d",maxDecisionTime);
	f.Write((const void *) tmp, 500);

	sprintf(tmp,"%d",maxGamePly);
	f.Write((const void *) tmp, 500);

	f.Close();
}

void GameServerConfiguration::load()
{
	StringTool s;

	CFile f;
	if(!f.Open("server.cfg", CFile::modeRead)) return;
	char tmp[500];

	f.Read((void *) tmp, 500);
	serverName = tmp;

	f.Read((void *) tmp, 500);
	serverDescription = tmp;

	f.Read((void *) tmp, 500);
	serverOwner = tmp;

	f.Read((void *) tmp, 500);
	s.set((char*) tmp);
	try { port = s.toLong(); } 
	catch (CException* e) { e->Delete(); }
	

	f.Read((void *) tmp, 500);
	s.set((char*) tmp);
	try { maxClients = s.toLong(); } 
	catch (CException* e) { e->Delete(); }	

	f.Read((void *) tmp, 500);
	s.set((char*) tmp);
	try { maxDecisionTime = s.toLong(); } 
	catch (CException* e) { e->Delete(); }	

	f.Read((void *) tmp, 500);
	s.set((char*) tmp);
	maxGamePly = s.toLong();

	f.Close();
}

const GameServerConfiguration& GameServerConfiguration::operator=(const GameServerConfiguration& new_gameserverconfiguration) 
{
	port					= new_gameserverconfiguration.port;
    serverName				= new_gameserverconfiguration.serverName;
    serverDescription		= new_gameserverconfiguration.serverDescription;
	serverOwner				= new_gameserverconfiguration.serverOwner;
	maxClients				= new_gameserverconfiguration.maxClients;
	maxDecisionTime			= new_gameserverconfiguration.maxDecisionTime;
	maxGamePly				= new_gameserverconfiguration.maxGamePly;
	return *this;
}
