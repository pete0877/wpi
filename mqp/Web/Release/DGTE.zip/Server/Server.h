/*     CONTENT: definition of class Server
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(AFX_SERVER_H__2CE3C47E_A77B_11D3_90F1_004095100085__INCLUDED_)
#define AFX_SERVER_H__2CE3C47E_A77B_11D3_90F1_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "..\Idl\Types.h"
#include "..\Idl\Server_i.h"
#include "GameServer.h"
#include "AboutDlg.h"

/*
 * This is the application class.
 *
 */
class CServerApp : public CWinApp {
public:
	BOOL OnIdle( LONG lCount );

	GameServer* getGameServer();
	CServerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CServerApp)
	afx_msg void OnAppAbout();
	afx_msg void OnToolsOptions();
	afx_msg void OnToolsStatistics();
	afx_msg void OnServerStart();
	afx_msg void OnServerStop();
	afx_msg LRESULT OnRefreshing(WPARAM p0, LPARAM p1);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL			m_bATLInited;
	GameServer*		gameserver;
private:
	BOOL InitATL();
};





/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVER_H__2CE3C47E_A77B_11D3_90F1_004095100085__INCLUDED_)

extern CServerApp theApp;

