/*     CONTENT: implementation of class CHelperRegistrar
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "Server.h"
#include "HelperRegistrar.h"
#include "GameServer.h"
#include "Engine.h"
#include "..\Idl\Types.h"

/////////////////////////////////////////////////////////////////////////////
// CHelperRegistrar


STDMETHODIMP CHelperRegistrar::registerHelper(unsigned char *address, GameTypeData data, int maxThreads, HelperSecurity helperSecurity)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	this->engineHelperRegistry->registerHelper(address, data, maxThreads, helperSecurity);
	return S_OK;
}

STDMETHODIMP CHelperRegistrar::unregisterHelper(unsigned char *address)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	this->engineHelperRegistry->unregisterHelper(address);
	return S_OK;
}

CHelperRegistrar::CHelperRegistrar() {
	engineHelperRegistry = theApp.getGameServer()->getEngine()->getHelperRegistry();
}
