/*     CONTENT: implementation of class Engine
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "Engine.h"
#include "GameType.h"
#include "SimpleDateTime.h"
#include "Helper.h"
#include "GameServerExceptions.h"
#include "..\Idl\Types.h"


Engine::Engine()
{
	helperRegistry = new HelperRegistry();
	algorithm = NULL;	
	logContext = NULL;
}

boolean Engine::isGameImplemented(const GameType& gametype)
{	
	return helperRegistry->isGameImplemented(gametype);
}

vector<GameType> Engine::getAllGameTypes()
{
	return helperRegistry->getAllGameTypes();
}


MoveDecision Engine::makeMove(const GameState& gamestate, const GameType& gametype, int ply, SimpleDateTime* deadline)
{	
	if (algorithm==NULL) throw new GameNotSupportedException();
	algorithm->setLogContext(logContext);

	MoveDecision result;		

	vector<Helper*> helperSet = helperRegistry->getHelpers(gametype);
	if (helperSet.size()==0) throw new GameNotSupportedException();
	int a = 0;
	boolean got_decision = false;
	Move* rapidMove;
	Helper* decisionHelper;
	do {
		decisionHelper = helperSet[a];		
		try {
			decisionHelper->makeRapidDesicion(gamestate, &rapidMove);
			// now we know that the decision was made. if rapidMove is NULL, 
			// then we have to evaluate. Otherwise, we simply return the move.
			got_decision = true;
		} catch (HelperDeadException* the_exception) {
			the_exception->Delete();
			a++;
			if (a>=helperSet.size()) {
				// no more supprting helpers
				// so we return the helpers and let the calling module know about
				// the boo-boo:
				helperRegistry->returnHelpers(helperSet);
				throw new GameNotSupportedException();
			}
		} catch (GameOverException* the_exception) {
			// so we return the helpers and let the calling module know about
			// the boo-boo:
			helperRegistry->returnHelpers(helperSet);
			throw the_exception;
		}
	} while (!got_decision);

	// see what has been decided:
	if (rapidMove==NULL) {
		// tree evaluation:
		// create new job semaphore:
		CSemaphore* evaluationJobSem = new CSemaphore();
		evaluationJobSem->Lock();  // reset the counter to 0
		// create the root node:
		GameTreeNode* root = new GameTreeNode();
		root->setPly(ply);
		root->setGameState(gamestate);
		root->setLevel(MAXIMAXING);					
		root->setProcessingSemaphore(evaluationJobSem);
		
		CString logEntry;
		char tmpString[50];

		sprintf(tmpString, "%d", (long) root);
		logEntry = tmpString;
		logEntry = "Created root node: " + logEntry;		
		log (logEntry);

		// right before we start the distribution method,
		// we want to start up all the helpers on performance
		// measuring. We will stop them as soon as we are done
		// with evaluating the tree
		vector<Helper*>::iterator hlp;
		Helper* phlp;
		for (hlp=helperSet.begin(); hlp!=helperSet.end(); hlp++) {
			phlp = *hlp;
			phlp->startPerfMeasuring();
		}
		// span new thread on the distribution algorithm:		
		SimpleDateTime tStart, tEnd;
		tStart.setToNow();
		algorithm->start((GameTreeNode*) root, helperSet, deadline);		

		// wait till the algorithm is done:		
		evaluationJobSem->Lock(); 
		// once we get out of the lock .. we know that no other threads
		// are accessing the tree.
		tEnd.setToNow();

		// stop performance measuring and gather stats
		long nodes_searched = 0;
		float ave_utilization = 0;
		float hlp_utilization = 0;
		float ave_dcomoverhead = 0;
		float ave_nps = 0;
		int	  hlp_count = 0;
		for (hlp=helperSet.begin(); hlp!=helperSet.end(); hlp++) {
			phlp = *hlp;
			phlp->stopPerfMeasuring();
			phlp->lockCacheAdjustment(false);
			if (phlp->getAvailable()) {
				hlp_count++;
				nodes_searched		+= phlp->getTotalNodesSearched();
				ave_nps				+= phlp->getNodesPerSec();
				hlp_utilization      = phlp->getUtilizationTime() / (tEnd - tStart);
				ave_utilization		+= hlp_utilization;
				ave_dcomoverhead	+= phlp->getComOverhead();			
				statsKeeper.reportHelperUtilization(phlp->getAddress().ipAddress, hlp_utilization);
			}
		}
		if (hlp_count==0) {
			ave_dcomoverhead	= 0;
			ave_utilization		= 0;
			ave_nps				= 0;
		} else {
			ave_dcomoverhead	= ave_dcomoverhead / hlp_count;
			ave_utilization		= ave_utilization / hlp_count;
			ave_nps				= ave_nps / hlp_count;
		}

		logEntry = tmpString;
		logEntry = "Finished evaluating root node: " + logEntry;		
		log (logEntry);

		statsKeeper.report(helperSet.size(), tEnd - tStart, nodes_searched, ave_utilization, ave_dcomoverhead, ave_nps);
		

		delete evaluationJobSem;
		// once we get unlocked, we can now try to get the final decision:
		helperRegistry->returnHelpers(helperSet);			
		try {
			// attempt to genereate the resulting move:
			result = root->generateDecision();			
			delete root;
			root = NULL;
		} catch (NodeEvaluationFailedException* the_exception) {
			the_exception->Delete();			
			delete root;
			root = NULL;
			throw new GameNotSupportedException();
		}
		return result;
	} else {
		// rapid move:
		result.pctCompleted = 100;
		result.move = rapidMove->move;
		result.gamestatus = rapidMove->status;	
		if (rapidMove->gamestate.gamestate!=NULL) delete [] rapidMove->gamestate.gamestate;
		if (rapidMove->move!=NULL) delete [] rapidMove->move;
		delete rapidMove;
		helperRegistry->returnHelpers(helperSet);
		return result; 
	}
}


HelperRegistry* Engine::getHelperRegistry() 
{
	return helperRegistry;
}

Engine::~Engine()
{
	delete helperRegistry;
}

void Engine::setDistributionAlgorithm(DistributionAlgorithm *new_algorithm)
{
	algorithm = new_algorithm;
}

DistributionAlgorithm* Engine::getDistributionAlgorithm()
{
	return (DistributionAlgorithm*) algorithm;
}

void Engine::setLogContext(LogContext* new_logContext) {
	logContext = new_logContext;
	helperRegistry->setLogContext(new_logContext);
	algorithm->setLogContext(new_logContext);
	statsKeeper.setLogContext(new_logContext);
}


void Engine::log(CString event) {
	char instanceID[30];
	sprintf(instanceID, "[%d]", (long) this);
	if (logContext!=NULL) logContext->addEntry("ENGINE", instanceID, event);
}
