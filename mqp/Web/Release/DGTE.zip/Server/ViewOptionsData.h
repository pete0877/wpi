#if !defined(AFX_VIEWOPTIONSDATA_H__5B24D284_DDA2_11D3_91B8_004095100085__INCLUDED_)
#define AFX_VIEWOPTIONSDATA_H__5B24D284_DDA2_11D3_91B8_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ViewOptionsData  
{
public:
	CString m_keyword_string;	
	ViewOptionsData();
	virtual ~ViewOptionsData();
	int mode;
	int see_game_server;
	int see_engine;
	int  see_helper_registry;
	int  see_helpers;
	int  see_distributor;
	int  see_stats;
	int  see_keyword;
};

#endif // !defined(AFX_VIEWOPTIONSDATA_H__5B24D284_DDA2_11D3_91B8_004095100085__INCLUDED_)
