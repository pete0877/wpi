/*     CONTENT: definition of class Engine
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(Engine_h)
#define Engine_h

#include "resource.h"
#include "HelperRegistry.h"
#include "MoveDecision.h"
#include "GameType.h"
#include "SimpleDateTime.h"
#include "GameTreeNode.h"
#include "Helper.h"
#include "DistributionAlgorithm.h"
#include "StatsKeeper.h"



/*
 * Engine Class is responsible for providing game decision services
 * for games of various types. It also provides estimation on how
 * long a move desicion might take.
 */

class Engine
{
public:

    /*
     * Engine () - default constructor.
     */
    Engine();

    boolean isGameImplemented(const GameType& gametype);
    /*
     * getAllGameTypes() - returns all game types supported by the
     * Engine.
     */
    vector<GameType> getAllGameTypes();
    /*
     * estimateMoveTime() - returns float value of seconds that the
     * engine would need to come up with the decision move if all
     * resources were free.
     * THROWS:
     *    GameNotSupportedException
     */
    /*
     * makeMove() - returns decision move to a given board setup within
     * certain amount of time.
     * THROWS:
     *    GameNotSupportedException
     *    GameOverException
     */
    MoveDecision makeMove(const GameState& gamestate, const GameType& gametype, int ply, SimpleDateTime* deadline);

	HelperRegistry* getHelperRegistry();

	void setDistributionAlgorithm(DistributionAlgorithm *new_algorithm);

	DistributionAlgorithm* getDistributionAlgorithm();

	void setLogContext(LogContext* new_logContext);

    ~Engine();

protected:
	StatsKeeper					statsKeeper;
	HelperRegistry*				helperRegistry;
	DistributionAlgorithm*		algorithm;
	LogContext*					logContext;
	void						log(CString event);
	

private:


};

#endif /* Engine_h */
