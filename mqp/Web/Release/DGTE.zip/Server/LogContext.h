/*     CONTENT: definition of class LogContext
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(AFX_LOGCONTEXT_H__45BA1D83_B052_11D3_9103_004095100085__INCLUDED_)
#define AFX_LOGCONTEXT_H__45BA1D83_B052_11D3_9103_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/*
 * LogContext defines abstract log-compatible class
 */
class LogContext  
{
public:
	virtual CString	getEntry(long entryNumber)=0;
	virtual long	getSize()=0;
	virtual void	addEntry(CString classID, CString objectID, CString event)=0;
	virtual bool	getHasNewEntries()=0;
	virtual void	setHasNewEntries(bool bFlag)=0;
};

#endif // !defined(AFX_LOGCONTEXT_H__45BA1D83_B052_11D3_9103_004095100085__INCLUDED_)
