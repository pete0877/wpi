/*     CONTENT: definition of class GameServerConfiguration
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(GameServerConfiguration_h)
#define GameServerConfiguration_h

#include "resource.h"
#include <afx.h>

#undef AFX_API
#define AFX_API AFX_EXT_CLASS

/*
 * GameServerConfiguration Class is used to store parameters that
 * customize functionality of the GameServer Class.
 */
class GameServerConfiguration
{
public:

    GameServerConfiguration();
    GameServerConfiguration(const GameServerConfiguration& new_gameserverconfiguration);
    int getPort();
    void setPort(int new_port);
    CString getServerName();
    void setServerName(const CString& new_servername);
    CString getServerDescription();
    void setServerDescription(const CString& new_serverdescription);
    CString getServerOwner();
    void setServerOwner(const CString& new_serverowner);
	int getMaxClients();
    void setMaxClients(int new_max);
	long getMaxDecisionTime();
    void setMaxDecisionTime(long new_max);
	int getMaxGamePly();
    void setMaxGamePly(int new_max);
    CString getWelcomeMessage();
    void save();
    void load();
    const GameServerConfiguration& operator=(const GameServerConfiguration& new_gameserverconfiguration);
    
protected:
    int					port;
    CString				serverName;
    CString				serverDescription;
    CString				serverOwner;
	int					maxClients;
	long				maxDecisionTime;
	int					maxGamePly;
};

#undef AFX_API
#define AFX_API


#endif /* GameServerConfiguration_h */
