/*     CONTENT: definition of various results of moves
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#define MOVEDECISION_CONTINUE 0
#define MOVEDECISION_WIN      1
#define MOVEDECISION_LOOSE    2
#define MOVEDECISION_DRAW     3