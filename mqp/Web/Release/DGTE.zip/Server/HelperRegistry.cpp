/*     CONTENT: implementation of class HelperRegistry
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "HelperRegistry.h"
#include "GameType.h"
#include "InternetAddress.h"
#include "Helper.h"

HelperRegistry::HelperRegistry()
{	
	nextHelperID = 0;
}

vector<Helper*> HelperRegistry::getHelpers(GameType gametype)
{
	helpersListLock.Lock();
	vector<Helper*>				result;	
	vector<Helper*>::iterator	ir;
	vector<int>::iterator		ic;
	Helper*						helper;
	ir = helpers.begin(); 
	ic = refereceCounts.begin();
	while (ir!=helpers.end()   &&   ic!=refereceCounts.end()) {		
		helper = *ir;		
		// grab the helper only if it implements the game type 
		// and is available 
		if ((helper->getGameType()==gametype) && (helper->getAvailable())){
			*ic = *ic + 1;			
			result.push_back(helper);
		}
		ir++;
		ic++;
	}; 
	helpersListLock.Unlock();
    return result;
}

vector<GameType> HelperRegistry::getAllGameTypes()
{
	helpersListLock.Lock();
	vector<GameType> result;	
	GameType gt;
	vector<GameType>::iterator	ig;
	vector<Helper*>::iterator	ir;
	Helper*						helper;
	ir = helpers.begin(); 
	while (ir!=helpers.end()) {		
		helper = *ir;		
		if (helper->getAvailable()) {
			gt = helper->getGameType();
			boolean found = false;
			for (ig = result.begin(); ig != result.end(); ++ig) {				
				if ((*ig)==gt) found = true;
			}
			if (!found) result.push_back(gt);
		}
		ir++;
	}; 
	helpersListLock.Unlock();
	return result;
}

boolean HelperRegistry::isGameImplemented(const GameType& gametype)
{
	helpersListLock.Lock();
	vector<Helper*>::iterator	ir;
	Helper*						helper;
	ir = helpers.begin(); 
	while (ir!=helpers.end()) {		
		helper = *ir;		
		if (helper->getAvailable() && helper->getGameType()==gametype) 
		{
			helpersListLock.Unlock();
			return true;
		}
		ir++;
	}; 
	helpersListLock.Unlock();
	return false;
}

void HelperRegistry::returnHelpers(vector<Helper*> returnedhelpers)
{
	helpersListLock.Lock();
	vector<Helper*>::iterator	ir;
	vector<Helper*>::iterator	ir_ret;
	vector<int>::iterator		ic;
	Helper*						helper;
	Helper*						helper_ret;
	ir_ret = returnedhelpers.begin(); 
	while (ir_ret!=returnedhelpers.end()) {		
		helper_ret = *ir_ret;		
		ir = helpers.begin(); 
		ic = refereceCounts.begin();
		boolean found = false;
		while (ir!=helpers.end()   &&   !found) {		
			helper = *ir;		
			if (helper->getHelperID() == helper_ret->getHelperID()) {
				*ic = *ic - 1;
				found = true;
			}
			ir++;
			ic++;
		}; 
		
		ir_ret++;
	}; 
	helpersListLock.Unlock();
}

HelperRegistry::~HelperRegistry()
{		
	boolean allReturned;		
	vector<Helper*>::iterator	ir;
	vector<int>::iterator		ic;
	Helper*						helper;
	do {
		// repeat this loop until all references are returned:
		helpersListLock.Lock();	
		allReturned = true;
		ic = refereceCounts.begin();		
		while (ic!=refereceCounts.end()) {
			if (*ic != 0) allReturned = false;
			ic++;
		}
		if (allReturned) {
			// all helpers were now returned, so we delete them all:
			ir = helpers.begin(); 			
			while (ir!=helpers.end()) {
				helper = *ir;
				if (helper->getAvailable()) {
					// this helper is still alive, we need to Uninitialize it:
					helper->Uninitialize();
				}
				delete helper;
				ir++;
			}
			refereceCounts.clear();
			helpers.clear();
			helpersListLock.Unlock();
			return;
		}		

		helpersListLock.Unlock();
		::Sleep(100);
	} while(true);
}

typedef struct tagRegThreadParams {
	GameTypeData data;
	char address[200];
	vector<Helper*>*	helpers;
	vector<int>*	refereceCounts;	
	LogContext*     logContext;
	long*			nextHelperID;
	CSemaphore*		helpersListLock;
	int				maxThreads;
	HelperSecurity  helperSecurity;
} RegThreadParams;

UINT HelperRegistry::RegThread(LPVOID pParam) {
	RegThreadParams* params = (RegThreadParams*) pParam;
	GameTypeData data = params->data;
	char the_address[200];
	strcpy(the_address, params->address);	
	vector<Helper*>*	helpers = params->helpers;
	LogContext*			logContext = params->logContext;
	long*				nextHelperID = params->nextHelperID;
	vector<int>*		refereceCounts = params->refereceCounts;
	CSemaphore*			helpersListLock = params->helpersListLock;
	int					maxThreads = params->maxThreads;
	HelperSecurity		helperSecurity = params->helperSecurity;
	delete params;


	helpersListLock->Lock();
	GameType gt(data);	
	int sameHelpers = 1;
	vector<Helper*>::iterator	ir;
	Helper*						some_helper;
	for (ir = helpers->begin(); ir!=helpers->end(); ir++) {
		some_helper = *ir;		
		if (some_helper->getAvailable() && some_helper->getGameType()==gt) sameHelpers++;
	}
	int real_branching = gt.getBranchingFactor();
	// if the branching is too big, we don't want to relase all the threads
	// at once:
	if (real_branching>MAXTHREADSINIT) real_branching = MAXTHREADSINIT;
	int perHelperBranching = (real_branching / sameHelpers) + 1;

	if (maxThreads <= 0) maxThreads = perHelperBranching;
	
	InternetAddress ha;
	strcpy(ha.ipAddress, (char*) the_address);
	Helper* h1 = new Helper();
	h1->setGameType(gt);	
	h1->setHelperID(*nextHelperID);
	*nextHelperID = *nextHelperID + 1;
	h1->setHelperSecurity(helperSecurity);
	h1->setAddress(ha);
	h1->setAvailable(true);
	h1->setLogContext(logContext);
	h1->setMaxThreads(maxThreads);
	h1->lockCacheAdjustment(false);
	if (maxThreads < perHelperBranching) perHelperBranching = maxThreads;
	h1->setDesiredCacheSize(perHelperBranching);
	helpers->push_back(h1);
	refereceCounts->push_back(0);
	helpersListLock->Unlock();

	return (UINT)0;
}

void HelperRegistry::registerHelper(unsigned char *address, GameTypeData data, int maxThreads, HelperSecurity helperSecurity)
{	
	RegThreadParams* params = new RegThreadParams;
	strcpy(params->address, (char*) address);
	params->data	= data;
	params->helpers = &helpers;
	params->refereceCounts = &refereceCounts;
	params->logContext = logContext;
	params->helpersListLock = &helpersListLock;
	params->nextHelperID = &nextHelperID;
	AfxBeginThread(RegThread, (LPVOID) params);
	
	GameType gt(data);
	CString tmpEvent;
	tmpEvent = "Registered helper ";
	tmpEvent = tmpEvent + (char*) address;
	tmpEvent = tmpEvent + " (";
	tmpEvent = tmpEvent + gt.getGameName() + ", " + gt.getGameEncoding() + ")";
	log (tmpEvent);	
}

void HelperRegistry::unregisterHelper(unsigned char *address)
{
	helpersListLock.Lock();
	vector<Helper*>::iterator	ir;
	vector<int>::iterator		ic;
	Helper*						helper;
	CString tmpHelperInfo;
	ir = helpers.begin(); 
	ic = refereceCounts.begin();
	while (ir!=helpers.end()   &&   ic!=refereceCounts.end()) {		
		helper = *ir;		
		if (!strcmp((char*)helper->getAddress().ipAddress,(char*) address)) {
			tmpHelperInfo = helper->getAddress().ipAddress;
			tmpHelperInfo = tmpHelperInfo + " (";
			tmpHelperInfo = tmpHelperInfo + helper->getGameType().getGameName();
			tmpHelperInfo = tmpHelperInfo + ", ";
			tmpHelperInfo = tmpHelperInfo + helper->getGameType().getGameEncoding() + ")";
			helper->setAvailable(false);				
			helper->Uninitialize();
			helpersListLock.Unlock();
			CString tmpEvent = "Unregistered helper " + tmpHelperInfo;
			log (tmpEvent);
			return;
		}
		ir++;
		ic++;
	}; 
	helpersListLock.Unlock();
}

void HelperRegistry::setLogContext(LogContext* new_logContext) {
	vector<Helper*>::iterator	ir;
	Helper*						helper;
	logContext = new_logContext;	
	// do the same for all helpers:
	helpersListLock.Lock();		
	ir = helpers.begin();
	while (ir!=helpers.end()) {		
		helper = *ir;
		helper->setLogContext(new_logContext);
		ir++;
	}	
	helpersListLock.Unlock();
}


void HelperRegistry::log(CString event) {
	char hid[30];
	sprintf(hid, "[%d]", (long) this);
	CString tmp = hid;
	if (logContext!=NULL) logContext->addEntry("HELPER REGISTRY", tmp , event);
}

void HelperRegistry::cleanup()
{
	// this function takes any helpers that are unavailable 
	// and have no references and deletes them from the registry:
	helpersListLock.Lock();
	vector<Helper*>::iterator	ir;
	vector<int>::iterator		ic;
	Helper*						helper;
	ir = helpers.begin(); 
	ic = refereceCounts.begin();
	while (ir!=helpers.end()   &&   ic!=refereceCounts.end()) {		
		helper = *ir;		
		if (!helper->getAvailable() && (*ic==0)) {
			helpers.erase(ir);
			refereceCounts.erase(ic);
		} else {
			ir++;
			ic++;
		}
	}; 
	helpersListLock.Unlock();
}
