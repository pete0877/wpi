/*     CONTENT: implementation of class StatsKeeper
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "Server.h"
#include "StatsKeeper.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

StatsKeeper::StatsKeeper()
{
	logContext = NULL;
	reset();
}

StatsKeeper::~StatsKeeper()
{
	reset();
}

void StatsKeeper::setLogContext(LogContext *new_logContext)
{
	logContext = new_logContext;
}

void StatsKeeper::log(CString event) {
	if (logContext!=NULL) logContext->addEntry("STATS KEEPER", "", event);
}

void StatsKeeper::reset()
{
	start_data_available = false;
	log("Data reset");
}

void StatsKeeper::report(int h, long eval_time, long nodes_searched, float ave_utilization, float ave_dcomoverhead, float ave_nps)
{
	if (h < 1 || h > MAX_HELPERS) return;
	T[h]	= eval_time;
	logStatFunction("Evaluation time", h, eval_time, "msec");
	N[h]	= nodes_searched;
	logStatFunction("Searched nodes", h, nodes_searched, "");
	if (T[h]>0)
		SS[h]	= N[h] / T[h];
	else SS[h]	= -1;
	logStatFunction("Search speed", h, SS[h], "nodes/msec");
	HU[h]	= ave_utilization;
	logStatFunction("Resource utilization", h, ave_utilization * 100, "percent");
	ACO[h]	= ave_dcomoverhead;
	logStatFunction("Ave. communication overhead", h, ave_dcomoverhead, "msec");
	NPS[h]	= ave_nps;
	logStatFunction("Ave. helper performance", h, ave_nps, "nodes/sec");
	if (h == 1) start_data_available = true;
	if (start_data_available) {
		if (T[h]>0)
			S[h] = T[1] / T[h];
		else S[h] = -1;
		logStatFunction("Speed-up", h, S[h], "");
		E[h] = S[h] / h;
		logStatFunction("Relative distribution efficiency", h, E[h] * 100, "percent");
		if (N[1]>0)
			RSO[h] = (N[h] / N[1]) - 1;
		else RSO[h] = 0;
		logStatFunction("Relative search overhead", h, E[h], "");
		if (SS[1]>0)
			SSR[h] = SS[h] / SS[1];
		else SSR[h] = -1;
		logStatFunction("Search speed-up ratio", h, SSR[h], "");
		if (S[h]>0)
			TO[h] = h / S[h] - 1;
		else TO[h] = -1;
		logStatFunction("Total overhead", h, TO[h] * 100, "percent");
	}
}

void StatsKeeper::reportHelperUtilization(CString helper, float utilization) {
	char tmp[255];
	sprintf(tmp, "Helper %s was utilized %.2f percent", helper.GetBuffer(0), utilization * 100);
	log(tmp);
}

void StatsKeeper::logStatFunction(CString name, int index, float value, CString units)
{
	char tmp[255];
	sprintf(tmp, "%s [%d] = %.2f %s", name.GetBuffer(0), index, value, units.GetBuffer(0));
	log(tmp);
}
