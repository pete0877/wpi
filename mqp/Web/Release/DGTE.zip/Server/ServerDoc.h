/*     CONTENT: definition of class ServerDoc
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(AFX_SERVERDOC_H__2CE3C484_A77B_11D3_90F1_004095100085__INCLUDED_)
#define AFX_SERVERDOC_H__2CE3C484_A77B_11D3_90F1_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LogContext.h"

class CServerView;

/*
 * This is the document class.
 *
 */
class CServerDoc : public CDocument, public LogContext
{
protected: // create from serialization only
	bool hasNewEntries;
	CServerDoc();
	vector<CString> entries;
	CSemaphore logLock;
	DECLARE_DYNCREATE(CServerDoc)
	CFile logFile;

// Attributes
public:
	DWORD	appThread;
	HWND	wndHandle;
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

	CString	getEntry(long entryNumber);
	long	getSize();
	void	addEntry(CString classID, CString objectID, CString event);
	bool	getHasNewEntries();
	void	setHasNewEntries(bool bFlag);
	virtual	~CServerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif


protected:
	//{{AFX_MSG(CServerDoc)
	afx_msg void OnClearview();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERDOC_H__2CE3C484_A77B_11D3_90F1_004095100085__INCLUDED_)
