/*     CONTENT: definition of structure InternetAddress
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(InternetAddress_h)
#define InternetAddress_h

/*
 * InternetAddress is used to store the Internet identity of
 * a particular helper. It gathers all the information on would
 * need to contact the helper process on another machine and
 * request one of the services.
 */

#include "resource.h"

typedef struct tagInternetAddress {
    char ipAddress[256];
} InternetAddress;

#endif /* InternetAddress_h */
