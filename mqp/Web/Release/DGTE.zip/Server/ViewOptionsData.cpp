/*     CONTENT: implementation of class ViewOptionsData
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "Server.h"
#include "ViewOptionsData.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ViewOptionsData::ViewOptionsData()
{
	mode				= 0;
	see_game_server		= 1;
	see_engine			= 1;
	see_helper_registry	= 1;
	see_helpers			= 1;
	see_distributor		= 1;
	see_stats			= 1;
	see_keyword			= 0;
}

ViewOptionsData::~ViewOptionsData()
{}
