/*     CONTENT: definition of class StatsKeeper
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(AFX_STATSKEEPER_H__03913733_E2D2_11D3_91CA_004095100085__INCLUDED_)
#define AFX_STATSKEEPER_H__03913733_E2D2_11D3_91CA_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LogContext.h"
#define MAX_HELPERS 30

class StatsKeeper  
{
public:
	void reportHelperUtilization(CString helper, float utilization);	
	void report(int helpers, long eval_time, long nodes_searched, float ave_utilization, float ave_dcomoverhead, float ave_nps);
	void reset();
	void setLogContext(LogContext* new_logContext);
	StatsKeeper();
	virtual ~StatsKeeper();
protected:
	void logStatFunction(CString name, int index, float value, CString units);
	float	T[MAX_HELPERS + 1];		// total evaluation time 
	float	N[MAX_HELPERS + 1];		// number of nodes searched 
	float	S[MAX_HELPERS + 1];		// speedup
	float	E[MAX_HELPERS + 1];		// relative efficiency
	float   HU[MAX_HELPERS + 1];	// helper utilization
	float  RSO[MAX_HELPERS + 1];	// relative search overhead	
	float   SS[MAX_HELPERS + 1];	// search speed	
	float SSR[MAX_HELPERS + 1];		// search speed ratio	
	float TO[MAX_HELPERS + 1];		// total overhead	
	float ACO[MAX_HELPERS + 1];		// average communication overhead
	float NPS[MAX_HELPERS + 1];		// average nodes per second on all helpers
	bool  start_data_available;

	LogContext*		logContext;	
	void log(CString event);
};

#endif // !defined(AFX_STATSKEEPER_H__03913733_E2D2_11D3_91CA_004095100085__INCLUDED_)
