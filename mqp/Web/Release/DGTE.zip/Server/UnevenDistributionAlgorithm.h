/*     CONTENT: definition of class UnevenDistributionAlgorithm
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(AFX_UNEVENDISTRIBUTIONALGORITHM_H__27484E42_AD2A_11D3_90FE_004095100085__INCLUDED_)
#define AFX_UNEVENDISTRIBUTIONALGORITHM_H__27484E42_AD2A_11D3_90FE_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DistributionAlgorithm.h"

class DistributionAlgorithm;

typedef struct tagDistributionAlgorithmParameters {
	GameTreeNode*		node;
	vector<Helper*>		helpers;
	SimpleDateTime*		deadline;
	DistributionAlgorithm*	distributor;
} DistributionAlgorithmParameters;

typedef struct tagHelperAssigmentParameters {
	GameTreeNode*			node;
	Helper*					helper;
	vector<Helper*>			helpers;
	SimpleDateTime*			deadline;
	DistributionAlgorithm*	distributor;
} HelperAssigmentParameters;


class UnevenDistributionAlgorithm : public DistributionAlgorithm  
{
protected:
	LogContext* logContext;
	static UINT run(LPVOID pParam);
	static UINT assignHelper(LPVOID pParam);
public:	
	void log(CString event);
	void start(GameTreeNode* node, vector<Helper*> helpers, SimpleDateTime* deadline);
	void setLogContext(LogContext* new_log);
};

#endif // !defined(AFX_UNEVENDISTRIBUTIONALGORITHM_H__27484E42_AD2A_11D3_90FE_004095100085__INCLUDED_)
