//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Server.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_SERVER                      102
#define IDR_HELPERREGISTRAR             103
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_DISTRITYPE                  129
#define IDD_DIALOG2                     131
#define IDB_ABOUT                       134
#define IDC_HAND                        135
#define IDB_SPLASH                      136
#define IDD_DIALOG1                     137
#define IDC_ABOUT_HYPERLINK             1002
#define IDC_EDIT1                       1004
#define IDC_EDIT2                       1005
#define IDC_EDIT3                       1006
#define IDC_EDIT4                       1007
#define IDC_EDIT5                       1008
#define IDC_CHECK1                      1008
#define IDC_EDIT6                       1009
#define IDC_CHECK2                      1009
#define IDC_EDIT7                       1010
#define IDC_CHECK3                      1010
#define IDC_EDIT8                       1011
#define IDC_CHECK4                      1011
#define IDC_CHECK5                      1012
#define IDC_CHECK9                      1013
#define IDC_EDIT_DOMAIN                 1013
#define IDC_CHECK10                     1014
#define IDC_VERSION                     1016
#define IDC_CHECK6                      1027
#define IDC_CHECK7                      1028
#define ID_TOOLS_OPTIONS                32774
#define ID_BUTTON32775                  32775
#define ID_BUTTON32776                  32776
#define ID_BUTTON32777                  32777
#define ID_BUTTON32778                  32778
#define ID_TOOLS_STATISTICS             32779
#define ID_SERVERSTART                  32780
#define ID_SERVERSTOP                   32781
#define ID_REFRESH                      32782
#define ID_CLEARVIEW                    32783
#define ID_Dummy2                       32784
#define ID_NULL                         32784
#define ID_VIEWOPTIONS                  32785
#define ID_BUTTON32792                  32792
#define ID_BUTTON32793                  32793
#define ID_BUTTON32794                  32794
#define ID_SHOWTREE                     32795
#define ID_SHOWLOG                      32796
#define ID_THREAD_REFRESH               61204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
