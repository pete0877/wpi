/*     CONTENT: definition of class DistributedAlgorithm
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(AFX_DISTRIBUTIONALGORITHM_H__27484E41_AD2A_11D3_90FE_004095100085__INCLUDED_)
#define AFX_DISTRIBUTIONALGORITHM_H__27484E41_AD2A_11D3_90FE_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../Idl/Types.h"
#include "helper.h"
#include "SimpleDateTime.h"
#include "StatsKeeper.h"

/* 
 * This is the generic, abstract description of what any distribution algorithm has to support.
 * 
 */
class DistributionAlgorithm  
{
public:	
	// start() - See the Final Project Report for detials of beheivioral requirements for this method.
	virtual void start(GameTreeNode* node, vector<Helper*> helpers, SimpleDateTime* deadline)=0;
	// setLogContext() - is called by the Engine class to 
	// set the log context for the distributor class.
	// You can use following method to add messages to the 
	// main Server log:
	//  addEntry(CString classID, 
	//		CString objectID, 
	//		CString event)
	// Where, classID should be "Distribution Algorithm"; 
	//	objectID can be the string-equivalent of your
	//	class's this pointer; event is the text message 
	//	you want to log.
	virtual void setLogContext(LogContext* new_log)=0;
	// log() - some of the Server classes might use your
	// distributor class to log their own events and messages.
	// Although you don't have to do this, it's recommended 
	// that you forward these messages to 
	// LogContext ::addEntry() as your own.	
	virtual void log(CString event)=0;
};

#endif // !defined(AFX_DISTRIBUTIONALGORITHM_H__27484E41_AD2A_11D3_90FE_004095100085__INCLUDED_)
