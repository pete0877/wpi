/*     CONTENT: build numbers
 *      AUTHOR: Sebastian Jastrzebski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#ifndef AUTOBUILDCOUNT_H
#define AUTOBUILDCOUNT_H
#define BUILDCOUNT_NUM 95
#define BUILDCOUNT_STR "95"
#endif
