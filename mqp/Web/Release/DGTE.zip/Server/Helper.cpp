/*     CONTENT: implementation of class Helper
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "Helper.h"
#include "GameTreeNode.h"
#include "MoveStatus.h"

#include "..\Idl\Helper_i.h"
#include "..\Idl\Helper_i.c"
#include <comdef.h>
#include "GameServerExceptions.h"

Helper::Helper()
{
	logContext = NULL;	
	available = true;
	currentCacheSize = 0;
	mDesiredLoad = 0;
	desiredCacheSize = 0;
	lockedCacheAdjustment = false;		
	DCOMsleeper = new CSemaphore(1, 10000);
	DCOMsleeper->Lock(); // this makes sure that the thread will not wake up right away
	COMObject = NULL;
}

HelperPerformance Helper::getPerformance()
{	
	return this->performance;
}

void Helper::setPerformance(const HelperPerformance& new_performance)
{
	this->performance = new_performance;
}

InternetAddress Helper::getAddress()
{	
	return address;
}

void Helper::setAddress(const InternetAddress& new_address)
{
	this->address = new_address;
}

GameType Helper::getGameType()
{
	return this->gametype;
}

void Helper::setGameType(const GameType& new_gametype)
{
	this->gametype = new_gametype;
}

bool Helper::getAvailable()
{
	return available;
}

void Helper::setAvailable(bool new_available)
{
	available = new_available;
}

long Helper::getHelperID()
{
    return this->helperID;
}

void Helper::setHelperID(long new_helperid)
{
	this->helperID = new_helperid;
}

int Helper::evaluateBoard(GameTreeNode* node, long timelimit)
{
	if (!available) {		
		throw new HelperDeadException();
		return 1;
	}

	if ((node->getLastMove().status == MOVEDECISION_LOOSE) || (node->getLastMove().status == MOVEDECISION_WIN)) {
		// we don't need to evaluate game states at end of games
		node->setPctCompleted(1);
		return 0;
	}
	
	SimpleDateTime timeBefore, timeAfter;
	timeBefore.setToNow();

	int gameStateSize = this->gametype.getGameStateSize();
	int moveSize	  = this->gametype.getMoveSize();
	int moveListSize  = this->gametype.getMoveListSize();

	// Make the DCom call:
	GameState gs, gs_node;
	gs_node			= node->getGameState();
	gs				= gs_node;
	gs.gamestate	= new unsigned char[gameStateSize];
	strcpy((char *) gs.gamestate, (char *) gs_node.gamestate);
	gs.maxSize		= gameStateSize;
	gs.actualSize	= strlen((char *) gs.gamestate)+1;	;

	// create call parameters:	
	DCOMCallParameters* call_params = new DCOMCallParameters;
	CSemaphore* callsleep = new CSemaphore();
	callsleep->Lock(); // makes sure that we don't wake up right way
	call_params->call_type		= 2; // eval call type
	call_params->call_sleeper	= callsleep;
	call_params->call_gamestate = gs;
	call_params->eval_level		= node->getLevel();
	call_params->eval_ply		= node->getPly();
	call_params->eval_timeout	= timelimit;
	call_params->jobID			= (long) node;

	// lock the DCOM queue and add the call:
	
	// KILL
	// char lpszTmp[500];
	// sprintf(lpszTmp, "Trying to queue node: %d",(long) node);
	// log(lpszTmp);

	DCOMQueueLock.Lock();	
	DCOMcalls.push_back(call_params);
	DCOMQueueLock.Unlock();

	// KILL
	// sprintf(lpszTmp, "Queued node: %d",(long) node);
	// log(lpszTmp);

	// wake up the DCOM thread:
	DCOMsleeper->Unlock();

	// KILL
	// sprintf(lpszTmp, "Queued node: %d and going to sleep",(long) node);
	// log(lpszTmp);

	// and go to sleep yourself:
	callsleep->Lock();

	// at this point our request has been processed by the DCOM thread
	delete callsleep;

	if (call_params->call_result != 0) {
		// error was found while making the call
		performance.setNodesEvaluated(0);
		performance.setNodesEvaluatedPerSecond(0);
		performance.setSpeed(0);
		performance.setOverheadTime(0);
		performance.setPctCompleted(0);
		performance.setSpeed(0);
		performance.setTotalWorkTime(0);
		delete call_params;
		delete gs.gamestate;
		throw new HelperDeadException();
		return 1;
	}

	// calculate and update the performance:
	timeAfter.setToNow();

	char szPerf[500];	
	long turnAround = timeAfter - timeBefore;	
	
	/*
	CString _tmp;
	_tmp = "_started: ";
	_tmp = _tmp + timeBefore.toString();
	log(_tmp);

	_tmp = "_started: ";
	_tmp = _tmp + timeAfter.toString();
	log(_tmp);

	sprintf(szPerf, "_total: %d", turnAround);
	_tmp = szPerf;
	log(szPerf);
	*/

	sprintf(szPerf, "Eval performance: %d npms", (long) call_params->eval_performance.nodesEvaluatedPerSecond);
	log(szPerf);

	this->updatePerformance(call_params->eval_performance, turnAround);
	
	HelperPerformance _perf = this->getPerformance();
	int new_nps = _perf.getSpeed();

	sprintf(szPerf, "Calculated performance: %d npms", new_nps);
	log(szPerf);

	sprintf(szPerf, "Eval completion degree %.2f", call_params->eval_performance.pctCompleted);
	log(szPerf);

	// mark the results:
	node->setQuality(call_params->eval_quality);
	node->setPctCompleted(call_params->eval_performance.pctCompleted);

	delete call_params;
	delete gs.gamestate;

	return 0;
}

int Helper::splitBoard(GameTreeNode* node)
{
	if (!available) {		
		throw new HelperDeadException();
		return 1;
	}

	int gameStateSize = this->gametype.getGameStateSize();
	int moveSize	  = this->gametype.getMoveSize();
	int moveListSize  = this->gametype.getMoveListSize();
	
	Move *moves = new Move[moveListSize];
	for(int i = 0; i < moveListSize; i++) {
		moves[i].maxSize = moveSize;
		moves[i].actualSize = 0;
		moves[i].move = new unsigned char[moveSize];
		moves[i].gamestate.maxSize = gameStateSize;
		moves[i].gamestate.actualSize = 0;
		moves[i].gamestate.gamestate = new unsigned char[gameStateSize];	
	}

	GameState gs, gs_node;
	gs_node			= node->getGameState();
	gs				= gs_node;
	gs.gamestate	= new unsigned char[gameStateSize];
	strcpy((char *) gs.gamestate, (char *) gs_node.gamestate);
	gs.maxSize		= gameStateSize;
	gs.actualSize	= strlen((char *) gs.gamestate)+1;	;

	int actualSize = moveListSize;

	// create call parameters:	
	DCOMCallParameters* call_params = new DCOMCallParameters;
	CSemaphore* callsleep = new CSemaphore();
	callsleep->Lock(); // makes sure that we don't wake up right way
	call_params->call_type		= 1; // split call type
	call_params->call_sleeper	= callsleep;
	call_params->call_gamestate	= gs;
	call_params->split_level		= node->getLevel();
	call_params->split_moves		= moves;
	call_params->split_moveListSize	= moveListSize;
	call_params->split_actualSize	= actualSize;
	call_params->jobID				= (long) node;

	// lock the DCOM queue and add the call:
	DCOMQueueLock.Lock();	
	DCOMcalls.push_back(call_params);
	DCOMQueueLock.Unlock();
	// wake up the DCOM thread:
	DCOMsleeper->Unlock();
	// and go to sleep yourself:
	callsleep->Lock();
	// at this point our request has been processed by the DCOM thread
	delete callsleep;

	// process results:
	if (call_params->call_result != 0) {
		// error was found while making the call
		// delallocate the array of moves:	
		for(i = 0; i < moveListSize; i++) {
			delete moves[i].move;
			delete moves[i].gamestate.gamestate;	
		}
		delete moves;
		delete gs.gamestate;
		delete call_params;	
		available = false;
		// kill all the DCOM threads:
		Uninitialize();
		throw new HelperDeadException();
		return 1;
	}

	moves = call_params->split_moves;
	actualSize = call_params->split_actualSize;

	// make sure that all character arrays end with \0:
	for (int a=0; a<actualSize; a++) {
		moves[a].move[moveSize-1] = '\0';
		moves[a].gamestate.gamestate[gameStateSize-1] = '\0';
	}

	char tmpChar[250];

	// for each move in moves[], create new child node:
	GameTreeNode* tmpNode;
	for (a=0; a<actualSize; a++) {
		// create new node:
		tmpNode = new GameTreeNode();
		sprintf(tmpChar, "Created node: %d: from node: %d", (long) tmpNode, (long) node);		
		log(tmpChar);

		tmpNode->setLastMove(moves[a]); 

		// set the game tree level indicator:
		if (node->getLevel()==MAXIMAXING) tmpNode->setLevel(MINIMAZING); else tmpNode->setLevel(MAXIMAXING); 

		// set the parent node to the same node passed as argument:
		tmpNode->setParentNode(node);

		// play is one smaller then the ply of the parent node:
		tmpNode->setPly(node->getPly()-1);

		node->addChildNode(tmpNode);
	}

	// delallocate the array of moves:	
	for(i = 0; i < moveListSize; i++) {
		delete moves[i].move;
		delete moves[i].gamestate.gamestate;	
	}
	delete moves;
	delete gs.gamestate;
	delete call_params;	

	return 0;
}

int Helper::makeRapidDesicion(const GameState& gamestate, Move** rapid_move)
{
	if (!available) {		
		throw new HelperDeadException();
		return 1;
	}

	// Initiate DCOM:
	int gameStateSize = this->gametype.getGameStateSize();
	int moveSize	  = this->gametype.getMoveSize();
	int moveListSize  = this->gametype.getMoveListSize();
	
	// Make the DCOM call:
	GameState gs;
	gs.gamestate		= new unsigned char[gameStateSize];	
	gs.maxSize			= gameStateSize;	
	strcpy((char *) gs.gamestate, (char *) gamestate.gamestate);
	gs.actualSize		= strlen((char *) gs.gamestate)+1;	

	Move move;
	move.move					= new unsigned char[moveSize];
	move.gamestate.gamestate	= new unsigned char[gameStateSize];
	move.maxSize				= moveSize;
	move.actualSize				= 0;
	move.gamestate.maxSize		= gameStateSize;
	move.gamestate.actualSize	= 0;
	
	int actualSize = 1;	
	// here is the call:

	// create call parameters:	
	DCOMCallParameters* call_params = new DCOMCallParameters;
	CSemaphore* callsleep = new CSemaphore();
	callsleep->Lock(); // makes sure that we don't wake up right way
	call_params->call_type		= 0; // rapid call type
	call_params->call_sleeper	= callsleep;
	call_params->call_gamestate	= gs;
	call_params->rapid_move			= move;
	call_params->rapid_actualSize	= actualSize;
	call_params->jobID				= 0;

	// lock the DCOM queue and add the call:
	DCOMQueueLock.Lock();	
	DCOMcalls.push_back(call_params);
	DCOMQueueLock.Unlock();
	// wake up a DCOM thread:
	DCOMsleeper->Unlock();
	// and go to sleep yourself:
	callsleep->Lock();
	// at this point our request has been processed by the DCOM thread
	delete callsleep;

	move = call_params->rapid_move;
	actualSize = call_params->rapid_actualSize;

	// make sure that any received character strings end with \0:
	move.gamestate.gamestate[gameStateSize-1] = '\0';
	move.move[moveSize-1] = '\0';

	// process results:
	if (call_params->call_result != 0) {
		delete call_params;		
		delete [] gs.gamestate;
		delete [] move.move;
		delete [] move.gamestate.gamestate;
		available = false;
		// kill all the DCOM threads:
		Uninitialize();
		throw new HelperDeadException();
		return 1;
	}

	// check if the game state was in game over state:
	if (call_params->game_over == 1) {
		delete call_params;		
		delete [] gs.gamestate;
		delete [] move.move;
		delete [] move.gamestate.gamestate;
		throw new GameOverException();
		return 0;
	}

	if (actualSize==0) {
		// no rapid move:
		delete [] gs.gamestate;
		delete [] move.move;
		delete [] move.gamestate.gamestate;		
		delete call_params;		
		*rapid_move = NULL;
		return 0;		
	} 

	// there was a rapid move:	
	Move* tmpResult = new Move;
	tmpResult->gamestate.gamestate = new unsigned char[move.gamestate.actualSize + 1];
	strcpy ((char*) tmpResult->gamestate.gamestate, (char*)move.gamestate.gamestate);

	tmpResult->move = new unsigned char[move.actualSize];
	strcpy ((char*) tmpResult->move, (char*) move.move );
	tmpResult->quality = move.quality;
	tmpResult->status = move.status;

	delete [] gs.gamestate;
	delete [] move.move;
	delete [] move.gamestate.gamestate;
	delete call_params;		
	*rapid_move = tmpResult;
	return 0;
}

Helper::~Helper()
{
	Uninitialize();
	delete DCOMsleeper;
}

void Helper::setLogContext(LogContext* new_logContext) {
	logContext = new_logContext;
}


void Helper::log(CString event) {	
	char hid[30];
	sprintf(hid, "[%d],", (long) this);
	CString tmp = hid;
	sprintf(hid, "%d,", helperID);
	tmp = tmp +  hid;
	tmp = tmp + address.ipAddress;
	if (logContext!=NULL) logContext->addEntry("DCOM HELPER", tmp , event);
}


UINT Helper::DComThread(LPVOID pParam)
{
	// Fetch the thread parameters:
	DCOMThreadParameters* threadParams = (DCOMThreadParameters*) pParam;
	CSemaphore*						DCOMsleeper				= threadParams->sleeper;
	Helper*							hostingHelper			= threadParams->hostingHelper;
	vector<DCOMCallParameters*>*	DCOMcalls				= threadParams->calls;
	CSemaphore*						DCOMQueueLock			= threadParams->queue_lock;
	int*							currentCacheUsage		= threadParams->currentCacheUsage; 
	CSemaphore*						cacheUsageLock			= threadParams->cacheUsageLock; 
	CSemaphore*						cacheAdjLock			= threadParams->cacheAdjLock; 
	int*							desiredCacheSize		= threadParams->desiredCacheSize; 
	bool*							lockedCacheAdjustment	= threadParams->lockedCacheAdjustment;
	bool*							available				= threadParams->available;
	int*							currentCacheSize		= threadParams->currentCacheSize;
	IHelper*						COMObject				= (IHelper*) threadParams->COMObject;
	delete							threadParams;

	// hostingHelper->log("DCOM thread was born");

	vector<DCOMCallParameters*>::iterator call_iterator;
	SimpleDateTime start_time, end_time;
	char temp_string[50];

	// variables used in DCOM:
	HRESULT hr;
	bool locked_thread_count = false;
	bool DCOMInitialized = false;
	try {
		// Initialize DCOM:
		hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);

		if( FAILED(hr) ) {
			// DCOM failed, so log it, mark the helper as dead and 
			// throw an exception, so that we can terminiate this thread
			hostingHelper->log("Cannot create DCOM object instance");
			hostingHelper->setAvailable(false);
			_com_error e(hr);
			CString emess;
			emess = "DCOM ERROR: ";
			emess = emess + e.ErrorMessage();
			AfxMessageBox(emess);
			throw new CException();
		}

		// DCOM initialization was succesful:
		DCOMInitialized = true;				

		// work loop:		
		while(true) {
			// take a nap:
			DCOMsleeper->Lock();			

			// KILL
 			// hostingHelper->log("TH: Woke up and trying to lock cache adjustment");

			// check if they woke you up to kill you:
			// even if the desired cache size is smaller, we might just want to 
			// ignore this wake up, in case outside party does not want us
			// to adjust the cache no matter what at the moment.

			cacheAdjLock->Lock(); // in case other threads are trying to adjust the cache at this time
			locked_thread_count = true;

			bool mustStayUp = (*lockedCacheAdjustment);
			bool mustGoDown = !(*available);
			int tmp_desiredCacheSize = (*desiredCacheSize);
			int tmp_currentCacheSize = (*currentCacheSize);

			if (mustGoDown || ((mustStayUp == false) && (tmp_desiredCacheSize < tmp_currentCacheSize))) throw new CException();
			
			cacheAdjLock->Unlock();
			locked_thread_count = false;

			DCOMQueueLock->Lock();
			if (DCOMcalls->size() > 0) {

				call_iterator = DCOMcalls->begin();
				DCOMCallParameters* call = *call_iterator;
				DCOMcalls->erase(call_iterator);

				// hostingHelper->log("TH: Unlocking call queue");				
				DCOMQueueLock->Unlock();
				
				if (call->call_type == 0) {
					// this is a rapid move call						
					// hostingHelper->log("Making DCOM call to the rapid move service");					
					call->game_over = 0;					
					hr = COMObject->getQuickMove(
						call->call_gamestate, 
						MAXIMAXING, 
						1, 
						&call->rapid_actualSize, 
						&call->rapid_move,
						&call->game_over
					);													
					call->call_result = 0;
					if (mustGoDown) {
						call->call_result = 1;
						hostingHelper->setAvailable(false);
						call->call_sleeper->Unlock();
						throw new CException();
					}
					if( FAILED(hr) ) {
						// if DCOM failed, then log it, mark the helper as dead and return error
						// also, throw an exception, so that we can terminiate this thread
						hostingHelper->log("DCOM rapid-move call failed");
						hostingHelper->setAvailable(false);
						call->call_result = 1; // mark the call as failed
						_com_error e(hr);
						CString emess;						
						// wake up the caller:
						call->call_sleeper->Unlock();
						throw new CException();
					}			
					// hostingHelper->log("Rapid move service results came back");
					if (call->game_over==1) {
						hostingHelper->log("Game-over state sent by the client");
					} else {
						/*
						if (call->rapid_actualSize == 0) {
							hostingHelper->log("No rapid move available");
						} else {
							hostingHelper->log("Rapid move available");
						}
						*/
					}
					call->call_sleeper->Unlock();
				}
				if (call->call_type == 1) {
					// this is a split call					
					// hostingHelper->log("Making DCOM call to the split service");
					hostingHelper->recordAThreadBusy();
					hr = COMObject->split(
						call->call_gamestate, 
						call->split_level, 
						call->split_moveListSize, 
						&call->split_actualSize, 
						call->split_moves
					);					
					hostingHelper->recordAThreadNotBusy();
					if (mustGoDown) {
						call->call_result = 1;
						hostingHelper->setAvailable(false);
						call->call_sleeper->Unlock();
						throw new CException();
					}
					// hostingHelper->log("Split service results came back");
					call->call_result = 0;
					if( FAILED(hr) ) {
						// if DCOM failed, then log it, mark the helper as dead and return error
						// also, throw an exception, so that we can terminiate this thread
						hostingHelper->log("DCOM split call failed");
						hostingHelper->setAvailable(false);
						call->call_result = 1; // mark the call as failed
						_com_error e(hr);						
						// wake up the caller:
						call->call_sleeper->Unlock();
						throw new CException();
					}	
					call->call_sleeper->Unlock();
				}
				if (call->call_type == 2) {
					// this is a eval call
					start_time.setToNow();
					char tmpChar[500];
					sprintf(tmpChar, "Performing node eval: %d: to helper: %d: %s", call->jobID, (long) COMObject, hostingHelper->getAddress().ipAddress);	
					hostingHelper->log(tmpChar);
					
					// mark the fact that one more thread will be used
					cacheUsageLock->Lock();
					*currentCacheUsage = *currentCacheUsage + 1;
					cacheUsageLock->Unlock();
					
					// sprintf(tmpChar, "Eval expected in %d msec", call->eval_timeout);	
					// hostingHelper->log(tmpChar);

					// make the call					
					hostingHelper->recordAThreadBusy();

					// sprintf(tmpChar, "GAME STATE:[%s]", (char*) call->call_gamestate.gamestate);	
					// hostingHelper->log(tmpChar);

					hr = COMObject->evaluate(
						call->call_gamestate,  
						call->eval_level, 
						call->eval_ply,
						call->eval_timeout, 
						&call->eval_quality, 
						&call->eval_performance
					);
					hostingHelper->recordAThreadNotBusy();
					if (mustGoDown) {
						call->call_result = 1;
						hostingHelper->setAvailable(false);
						call->call_sleeper->Unlock();
						throw new CException();
					}
					call->eval_performance.totalWorkTime = call->eval_performance.totalWorkTime * 1000;

					// mark the fact that one less thread will be used
					cacheUsageLock->Lock();
					*currentCacheUsage = *currentCacheUsage - 1;
					cacheUsageLock->Unlock();

					// log the event
					end_time.setToNow();
					// hostingHelper->log("Evaluation service results came back");
					long timespan = end_time - start_time;
					sprintf(temp_string, "%d", timespan);
					CString s = temp_string;
					s = "Total call time was " + s + " msec";
					hostingHelper->log(s);

					// intially mark the call as sucessful
					call->call_result = 0;
					if( FAILED(hr) ) {
						// if DCOM failed, then log it, mark the helper as dead and return error
						// also, throw an exception, so that we can terminiate this thread
						hostingHelper->log("DCOM eval call failed");
						call->call_result = 1; // mark the call as failed
						_com_error e(hr);

					}
					// mark the performance results results 
					hostingHelper->recordEvaluatedNodes(call->eval_performance.nodesEvaluated);
					hostingHelper->recordNodesPerSec(call->eval_performance.nodesEvaluatedPerSecond);
					hostingHelper->recordComOverhead(timespan - call->eval_performance.totalWorkTime);
					call->call_sleeper->Unlock();
				}								
			} else {
				// sprintf(lpszTmp, "TH: Call queue empty");
				// hostingHelper->log(lpszTmp);
				DCOMQueueLock->Unlock();
			}
			
		}
	} catch (CException* e) { 
		// it is time to quit the thread 
		e->Delete();
	}	

	// Thread is going to die, so we need to mark it:
	if (!locked_thread_count) {
		cacheAdjLock->Lock();
	}
	*currentCacheSize = *currentCacheSize - 1;
	cacheAdjLock->Unlock();
	locked_thread_count = false;

	// release the object pointer:
	COMObject->Release();
	// check if we need to uninitialize DCOM:	
	if (DCOMInitialized) CoUninitialize();

	// hostingHelper->log("DCOM thread died");

	return (UINT)0;
}

void Helper::updatePerformance(HelperPerformanceData perfData, long turnAround)
{
	performance.update(perfData, turnAround);
}

void Helper::setDesiredCacheSize(int new_cache)
{	
	cacheAdjLock.Lock();
	desiredCacheSize = new_cache;
	cacheAdjLock.Unlock();
	if (!lockedCacheAdjustment) adjustCache();
}

int Helper::getDesiredCacheSize()
{
	return desiredCacheSize;
}

int Helper::getCurrentCacheSize()
{
	return currentCacheSize;
}

int Helper::getCurrentCacheUsage()
{
	return currentCacheUsage;
}

void Helper::lockCacheAdjustment(bool new_value)
{
	lockedCacheAdjustment = new_value;
	if (!lockedCacheAdjustment) adjustCache();
}

void Helper::adjustCache()
{
	if (lockedCacheAdjustment) return;
	cacheAdjLock.Lock();
	if (desiredCacheSize==currentCacheSize) {
		cacheAdjLock.Unlock();
		return;
	}

	int toCreate = desiredCacheSize - currentCacheSize;
	if (toCreate > 0) {
		vector<void*> pCOMs = createPointers(toCreate);
		vector<void*>::iterator epCOM;
		epCOM = pCOMs.begin();
		IHelper* pCOM;
		while (available && (desiredCacheSize > currentCacheSize)) {
			pCOM = (IHelper*) *epCOM;
			createThread(pCOM);
			currentCacheSize++;
			if (epCOM!=pCOMs.end()) epCOM++;
		}
	}

	int toKill = currentCacheSize - desiredCacheSize;
	cacheAdjLock.Unlock();

	if (toKill>0) {
		// every time we unlock DCOMsleeper, one thread should wake up and realize
		// that it is not needed.
		for (int a=1; a<=toKill; a++) DCOMsleeper->Unlock();
	}

	char tmp[100];
	sprintf(tmp, "Adjusting thread cache to %d", desiredCacheSize);
	log(tmp);

	while (currentCacheSize!=desiredCacheSize) {		
		/*
		sprintf(tmp, "We are down to %d", currentCacheSize);
		log(tmp);
		*/
		::Sleep(100);

	}
}


void Helper::Uninitialize()
{	
	if (currentCacheSize > 0) {
		// Adjust the cache to 0 .. we don't want any threads:
		while (getBusyThreadsCount()>0) ::Sleep(100); // wait until no threads are working		
		available = false;
		lockedCacheAdjustment = false;
		setDesiredCacheSize(0);
		// wait till all threads died
		while (currentCacheSize > 0) { ::Sleep(100); }
	}
}

void Helper::startPerfMeasuring()
{
	measurementsAccess.Lock();		
	totalNodesSearched = 0;
	currentlyWorkingThreads = 0;
	currentlyBusy = false;	
	totalUtilizationTime = 0;
	totalComOverhead = 0;
	totalComOverhead_COUNT = 0;
	totalNodesPerSec = 0;
	totalNodesPerSec_COUNT = 0;
	measurementsAccess.Unlock();
}

void Helper::stopPerfMeasuring()
{
	// nothing to do here
}

long Helper::getTotalNodesSearched()
{
	return totalNodesSearched;
}

float Helper::getNodesPerSec()
{
	if (totalNodesPerSec_COUNT == 0) return 0;
	return totalNodesPerSec / totalNodesPerSec_COUNT;
}

float Helper::getUtilizationTime()
{
	return totalUtilizationTime;
}

float Helper::getComOverhead()
{
	if (totalComOverhead_COUNT == 0) return 0;
	return totalComOverhead / totalComOverhead_COUNT;
}

void Helper::setUtilized(bool flag)
{
	// no need to semaphorize this because it will get called only through
	// other, protected functions
	if (currentlyBusy==flag) {
		// nothing to do
		measurementsAccess.Unlock();		
		return;
	}	
	currentlyBusy = flag;
	if (currentlyBusy) {
		lastTimeBusy.setToNow(); // mark beginning of new busy period
	} else {
		// we just switched to not-busy, so we add up the time 
		// from the previous busy period
		SimpleDateTime tNow;
		tNow.setToNow();
		totalUtilizationTime = totalUtilizationTime + (tNow - lastTimeBusy);
	}	
}

void Helper::recordEvaluatedNodes(long nodes)
{
	measurementsAccess.Lock();	
	totalNodesSearched += nodes;
	measurementsAccess.Unlock();	
}

void Helper::recordNodesPerSec(long nodes)
{
	measurementsAccess.Lock();	
	totalNodesPerSec += nodes;
	totalNodesPerSec_COUNT++;
	measurementsAccess.Unlock();
}

void Helper::recordComOverhead(long msec)
{
	measurementsAccess.Lock();	
	totalComOverhead += msec;
	totalComOverhead_COUNT++;
	measurementsAccess.Unlock();
}

void Helper::recordAThreadBusy()
{	
	measurementsAccess.Lock();	
	if (currentlyWorkingThreads==0) setUtilized(true); // just became utilized
	currentlyWorkingThreads++;	
	measurementsAccess.Unlock();	
}

void Helper::recordAThreadNotBusy()
{
	measurementsAccess.Lock();		
	currentlyWorkingThreads--;	
	if (currentlyWorkingThreads==0) setUtilized(false); // just became un-utilized
	measurementsAccess.Unlock();
}

void Helper::lockBusyThreadCounts()
{
	measurementsAccess.Lock();	
}

void Helper::unlockBusyThreadCounts()
{
	measurementsAccess.Unlock();	
}

int Helper::getBusyThreadsCount()
{
	return currentlyWorkingThreads;
}

int Helper::getMaxThreads()
{
	return m_maxThreads;
}

void Helper::setMaxThreads(int value)
{
	m_maxThreads = value;
}

HelperSecurity Helper::getHelperSecurity()
{
	return helperSecurity;
}

void Helper::setHelperSecurity(HelperSecurity newHelperSecurity)
{
	helperSecurity = newHelperSecurity;
}

void Helper::createThread(void* pCOM)
{
	// we simply create another thread. 
	// we also have to mark that the new thread was created:		
	DCOMThreadParameters* threadParams = new DCOMThreadParameters;
	threadParams->sleeper					= DCOMsleeper;
	threadParams->hostingHelper				= this;
	threadParams->calls						= &DCOMcalls;
	threadParams->queue_lock				= &DCOMQueueLock;
	threadParams->currentCacheUsage			= &currentCacheUsage; 
	threadParams->cacheUsageLock			= &cacheUsageLock; 											   
	threadParams->cacheAdjLock				= &cacheAdjLock; 
	threadParams->desiredCacheSize			= &desiredCacheSize; 
	threadParams->lockedCacheAdjustment		= &lockedCacheAdjustment;
	threadParams->available					= &available;
	threadParams->currentCacheSize			= &currentCacheSize;
	threadParams->COMObject					= (IHelper*) pCOM;
	AfxBeginThread(DComThread, (LPVOID) threadParams);
}

vector<void*> Helper::createPointers(int n)
{
	int a;
	vector<void*> result;

	HRESULT hr;
	IHelper* COMObject;

	// Initialize DCOM:
	COSERVERINFO cs;
	memset(&cs, 0, sizeof(cs));
	cs.pwszName = _bstr_t(_T(address.ipAddress)); 
 
	hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
	if( FAILED(hr) ) {
		// DCOM failed
		_com_error e(hr);
		available = false;
		log("Cannot initiate DCOM");
		CString emess;
		emess = "DCOM ERROR: ";
		emess = emess + e.ErrorMessage();
		AfxMessageBox(emess);	
		return result;
	}

	/*

	COAUTHINFO* login_info			= new COAUTHINFO;
	COAUTHIDENTITY* login			= new COAUTHIDENTITY;
	login_info->dwAuthnSvc			= RPC_C_AUTHN_WINNT; // only one supported at this time
	login_info->dwAuthzSvc			= RPC_C_AUTHZ_NONE;  // only one supported at this time
	login_info->pwszServerPrincName	= NULL; // domain-login redirect ( I think )
	login_info->dwAuthnLevel		= RPC_C_AUTHN_LEVEL_CONNECT; // authorize only at the connection time.
	login_info->dwImpersonationLevel= RPC_C_IMP_LEVEL_IDENTIFY; // other choice is RPC_C_IMP_LEVEL_IMPERSONATE
	login_info->dwCapabilities		= EOAC_NONE; // only one supported at this time
	login->User						= (unsigned short*) new TCHAR[50];
	lstrcpy((LPTSTR) login->User,(LPTSTR) "DGTE");
	login->UserLength				= lstrlen((LPTSTR) login->User);
	login->Password					= (unsigned short*) new TCHAR[50];
	lstrcpy((LPTSTR) login->Password,(LPTSTR) "notjustagame");
	login->PasswordLength			= lstrlen((LPTSTR) login->Password);
	login->Domain					= (unsigned short*) new TCHAR[50];
	lstrcpy((LPTSTR) login->Domain,(LPTSTR) "");
	login->DomainLength				= lstrlen((LPTSTR) login->Domain);
	login->Flags					= SEC_WINNT_AUTH_IDENTITY_ANSI; // other choice is SEC_WINNT_AUTH_IDENTITY_ANSI, but we don't need it
	login_info->pAuthIdentityData	= login; 
	cs.pAuthInfo					= login_info;

    */
	MULTI_QI qi[1];

	for (a=0; a<n; a++) {
		qi[0].pItf = NULL;
		qi[0].hr = 0;
		qi[0].pIID = &IID_IHelper;	
		hr = CoCreateInstanceEx(CLSID_Helper, NULL, CLSCTX_SERVER, &cs, 1, qi);
		if (SUCCEEDED(qi[0].hr)) {
			COMObject = (IHelper*) qi[0].pItf;
			result.push_back((void*) COMObject);
		}
	}

	/*

	delete login->User;
	delete login->Password;
	delete login->Domain;
	delete login;
	delete login_info;

	*/

	if( FAILED(hr) ) {
		// DCOM failed, so log it, mark the helper as dead and 
		// throw an exception, so that we can terminiate this thread			
		_com_error e(hr);
		COMObject=NULL;			
		available = false;
		log("Cannot create DCOM object instance");
		CString emess;
		emess = "DCOM ERROR: ";
		emess = emess + e.ErrorMessage();
		AfxMessageBox(emess);		
	}
 	return result;
}

int Helper::getDesiredLoad()
{
	return mDesiredLoad;
}

void Helper::setDesiredLoad(int load)
{
	mDesiredLoad = load;
}

void Helper::resetSpeedGage()
{
	performance.resetSpeedGage();
}

void Helper::recalculateSpeed()
{
	performance.recalculateSpeed();
}
