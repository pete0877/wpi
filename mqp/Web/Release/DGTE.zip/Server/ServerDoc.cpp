/*     CONTENT: implementation of class CServerDoc
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */


#include "stdafx.h"
#include "Server.h"
#include "ServerDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerDoc

IMPLEMENT_DYNCREATE(CServerDoc, CDocument)

BEGIN_MESSAGE_MAP(CServerDoc, CDocument)
	//{{AFX_MSG_MAP(CServerDoc)
	ON_COMMAND(ID_CLEARVIEW, OnClearview)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerDoc construction/destruction

CServerDoc::CServerDoc()
{
	hasNewEntries = false;
	appThread = NULL;
}

CServerDoc::~CServerDoc()
{
	appThread = NULL;
	char lpszTmp[5000];
	CString strTmp;
	logFile.Open("server_log.txt", CFile::modeWrite | CFile::modeCreate);		
	vector<CString>::iterator enEntries;
	for (enEntries = entries.begin(); enEntries!=entries.end(); enEntries++) {
		strTmp = *enEntries;
		strcpy(lpszTmp, strTmp.GetBuffer(0));
		strcat(lpszTmp, "\x00D\x00A");
		logFile.Write((const void *) lpszTmp, strlen(lpszTmp));
	}
	logFile.Close();	
}

BOOL CServerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument()) return FALSE;
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CServerDoc serialization

void CServerDoc::Serialize(CArchive& ar)
{
	logLock.Lock();
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
	logLock.Unlock();
}

/////////////////////////////////////////////////////////////////////////////
// CServerDoc diagnostics

#ifdef _DEBUG
void CServerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CServerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

void CServerDoc::addEntry(CString classID, CString objectID, CString event)
{
	char tmpMili[50];
	SimpleDateTime t;
	CString logText;

	logLock.Lock();

	t.setToNow();
	double mtime = t.getMiliTime();
	sprintf(tmpMili, "%.0f", mtime);
	logText  = tmpMili;
	logText += "|";
	logText += t.toString().GetBuffer(0);
	logText += "|";
	logText += classID.GetBuffer(0);
	logText += "|";
	logText += objectID.GetBuffer(0);
	logText += "|";
	logText += event.GetBuffer(0);
	entries.push_back(logText);
	hasNewEntries = true;
	
	if (appThread!=NULL) {
		PostThreadMessage(appThread, ID_REFRESH, NULL, NULL);
		// SendMessage(wndHandle, ID_REFRESH, NULL, NULL);
	}

	logLock.Unlock();
}

long CServerDoc::getSize() {
	return entries.size();
}


bool CServerDoc::getHasNewEntries() {
	return hasNewEntries;
}

void CServerDoc::setHasNewEntries(bool bFlag) {
	logLock.Lock();
	hasNewEntries = bFlag;
	logLock.Unlock();
}


CString CServerDoc::getEntry(long entryNumber) {
	logLock.Lock();
	if ((entryNumber < 0) || (entryNumber > (entries.size() - 1))) {
		logLock.Unlock();
		return "";
	}
	CString tmpString = entries[entryNumber];
	logLock.Unlock();
	return tmpString;
}


void CServerDoc::OnClearview() {
	logLock.Lock();
	hasNewEntries = true;
	entries.clear();
	if (appThread!=NULL) {
		PostThreadMessage(appThread, ID_REFRESH, NULL, NULL);
		// SendMessage(wndHandle, ID_REFRESH, NULL, NULL);
	}
	logLock.Unlock();
}

 