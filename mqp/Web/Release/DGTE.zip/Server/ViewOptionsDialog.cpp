/*     CONTENT: implementation of class ViewOptionsDialog
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */


#include "stdafx.h"
#include "Server.h"
#include "ViewOptionsDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// ViewOptionsDialog dialog


ViewOptionsDialog::ViewOptionsDialog(CWnd* pParent /*=NULL*/)
	: CDialog(ViewOptionsDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(ViewOptionsDialog)
	m_check1 = FALSE;
	m_check2 = FALSE;
	m_check3 = FALSE;
	m_check4 = FALSE;
	m_check5 = FALSE;
	m_check6 = FALSE;
	m_keyword = _T("");
	m_check7 = FALSE;
	//}}AFX_DATA_INIT
}


void ViewOptionsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(ViewOptionsDialog)
	DDX_Check(pDX, IDC_CHECK1, m_check1);
	DDX_Check(pDX, IDC_CHECK2, m_check2);
	DDX_Check(pDX, IDC_CHECK3, m_check3);
	DDX_Check(pDX, IDC_CHECK4, m_check4);
	DDX_Check(pDX, IDC_CHECK5, m_check5);
	DDX_Check(pDX, IDC_CHECK9, m_check6);
	DDX_Text(pDX, IDC_EDIT1, m_keyword);
	DDX_Check(pDX, IDC_CHECK10, m_check7);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(ViewOptionsDialog, CDialog)
	//{{AFX_MSG_MAP(ViewOptionsDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


