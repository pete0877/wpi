/*     CONTENT: source file that includes just the standard includes
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"

#ifdef _ATL_STATIC_REGISTRY
	#include <statreg.h>
#endif

#include <atlimpl.cpp>

