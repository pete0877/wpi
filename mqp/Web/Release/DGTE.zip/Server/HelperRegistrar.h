/*     CONTENT: definition of class CHelperRegistrar
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#ifndef __HELPERREGISTRAR_H_
#define __HELPERREGISTRAR_H_

#include "resource.h"       // main symbols
#include "..\Idl\Types.h"

/* 
 * This is the COM class that supports helper registration
 * 
 */
class ATL_NO_VTABLE CHelperRegistrar : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CHelperRegistrar, &CLSID_HelperRegistrar>,
	public IHelperRegistrar
{
protected:
	HelperRegistry* engineHelperRegistry;

public:
	CHelperRegistrar();

DECLARE_REGISTRY_RESOURCEID(IDR_HELPERREGISTRAR)
DECLARE_NOT_AGGREGATABLE(CHelperRegistrar)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CHelperRegistrar)
	COM_INTERFACE_ENTRY(IHelperRegistrar)
END_COM_MAP()

// IHelperRegistrar
public:
	STDMETHOD(unregisterHelper)(/*[in, string]*/ unsigned char *address);
	STDMETHOD(registerHelper)(/*[in, string]*/ unsigned char *address, /*[in]*/ GameTypeData data, /*[in]*/ int maxThreads, /*[in]*/ HelperSecurity helperSecurity);
};

#endif //__HELPERREGISTRAR_H_
