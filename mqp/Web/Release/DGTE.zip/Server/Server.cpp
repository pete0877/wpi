/*     CONTENT: implementation of class CServerApp
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "Server.h"

#include "MainFrm.h"
#include "ServerDoc.h"
#include "ServerView.h"
#include <initguid.h>
#include "../Idl/Server_i.c"
#include "HelperRegistrar.h"
#include "ServerOptionsDialog.h"
#include "GameServer.h"
#include "Engine.h"
#include "Splash.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerApp

BEGIN_MESSAGE_MAP(CServerApp, CWinApp)
	//{{AFX_MSG_MAP(CServerApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_TOOLS_OPTIONS, OnToolsOptions)
	ON_COMMAND(ID_TOOLS_STATISTICS, OnToolsStatistics)
	ON_COMMAND(ID_SERVERSTART, OnServerStart)
	ON_COMMAND(ID_SERVERSTOP, OnServerStop)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)	
	ON_THREAD_MESSAGE(ID_REFRESH, OnRefreshing)	
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerApp construction

CServerApp::CServerApp()
{
	gameserver = NULL;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CServerApp object

CServerApp theApp;



/////////////////////////////////////////////////////////////////////////////
// CServerApp initialization

BOOL CServerApp::InitInstance()
{
	// CG: The following block was added by the Splash Screen component.
\
	{
\
		CCommandLineInfo cmdInfo;
\
		ParseCommandLine(cmdInfo);
\

\
		Splash::EnableSplashScreen(cmdInfo.m_bShowSplash);
\
	}

	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	if (!InitATL())
		return FALSE;

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Distributed Game Tree Server"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CServerDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CServerView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated) return TRUE;


	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();


	////////////////////////////////////////////////////////////////////////
	// Initiate the configurations and the log files:


	gameserver = new GameServer();

	CMainFrame* tmpFrame = (CMainFrame*) GetMainWnd();	
	CServerDoc* tmpDoc = (CServerDoc*) tmpFrame->GetActiveDocument();	
	CDocument* tmpParentDoc = (CDocument*) tmpDoc;
	tmpParentDoc->SetTitle("DGTE");
	gameserver->setLogContext((LogContext*) tmpDoc);

	tmpDoc->appThread = GetCurrentThreadId();
	tmpDoc->wndHandle = tmpFrame->m_hWnd;

	return TRUE;
}

// App command to run the dialog
void CServerApp::OnAppAbout()
{
	AboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CServerApp message handlers

BOOL CServerApp::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following line was added by the Splash Screen component.

	Splash::PreTranslateAppMessage(pMsg);
	return CWinApp::PreTranslateMessage(pMsg);
}

CServerModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_HelperRegistrar, CHelperRegistrar)
END_OBJECT_MAP()

LONG CServerModule::Unlock()
{
	AfxOleUnlockApp();
	return 0;
}

LONG CServerModule::Lock()
{
	AfxOleLockApp();
	return 1;
}
LPCTSTR CServerModule::FindOneOf(LPCTSTR p1, LPCTSTR p2)
{
	while (*p1 != NULL)
	{
		LPCTSTR p = p2;
		while (*p != NULL)
		{
			if (*p1 == *p)
				return CharNext(p1);
			p = CharNext(p);
		}
		p1++;
	}
	return NULL;
}


int CServerApp::ExitInstance()
{
	// Stop and delete the game server:
	gameserver->setLogContext(NULL);
	gameserver->stop();
	delete gameserver;

	if (m_bATLInited)
	{
		_Module.RevokeClassObjects();
		_Module.Term();
		CoUninitialize();
	}

	return CWinApp::ExitInstance();

}

BOOL CServerApp::InitATL()
{
	m_bATLInited = TRUE;

	HRESULT hRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);

	if (FAILED(hRes))
	{
		m_bATLInited = FALSE;
		return FALSE;
	}

	_Module.Init(ObjectMap, AfxGetInstanceHandle());
	_Module.dwThreadID = GetCurrentThreadId();

	LPTSTR lpCmdLine = GetCommandLine(); //this line necessary for _ATL_MIN_CRT
	TCHAR szTokens[] = _T("-/");

	BOOL bRun = TRUE;
	LPCTSTR lpszToken = _Module.FindOneOf(lpCmdLine, szTokens);
	while (lpszToken != NULL)
	{
		if (lstrcmpi(lpszToken, _T("UnregServer"))==0)
		{
			_Module.UpdateRegistryFromResource(IDR_SERVER, FALSE);
			_Module.UnregisterServer(TRUE); //TRUE means typelib is unreg'd
			bRun = FALSE;
			break;
		}
		if (lstrcmpi(lpszToken, _T("RegServer"))==0)
		{
			_Module.UpdateRegistryFromResource(IDR_SERVER, TRUE);
			_Module.RegisterServer(TRUE);
			bRun = FALSE;
			break;
		}
		lpszToken = _Module.FindOneOf(lpszToken, szTokens);
	}

	if (!bRun)
	{
		m_bATLInited = FALSE;
		_Module.Term();
		CoUninitialize();
		return FALSE;
	}

	hRes = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER,
		REGCLS_MULTIPLEUSE);
	if (FAILED(hRes))
	{
		m_bATLInited = FALSE;
		CoUninitialize();
		return FALSE;
	}

	return TRUE;

}

void CServerApp::OnToolsOptions()
{
	ServerOptionsDialog dlg;
	dlg.setOptions(gameserver->getConfiguration());
	int result = dlg.DoModal();
	if (result == IDOK) {
		gameserver->setConfiguration(dlg.getOptions());
	}
}

void CServerApp::OnToolsStatistics()
{
	this->DoMessageBox("Sorry, this feature is not available yet.",0,0);
}

void CServerApp::OnServerStart()
{
	gameserver->start();
}

void CServerApp::OnServerStop()
{
	gameserver->stop();
}

GameServer* CServerApp::getGameServer()
{
	return this->gameserver;
}

BOOL CServerApp::OnIdle(LONG lCount)
{
	return CWinApp::OnIdle(lCount);
}

LRESULT CServerApp::OnRefreshing(WPARAM p0, LPARAM p1) {
	CMainFrame* tmpFrame = (CMainFrame*) GetMainWnd();	
	CServerView* tmpView = (CServerView*) tmpFrame->GetActiveView();		
	tmpView->Refresh();
	return (LRESULT)0;
}
