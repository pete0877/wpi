/*     CONTENT: definition of class HelperRegistry
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(HelperRegistry_h)
#define HelperRegistry_h

/*
 * HelperRegistry Class provides DCom interface for helpers to
 * register and unregister with the server. It stores references to
 * all known helpers.
 */

#include "resource.h"
#include <afxmt.h>
#include "GameType.h"
#include "Helper.h"

#define MAXTHREADSINIT 30

class HelperRegistry 
{
public:
	static UINT RegThread(LPVOID pParam);
	void unregisterHelper(unsigned char *address);
	void registerHelper(unsigned char *address, GameTypeData data, int maxThreads, HelperSecurity helperSecurity);
	HelperRegistry();
    vector<Helper*> getHelpers(GameType gametype);
    vector<GameType> getAllGameTypes();
    boolean isGameImplemented(const GameType& gametype);
    void returnHelpers(vector<Helper*> returnedhelpers);
	void setLogContext(LogContext* new_logContext);
    ~HelperRegistry();

protected:
	void cleanup();
	LogContext*			logContext;
	void				log(CString event);
    vector<Helper*>		helpers;
    vector<int>			refereceCounts;
    CSemaphore			helpersListLock;
    long				nextHelperID;

private:


};

#endif /* HelperRegistry_h */
