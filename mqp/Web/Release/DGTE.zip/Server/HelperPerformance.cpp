/*     CONTENT: implementation of class HelperPerformance
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "HelperPerformance.h"
#include <math.h>

// PERF_RESPONSIVENESS - higher -> faster the adjustments in load balancing
#define PERF_RESPONSIVENESS		0.10 // percent changes for each evaluation

HelperPerformance::HelperPerformance()
{
	helperPerformanceData.nodesEvaluatedPerSecond = 0;
	helperPerformanceData.nodesEvaluated = 0;
	helperPerformanceData.pctCompleted = 0;
	helperPerformanceData.totalWorkTime = 0;	
	overHeadTime = 0;
	dataLock = new CSemaphore();
	aveSpeed = 1;
	resetSpeedGage();
}


HelperPerformance::~HelperPerformance()
{
	delete dataLock;
}

HelperPerformance::HelperPerformance(const HelperPerformance& new_helperperformance)
{
	this->helperPerformanceData = new_helperperformance.helperPerformanceData;
	overHeadTime = new_helperperformance.overHeadTime;
	dataLock = new CSemaphore();	 
	aveSpeed = new_helperperformance.aveSpeed;
	resetSpeedGage();
}

HelperPerformance::HelperPerformance(const HelperPerformanceData& new_helperperformancedata)
{
	this->helperPerformanceData = new_helperperformancedata;
	overHeadTime = 0;
	dataLock = new CSemaphore();
	aveSpeed = new_helperperformancedata.nodesEvaluatedPerSecond;
	resetSpeedGage();
}

void HelperPerformance::update(const HelperPerformanceData& new_helperperformancedata, long new_turnaroundtime)
{
	lock();

	// record the completion factor and work time of the last evaluation:
	helperPerformanceData.pctCompleted		= new_helperperformancedata.pctCompleted;
	helperPerformanceData.totalWorkTime		= new_helperperformancedata.totalWorkTime;	
	helperPerformanceData.nodesEvaluated			= new_helperperformancedata.nodesEvaluated;
	helperPerformanceData.nodesEvaluatedPerSecond	= new_helperperformancedata.nodesEvaluatedPerSecond;

	mSumSpeeds += new_helperperformancedata.nodesEvaluatedPerSecond;
	mCountSpeeds++;
	
	overHeadTime = (long) new_turnaroundtime - (long) helperPerformanceData.totalWorkTime;

	unlock();
}

float HelperPerformance::getOverheadTime() { return overHeadTime; }

void HelperPerformance::setOverheadTime(float new_overheadtime) { 
	lock();	
	overHeadTime = new_overheadtime; 
	unlock();	
}

float HelperPerformance::getPctCompleted() { return helperPerformanceData.pctCompleted; }

void HelperPerformance::setPctCompleted(float new_pctcompleted) { 
	lock();	
	helperPerformanceData.pctCompleted = new_pctcompleted; 
	unlock();
}

float HelperPerformance::getTotalWorkTime() { return helperPerformanceData.totalWorkTime; }

void HelperPerformance::setTotalWorkTime(float new_worktime) { 
	lock();	
	helperPerformanceData.totalWorkTime = new_worktime; 
	unlock();
}

void HelperPerformance::lock() { dataLock->Lock(); }

void HelperPerformance::unlock() { dataLock->Unlock(); }

const HelperPerformance& HelperPerformance::operator=(const HelperPerformance& new_helperperformance)
{	
	lock();	
	helperPerformanceData = new_helperperformance.helperPerformanceData;
	overHeadTime = new_helperperformance.overHeadTime;
	aveSpeed = new_helperperformance.aveSpeed;
	unlock();
	return *this;
}


long HelperPerformance::getNodesEvaluated() {	
	return helperPerformanceData.nodesEvaluated;
}
void HelperPerformance::setNodesEvaluated(long new_value){
	lock();	
	helperPerformanceData.nodesEvaluated = new_value;
	unlock();
}

long HelperPerformance::getNodesEvaluatedPerSecond() {
	return helperPerformanceData.nodesEvaluatedPerSecond;
}

void HelperPerformance::setNodesEvaluatedPerSecond(long new_value) {
	lock();	
	helperPerformanceData.nodesEvaluatedPerSecond = new_value;
	unlock();	
}

long HelperPerformance::getSpeed()
{
	return aveSpeed;
}

void HelperPerformance::setSpeed(long speed)
{
	aveSpeed = speed;
}

void HelperPerformance::resetSpeedGage()
{
	mSumSpeeds = 0;
	mCountSpeeds = 0;
}

void HelperPerformance::recalculateSpeed()
{
	if (mCountSpeeds==0) return;
	float average = mSumSpeeds / mCountSpeeds;
	if (aveSpeed == 1) {
		// this is our first set of evaluations
		aveSpeed = average;
	} else {
		// we had some avereage data from the previous evaluation so we
		// take a correction only:
		aveSpeed = aveSpeed + (PERF_RESPONSIVENESS) * (average - aveSpeed);
	}
	resetSpeedGage();
}
