/*     CONTENT: definition of class Helper
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(Helper_h)
#define Helper_h

#include <afxmt.h>
#include "resource.h"
#include "HelperPerformance.h"
#include "InternetAddress.h"
#include "JobManager.h"
#include "..\Idl\Types.h"
#include "GameType.h"
#include "GameTreeNode.h"
#include "SimpleDateTime.h"	// Added by ClassView

/*
 * this structure is used to communicate with threads
 */
typedef struct tagDCOMCallParameters {
	int				call_type;
	CSemaphore*		call_sleeper;
	int				call_result;
	GameState		call_gamestate;
	long			jobID;

	// call specific parameters:
	LevelType				eval_level;
	int						eval_ply;
	int						eval_quality;
	long					eval_timeout;
	HelperPerformanceData	eval_performance;

	GameState				split_gamestate;
	LevelType				split_level;
	int						split_moveListSize;
	int						split_actualSize;
	Move*					split_moves;

	GameState				rapid_gamestate;
	int						rapid_actualSize;
	Move					rapid_move;
	int						game_over;

} DCOMCallParameters;


/*
 * Helper Class provides logical connection between the current
 * process on the game server and the physical helper process on a
 * different machine. Helper Class uses DCom in all network
 * communication. It provides game state  evaluation services, game
 * state split services and other. It throws HelperDeadException
 * exception.
 */
class Helper;
typedef struct tagDCOMThreadParameters {
	CSemaphore*						sleeper; // DCOM thread will sleep until this semaphore is unlocked
	Helper*							hostingHelper;// the pointer to the helper object, just so that we can log stuff
	vector<DCOMCallParameters*>*	calls; // queue of calls
	CSemaphore*						queue_lock; // lock for the queue of calls
	int*							currentCacheUsage; // counter of threads currently doing evaluation
	CSemaphore*						cacheUsageLock; // lock for the currentCacheUsage pointer
	CSemaphore*						cacheAdjLock; // lock on the adjustment of number of helpers
	int*							desiredCacheSize; // desired number of helpers
	bool*							lockedCacheAdjustment; // true, if we are not supposed to adjust to achieve desired cache size
	bool*							available; // true, if the DCOM connection is available
	int*							currentCacheSize; // the current number of threads running
	void*							COMObject; // pointer to the object
} DCOMThreadParameters;


class Helper
{
public:		
	void recalculateSpeed();
	void resetSpeedGage();
	void setDesiredLoad(int load);
	int getDesiredLoad();
	void setHelperSecurity(HelperSecurity newHelperSecurity);
	HelperSecurity getHelperSecurity();
	void setMaxThreads(int value);
	int getMaxThreads();
	int getBusyThreadsCount();
	void lockBusyThreadCounts();
	void unlockBusyThreadCounts();
	void recordAThreadNotBusy();
	void recordAThreadBusy();
	void recordComOverhead(long msec);
	void recordNodesPerSec(long nodes);
	void recordEvaluatedNodes(long nodes);
	float getComOverhead();
	float getUtilizationTime();
	float getNodesPerSec();
	long getTotalNodesSearched();
	void stopPerfMeasuring();
	void startPerfMeasuring();
	void lockCacheAdjustment(bool new_value);
	int  getCurrentCacheSize();
	int  getCurrentCacheUsage();	
	int  getDesiredCacheSize();	
	void setDesiredCacheSize(int new_cache);
	static UINT	DComThread(LPVOID pParam);
	void Uninitialize();

    /*
     * Helper() - default constructor.
     */
    Helper();
    HelperPerformance getPerformance();
    void setPerformance(const HelperPerformance& new_performance);
    InternetAddress getAddress();
    void setAddress(const InternetAddress& new_address);
    GameType getGameType();
    void setGameType(const GameType& new_gametype);
    bool getAvailable();
    void setAvailable(bool new_available);
    long getHelperID();
    void setHelperID(long new_helperid);
    /*
     * throws HelperDeadException exception
     */
    int evaluateBoard(GameTreeNode* node, long timelimit);
    /*
     * throws HelperDeadException exception
     */
    int splitBoard(GameTreeNode* node);
    /*
     * THROWS:
     *    HelperDeadException exception
     *    GameOverException exception
     */
    int makeRapidDesicion(const GameState& gamestate, Move** rapid_move);
	void setLogContext(LogContext* new_logContext);
	void log(CString event);
	void updatePerformance(HelperPerformanceData perfData, long turnAround);
    ~Helper();

protected:
	vector<void*> createPointers(int n);
	void createThread(void* pCOM);
	HelperSecurity helperSecurity;
	int m_maxThreads;
	void setUtilized(bool flag);
	bool currentlyBusy;
	int  currentlyWorkingThreads;
	SimpleDateTime lastTimeBusy;
	CSemaphore measurementsAccess;
	float totalUtilizationTime;
	float totalComOverhead;
	int   totalComOverhead_COUNT;
	float totalNodesPerSec;
	int   totalNodesPerSec_COUNT;
	long  totalNodesSearched;
	void* COMObject;
	CSemaphore cacheUsageLock;
	int currentCacheUsage;
	CSemaphore cacheAdjLock;
	int desiredCacheSize;
	bool lockedCacheAdjustment;
	int currentCacheSize;
	vector<DCOMCallParameters*>	DCOMcalls;
	CSemaphore			DCOMQueueLock;
	CSemaphore*			DCOMsleeper;
	LogContext*			logContext;	
    HelperPerformance	performance;
    InternetAddress		address;
    GameType			gametype;
    bool				available;
    long				helperID;
	void adjustCache();

private:
	int mDesiredLoad;
};

#endif /* Helper_h */
