/*     CONTENT: definition of class HelperPerformance
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(HelperPerformance_h)
#define HelperPerformance_h

#include "resource.h"
#include "..\Idl\Types.h"
#include <afxmt.h>

/*
 * HelperPerformance Class is used by each helper to store and
 * evaluate certain parameters, such as the average time that a
 * particular helper needs to evlauate a board, or overhead time in
 * communication.
 */
class HelperPerformance
{
public:
	void recalculateSpeed();
	void resetSpeedGage();
	void setSpeed(long speed);
	long getSpeed();

	~HelperPerformance();
    HelperPerformance();
    HelperPerformance(const HelperPerformance& new_helperperformance);
    HelperPerformance(const HelperPerformanceData& new_helperperformancedata);
    void update(const HelperPerformanceData& new_helperperformancedata, long new_turnaroundtime);
    float getOverheadTime();
    void setOverheadTime(float new_overheadtime);
    float getPctCompleted();
    void setPctCompleted(float new_pctcompleted);
    float getTotalWorkTime();
    void setTotalWorkTime(float new_worktime);
	long getNodesEvaluated();
    void setNodesEvaluated(long new_value);
	long getNodesEvaluatedPerSecond();
    void setNodesEvaluatedPerSecond(long new_value);
    const HelperPerformance& operator=(const HelperPerformance& new_helperperformance);
    
protected:
	int mCountSpeeds;
	long mSumSpeeds;

    void					lock();
    void					unlock();
    HelperPerformanceData	helperPerformanceData;
    long					overHeadTime;
    CSemaphore*				dataLock;
	long					aveSpeed;

};

#endif /* HelperPerformance_h */
