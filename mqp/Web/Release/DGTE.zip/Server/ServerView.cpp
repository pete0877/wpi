/*     CONTENT: implementation of class CServerView
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */


#include "stdafx.h"
#include "Server.h"

#include "ServerDoc.h"
#include "ServerView.h"
#include "StringTool.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CServerView

IMPLEMENT_DYNCREATE(CServerView, CEditView)

BEGIN_MESSAGE_MAP(CServerView, CEditView)
	//{{AFX_MSG_MAP(CServerView)
	ON_COMMAND(ID_VIEWOPTIONS, OnViewoptions)
	ON_WM_DESTROY()
	ON_WM_CREATE()
	ON_COMMAND(ID_SHOWTREE, OnShowtree)
	ON_COMMAND(ID_SHOWLOG, OnShowlog)			
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


#ifdef _DEBUG

CServerDoc* CServerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CServerDoc)));
	return (CServerDoc*)m_pDocument;
}
#endif //_DEBUG


void CServerView::OnDraw(CDC* pDC)
{
	CEditView::OnDraw(pDC);
}

void CServerView::Refresh() { 
	LogContext* logContext = (LogContext*) GetDocument();
	basic_string<char> displayedText = "";

	// depending on which mode we are in, we want to display different things:
	if (options.mode == 0) {
		// Chronological mode
		long totalLength = 0;
		long messageCount = logContext->getSize();
		for (long a=messageCount-1; a>=0; a--) {
			CString tmp = logContext->getEntry(a);
			bool willShow = false;
			if (!willShow && options.see_game_server==1 && tmp.Find("GAME SERVER")!=-1) willShow = true;
			if (!willShow && options.see_engine==1 && tmp.Find("ENGINE")!=-1) willShow = true;
			if (!willShow && options.see_helper_registry==1 && tmp.Find("HELPER REGISTRY")!=-1) willShow = true;
			if (!willShow && options.see_distributor==1 && tmp.Find("DISTRIBUTOR")!=-1) willShow = true;
			if (!willShow && options.see_helpers==1 && tmp.Find("DCOM HELPER")!=-1) willShow = true;
			if (!willShow && options.see_stats==1 && tmp.Find("STATS KEEPER")!=-1) willShow = true;
			if (!willShow && options.see_keyword==1 && tmp.Find(options.m_keyword_string)!=-1) willShow = true;
			if (willShow &&  totalLength <= 63000) {
				displayedText += tmp.GetBuffer(0);
				displayedText += "\x00D\x00A";
				totalLength += strlen(tmp.GetBuffer(0));
			}
		}
	}
	if (options.mode == 1) {
		// Tree view mode
		viewLock.Lock();
		displayedText  = "TREE DISTRIBUTION:                       \x00D\x00A\x00D\x00A";
		long logSize = logContext->getSize();
		basic_string<char> tree = "";
		if ((lastCount > logSize) || logSize==0) {
			// the clear button was pressed so we need to clear the tree:
			TDClear();
			lastCount = 0;
		}
		while (logSize > lastCount) {
			// .. sample executions
			// TDAddRootNode(1);
			// TDAddChildNode(1,2);
			// TDAddChildNode(3,10);
			// TDSetNodeStatus(2, 'E');
			// TDSetNodeHelper(2, 99, "REXER");
			CString log_entry = logContext->getEntry(lastCount++);
			int position;
			bool matched = false;


			if (!matched) {
				position = log_entry.Find("Created node:");
				if (position != -1) {
					CString number1, number2;
					position += strlen("Created node:");
					number1 = log_entry.Mid(position);
					position = number1.Find(":");
					number2 = number1.Mid(position+1);
					number1 = number1.Left(position);
					position = number2.Find(":");
					number2 = number2.Mid(position+2);
					number1.TrimLeft();
					number1.TrimRight();
					number2.TrimLeft();
					number2.TrimRight();
					long node1=0, node2=0;
					StringTool strTmp;
					if (number1!="" && number2!="") {
						strTmp.set(number1);				
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						strTmp.set(number2);						
						node2 = 0;
						try { node2 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						TDAddChildNode(node2, node1);
					}
					matched = true;
				}
			}
			if (!matched) {
				position = log_entry.Find("Created root node:");
				if (position != -1) {
					CString number1;
					position += strlen("Created root node:");
					number1 = log_entry.Mid(position);
					number1.TrimLeft();
					number1.TrimRight();
					if (number1!="") {
						long node1;
						StringTool strTmp;
						strTmp.set(number1);
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }						
						TDAddRootNode(node1);
					}
					matched = true;
				}
			}
			if (!matched) {
				position = log_entry.Find("Assigned node split:");
				if (position != -1) {
					CString number1, number2, sHelper;
					position += strlen("Assigned node split:");
					number1 = log_entry.Mid(position);
					position = number1.Find(":");
					number2 = number1.Mid(position+1);
					number1 = number1.Left(position);
					position = number2.Find(":");
					number2 = number2.Mid(position+2);
					position = number2.Find(":");
					sHelper = number2.Mid(position+1);
					number2 = number2.Left(position);
					number1.TrimLeft();
					number1.TrimRight();
					number2.TrimLeft();
					number2.TrimRight();
					sHelper.TrimLeft();
					sHelper.TrimRight();
					long node1=0, node2=0;
					StringTool strTmp;
					if (number1!="" && number2!="") {

						strTmp.set(number1);
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						strTmp.set(number2);
						node2 = 0;
						try { node2 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						TDSetNodeStatus(node1, "getting split");
						TDSetNodeHelper(node1, node2, sHelper);
					}
					matched = true;
				}
			}
			if (!matched) {
				position = log_entry.Find("Node split completed:");
				if (position != -1) {
					CString number1;
					position += strlen("Node split completed:");
					number1 = log_entry.Mid(position);
					number1.TrimLeft();
					number1.TrimRight();
					if (number1!="") {
						long node1;
						StringTool strTmp;
						strTmp.set(number1);
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						TDSetNodeStatus(node1, "split");
						TDSetNodeHelper(node1, -1, "");
					}
					matched = true;
				}
			}
			if (!matched) {
				position = log_entry.Find("Assigned node eval:");
				if (position != -1) {
					CString number1, number2, sHelper;
					position += strlen("Assigned node eval:");
					number1 = log_entry.Mid(position);
					position = number1.Find(":");
					number2 = number1.Mid(position+1);
					number1 = number1.Left(position);
					position = number2.Find(":");
					number2 = number2.Mid(position+2);
					position = number2.Find(":");
					sHelper = number2.Mid(position+1);
					number2 = number2.Left(position);
					number1.TrimLeft();
					number1.TrimRight();
					number2.TrimLeft();
					number2.TrimRight();
					sHelper.TrimLeft();
					sHelper.TrimRight();
					long node1=0, node2=0;
					StringTool strTmp;
					if (number1!="" && number2!="") {
						strTmp.set(number1);
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						strTmp.set(number2);
						node2 = 0;
						try { node2 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						TDSetNodeStatus(node1, "will get evaluated");
						TDSetNodeHelper(node1, node2, sHelper);
					}
					matched = true;
				}
			}
			if (!matched) {
				position = log_entry.Find("Performing node eval:");
				if (position != -1) {
					CString number1, number2, sHelper;
					position += strlen("Performing node eval:");
					number1 = log_entry.Mid(position);
					position = number1.Find(":");
					number2 = number1.Mid(position+1);
					number1 = number1.Left(position);
					position = number2.Find(":");
					number2 = number2.Mid(position+2);
					position = number2.Find(":");
					sHelper = number2.Mid(position+1);
					number2 = number2.Left(position);
					number1.TrimLeft();
					number1.TrimRight();
					number2.TrimLeft();
					number2.TrimRight();
					sHelper.TrimLeft();
					sHelper.TrimRight();
					long node1=0, node2=0;
					StringTool strTmp;
					if (number1!="" && number2!="") {
						strTmp.set(number1);
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						strTmp.set(number2);
						node2 = 0;
						try { node2 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						TDSetNodeStatus(node1, "getting evaluated");
						TDSetNodeHelper(node1, node2, sHelper);
					}
					matched = true;
				}
			}
			if (!matched) {
				position = log_entry.Find("Node eval completed:");
				if (position != -1) {
					CString number1;
					position += strlen("Node eval completed:");
					number1 = log_entry.Mid(position);
					number1.TrimLeft();
					number1.TrimRight();
					if (number1!="") {
						long node1;
						StringTool strTmp;
						strTmp.set(number1);
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						TDSetNodeStatus(node1, "evaluated");
						TDSetNodeHelper(node1, -1, "");
					}
					matched = true;
				}
			}
			if (!matched) {
				position = log_entry.Find("Node eval failed:");
				if (position != -1) {
					CString number1;
					position += strlen("Node eval failed:");
					number1 = log_entry.Mid(position);
					number1.TrimLeft();
					number1.TrimRight();
					if (number1!="") {
						long node1;
						StringTool strTmp;
						strTmp.set(number1);
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						TDSetNodeStatus(node1, "eval failed");
						TDSetNodeHelper(node1, -1, "");
					}
					matched = true;
				}
			}			
			if (!matched) {
				position = log_entry.Find("Finished evaluating root node:");
				if (position != -1) {
					CString number1;
					position += strlen("Finished evaluating root node:");
					number1 = log_entry.Mid(position);
					number1.TrimLeft();
					number1.TrimRight();
					if (number1!="") {
						long node1;
						StringTool strTmp;
						strTmp.set(number1);
						node1 = 0;
						try { node1 = strTmp.toLong(); } 
						catch (CException* e) { e->Delete(); }
						TDSetNodeStatus(node1, "completed");
						TDSetNodeHelper(node1, -1, "");						
						TDRemoveRootNode(node1);
					}
					matched = true;
				}
			}

		}
		tree = TDGetTrees();
		if (tree != "") displayedText += tree.begin();
		viewLock.Unlock();
	}
	this->GetEditCtrl().SetWindowText(displayedText.begin());
	return;
}

void CServerView::OnViewoptions()
{
	ViewOptionsDialog dlg;
	dlg.m_check1 = options.see_game_server;
	dlg.m_check2 = options.see_engine;
	dlg.m_check3 = options.see_helper_registry;
	dlg.m_check4 = options.see_helpers;
	dlg.m_check5 = options.see_distributor;
	dlg.m_check6 = options.see_stats;
	dlg.m_check7 = options.see_keyword;
	dlg.m_keyword = options.m_keyword_string;

	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		options.see_game_server = dlg.m_check1;
		options.see_engine = dlg.m_check2;
		options.see_helper_registry = dlg.m_check3;
		options.see_helpers = dlg.m_check4;
		options.see_distributor = dlg.m_check5;
		options.see_stats = dlg.m_check6;
		options.see_keyword = dlg.m_check7;
		options.m_keyword_string = dlg.m_keyword;
		Refresh();
	}
}

/*
typedef tagNodeInfo {
	long node_number;
	char node_state;
	char helper_number;
	char helper_name;
	vector<void*> children;
} NodeInfo;
*/

void CServerView::TDClear()
{
	vector<NodeInfo*>::iterator i;
	NodeInfo* node;
	for (i=knownTrees.begin(); i!=knownTrees.end(); i++) {
		node = *i;
		TDDeleteNode(node);
	}
	knownTrees.clear();
}

void CServerView::TDAddRootNode(long nNode)
{
	NodeInfo* node = new NodeInfo;
	node->helper_number = -1;
	node->helper_name =  "";
	node->node_number = nNode;
	node->node_state = " ";
	knownTrees.push_back(node);
}

void CServerView::TDRemoveRootNode(long nNode)
{
	vector<NodeInfo*>::iterator i;
	NodeInfo* node;
	for (i=knownTrees.begin(); i!=knownTrees.end(); i++) {
		node = *i;
		if (node->node_number == nNode) {
			TDDeleteNode(node);
			knownTrees.erase(i);
			return;
		}
	}

}

void CServerView::TDSetNodeStatus(long nNode, CString cStatus)
{
	NodeInfo* node = TDFindNode(nNode);
	if (node!=NULL) {
		node->node_state = cStatus;
	}
}

void CServerView::TDSetNodeHelper(long nNode, long nHelper, CString sHelper)
{
	NodeInfo* node = TDFindNode(nNode);
	if (node!=NULL) {
		node->helper_name = sHelper;
		node->helper_number = nHelper;
	}
}

void CServerView::TDAddChildNode(long nParentNode, long nChildNode)
{
	NodeInfo* node = TDFindNode(nParentNode);
	if (node!=NULL) {
		NodeInfo* tmpNode = new NodeInfo;
		tmpNode->helper_number = -1;
		tmpNode->helper_name = "";
		tmpNode->node_number = nChildNode;
		tmpNode->node_state = " ";
		node->children.push_back(tmpNode);
	}
}

basic_string<char> CServerView::TDGetTrees()
{
	basic_string<char> result = "";
	vector<NodeInfo*>::iterator i;
	NodeInfo* node;
	for (i = knownTrees.begin();i!=knownTrees.end(); i++) {
		node = *i;
		TDExtractTree(node, 2, &result);
	}
	return result;
}

void CServerView::TDDeleteNode(NodeInfo *pNode)
{
	vector<void*>::iterator i;
	NodeInfo* node;
	for (i = pNode->children.begin();i!=pNode->children.end(); i++) {
		node = (NodeInfo*) *i;
		TDDeleteNode(node);
	}
	pNode->children.clear();
	delete pNode;
}

void CServerView::TDExtractTree(NodeInfo *pNode, int spacing, basic_string<char> *result)
{
	char* spaces = new char[spacing+1];
	char tmpStr[200];
	for (int a=0; a<spacing; a++) spaces[a] = ' ';
	spaces[a] = '\0';
	CString line = spaces;
	delete spaces;
	sprintf(tmpStr, "%d: %s:  ", pNode->node_number, pNode->node_state.GetBuffer(0));
	line += tmpStr;
	if (pNode->helper_number >= 0) {
		sprintf(tmpStr, "%s (%d)", pNode->helper_name, pNode->helper_number);
		line += tmpStr;
	}
	line += "\x00D\x00A";

	*result += line.GetBuffer(0);

	vector<void*>::iterator i;
	NodeInfo* node;
	for (i=pNode->children.begin(); i!=pNode->children.end(); i++) {
		node = (NodeInfo*) *i;
		TDExtractTree(node, spacing + 15, result);
	}
}

NodeInfo* CServerView::TDFindNode(long nNode)
{
	vector<NodeInfo*>::iterator i;
	NodeInfo* node;
	NodeInfo* found = NULL;
	for (i = knownTrees.begin();i!=knownTrees.end(); i++) {
		node = *i;
		found = TDSearchNode(nNode, node);
		if (found != NULL) return found;
	}
	return NULL;
}

NodeInfo* CServerView::TDSearchNode(long nNode, NodeInfo* pStart)
{
	if (pStart->node_number == nNode) return pStart;
	if (pStart->children.size() == 0) return NULL;
	NodeInfo* node;
	NodeInfo* found;
	vector<void*>::iterator i;
	for (i = pStart->children.begin();i!=pStart->children.end(); i++) {
		node = (NodeInfo*) *i;
		found = TDSearchNode(nNode, node);
		if (found != NULL) return found;
	}
	return NULL;
}


void CServerView::OnDestroy()
{
	TDClear();
	CEditView::OnDestroy();
}

int CServerView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CEditView::OnCreate(lpCreateStruct) == -1)
		return -1;

	lastCount = 0;

	return 0;
}

void CServerView::OnShowtree() 
{
	options.mode = 1;	
	Refresh();
}

void CServerView::OnShowlog() 
{
	options.mode = 0;	
	Refresh();	
}

