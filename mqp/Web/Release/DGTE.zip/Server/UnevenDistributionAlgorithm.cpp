/*     CONTENT: implementation of class UnevenDistributionAlgorithm
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#include "stdafx.h"
#include "Server.h"
#include "UnevenDistributionAlgorithm.h"

#define RPCSLEEP 10 // msec
#define RPCSLEEP_ON_ERROR 100 // msec
#define MAXBUSYTHREADSPERHELPER 100 
#define DCOMRETRIES 0
#define ESTIMATED_OVERHEAD_DELAY 1000 // msec
// #define NO_LOAD_BALANCING

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

UINT UnevenDistributionAlgorithm::run(LPVOID pParam)
{
	// get the parameters
	DistributionAlgorithmParameters* params = (DistributionAlgorithmParameters*) pParam;
	GameTreeNode*		node		= params->node;
	vector<Helper*>		helpers		= params->helpers;
	SimpleDateTime*		deadline	= params->deadline;
	DistributionAlgorithm* distributor = params->distributor;
	delete params;

	// remove all dead helpers from the list:
	vector<Helper*>::iterator ih;
	Helper* chosenHelper;
	for (ih = helpers.begin(); ih != helpers.end(); ih++) {
		chosenHelper = *ih;
		if (!chosenHelper->getAvailable()) {	
			helpers.erase(ih);
		}
	}

	char _tmp [5000];

	// find out how much resources we can operate on:	
	Helper* fastestHelper = NULL;
	chosenHelper = NULL;
	int aveCount = 0;
	long nps, bestPerformance = 0;	
	float aveNodesPerSec = 0;
	long sumNodesPerSec = 0;
	for (ih = helpers.begin(); ih != helpers.end(); ih++) {
		chosenHelper = *ih; 
		chosenHelper->recalculateSpeed();
		nps = chosenHelper->getPerformance().getSpeed();
		sprintf(_tmp, "Helper speed [%s]: %d", chosenHelper->getAddress().ipAddress, chosenHelper->getPerformance().getSpeed());
		distributor->log(_tmp);
		sumNodesPerSec += nps;
		aveCount++;
		if (bestPerformance < nps) {
			fastestHelper = chosenHelper;
			bestPerformance = nps;
		}		 
	}

	if (fastestHelper==NULL) {
		// all helpers died so we quit
		node->setEvaluationFailed(true);
		node->markProcessingDone();
		return (UINT)0;
	}

	// calculate average performance:
	aveNodesPerSec = (float) sumNodesPerSec / aveCount;

	// perform the split using the fastest helper
	chosenHelper = fastestHelper;
	try {
		char tmpChar[200];
		// until we get at least one child evaluation done, this node is
		// considered not processed (failed to be processed)
		node->setEvaluationFailed(true);
		sprintf(tmpChar, "Assigned node split: %d: to helper: %d: %s", (long) node, (long) chosenHelper->getHelperID(), chosenHelper->getAddress().ipAddress);
		distributor->log(tmpChar);
		chosenHelper->splitBoard(node);
		sprintf(tmpChar, "Node split completed: %d", (long) node);
		distributor->log(tmpChar);
	} catch (HelperDeadException *e) {
		e->Delete();
	}

	// find out how much we have to do:
	vector<GameTreeNode*> kids = node->getChildNodes();
	if (kids.size()==0) {
		// server cannot make any moves
		node->setEvaluationFailed(true);
		node->markProcessingDone();
		return (UINT)0;
	}
	float totalUnits = kids.size(); 

	float normalPerHelperUnits = (float) (totalUnits) / helpers.size();

	sprintf(_tmp, "Normal units per helper: %f", normalPerHelperUnits);
	distributor->log(_tmp);

	// adjust the cache size depending on individual performance
	int totalThreads = 0;
	int totalLoadUnits = 0;
	for (ih = helpers.begin(); ih != helpers.end(); ih++) {
		chosenHelper = *ih;
		float nodesPerSec		= chosenHelper->getPerformance().getSpeed();				
		float desiredUnits		= (float) totalUnits * ( nodesPerSec / sumNodesPerSec);

		int desiredCache = (int) desiredUnits; 		
		if (((float) desiredCache) < desiredUnits) desiredCache++; // float -> int error correction
		int desiredLoad = (int) desiredUnits;
		if (desiredCache<=3) desiredCache = 5; // almost double
		else if (desiredCache<=10) desiredCache = 1.5 * desiredCache; // add %50
		else desiredCache = 1.3 * desiredCache; // add %30

#ifdef NO_LOAD_BALANCING
		desiredLoad				= normalPerHelperUnits;
		if (((float) desiredLoad) < normalPerHelperUnits) desiredLoad++; // float -> int error correction
#endif
		
		sprintf(_tmp, "Helper [%s] will have %d theads", chosenHelper->getAddress().ipAddress, desiredCache);
		distributor->log(_tmp);
		sprintf(_tmp, "Helper [%s] will have %d work units", chosenHelper->getAddress().ipAddress, desiredLoad);
		distributor->log(_tmp);

		// adjust the current cache and desired load:
		chosenHelper->setDesiredLoad(desiredLoad);
		chosenHelper->lockCacheAdjustment(false);
		chosenHelper->setDesiredCacheSize(desiredCache);
		totalThreads += desiredCache;
		totalLoadUnits += desiredLoad;
	}

	// double check to make sure that we have enough threads:
	int additionalCache = (int) totalUnits - totalThreads;
	if (additionalCache > 0) {
		distributor->log("Need for theard cache addition!!!");
		fastestHelper->setDesiredCacheSize(fastestHelper->getCurrentCacheSize() + additionalCache);
	}

	int additionalLoad = (int) totalUnits - totalLoadUnits;
	if (additionalLoad > 0) {
		fastestHelper->setDesiredLoad(fastestHelper->getDesiredLoad() + additionalLoad);
	}

	// lock all the future cache adjustments:
	for (ih = helpers.begin(); ih != helpers.end(); ih++) {
		chosenHelper = *ih;
		chosenHelper->lockCacheAdjustment(true);
	}

	int nodeIndex = 0;
	GameTreeNode* childNode;
	for (ih = helpers.begin(); ih != helpers.end(); ih++) {
		chosenHelper = *ih;
		chosenHelper->lockBusyThreadCounts();
		int units = chosenHelper->getDesiredLoad();
		for (int c=0; c<units; c++) {
			if (nodeIndex<totalUnits) {
				// assign kids[nodeIndex] to chosenHelper
				childNode = kids[nodeIndex++];
				HelperAssigmentParameters*	threadParams = new HelperAssigmentParameters;
				threadParams->node			= childNode;
				threadParams->helper		= chosenHelper;
				threadParams->helpers		= helpers;
				threadParams->deadline		= deadline;
				threadParams->distributor   = distributor;
				AfxBeginThread(assignHelper, (LPVOID) threadParams);
				::Sleep(RPCSLEEP);
			}
		}
		chosenHelper->unlockBusyThreadCounts();
	}

	
	// all the distribution has been completed so we can quit.
	// note: the helpers might still be working on the nodes.
	return (UINT)0;
}

UINT UnevenDistributionAlgorithm::assignHelper(LPVOID pParam)
{
	HelperAssigmentParameters* params = (HelperAssigmentParameters*) pParam;
	GameTreeNode*	node		= params->node;
	SimpleDateTime*	deadline	= params->deadline;
	Helper*			helper		= params->helper;
	vector<Helper*>	helpers		= params->helpers;
	DistributionAlgorithm* distributor = params->distributor;
	delete params;

	char tmpChar[200];
	vector<Helper*>::iterator eHelpers;	

	SimpleDateTime now;	
	int evalTries = DCOMRETRIES;
	do {
		now.setToNow();
		long timeout = *deadline  -  now;
		if (timeout<0) {
			// we are already late, so we just quit:
			sprintf(tmpChar, "Timeout, Node eval failed: %d", (timeout), (long) node);
			distributor->log(tmpChar);
			node->setEvaluationFailed(true);
			node->markProcessingDone();
			return (UINT)0;
		}
		try {
			sprintf(tmpChar, "Assigned node eval: %d: to helper: %d: %s", (long) node, (long) helper->getHelperID(), helper->getAddress().ipAddress);
			distributor->log(tmpChar);
			helper->evaluateBoard(node, timeout - ESTIMATED_OVERHEAD_DELAY);
			node->setEvaluationFailed(false);
			sprintf(tmpChar, "Node eval completed: %d", (long) node);
			distributor->log(tmpChar);
			node->markProcessingDone();
			return (UINT)0;
		} catch (HelperDeadException *e) {			
			e->Delete();
			
			sprintf(tmpChar, "AVAILABLE CHANCES: %d", evalTries);				
			distributor->log(tmpChar);				
			
			Helper* theHelper;
			if (evalTries>0) {								
				evalTries--;
				helper->setAvailable(true);
				distributor->log("DCOM RETRY");				
				::Sleep(RPCSLEEP_ON_ERROR);
			} else {
				distributor->log("NO MORE CHANCES");				

				helper->setAvailable(false);
				sprintf(tmpChar, "DCOM Error, Node eval failed: %d", (long) node);				
				distributor->log(tmpChar);				
				// see if we can reassign the unit of work:
				helper = NULL; // assume no
				
				// try to find a helper with less running threads than the desired load
				eHelpers = helpers.begin();	
				do {
					theHelper = *eHelpers;
					if (
							theHelper->getAvailable() && 
							(theHelper->getBusyThreadsCount() < theHelper->getDesiredLoad()) 
						) helper = theHelper;
					eHelpers++;
				} while (helper==NULL && eHelpers!=helpers.end());

				// see if we found one:
				if (helper != NULL) {
					// yes, we did
					evalTries = DCOMRETRIES; // the new helper should get tries too
				} else {
					// we didn't find an underloaded helper, so we just
					// try to find the first helper available:
					eHelpers = helpers.begin();	
					do {
						theHelper = *eHelpers;
						if (theHelper->getAvailable()) helper = theHelper;
						eHelpers++;
					} while (helper==NULL && eHelpers!=helpers.end());
					// check if we found one:
					if (helper == NULL) {
						// no, all the helpers are dead
						node->setEvaluationFailed(true);
						node->markProcessingDone();
						return (UINT)0;
					} else {
						// we found
						evalTries = DCOMRETRIES; // the new helper should get tries too
					}
				}
			}
		}
	} while (true);
	return (UINT)0;
}

void UnevenDistributionAlgorithm::start(GameTreeNode* node, vector<Helper*> helpers, SimpleDateTime* deadline)
{
	DistributionAlgorithmParameters* threadParams = new DistributionAlgorithmParameters;
	threadParams->node = node;
	threadParams->helpers = helpers;
	threadParams->deadline = deadline;
	threadParams->distributor = (DistributionAlgorithm*) this;
	AfxBeginThread(run, (LPVOID) threadParams);
}

void UnevenDistributionAlgorithm::setLogContext(LogContext* new_log)
{
	this->logContext = new_log;
}

void UnevenDistributionAlgorithm::log(CString event) {
	char hid[30];
	sprintf(hid, "[%d]", (long) this);
	CString tmp = hid;
	if (logContext!=NULL) logContext->addEntry("DISTRIBUTOR", tmp , event);
}