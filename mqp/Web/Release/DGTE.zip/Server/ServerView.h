/*     CONTENT: definition of class ServerView
 *      AUTHOR: Peter Golaszewski
 *     UPDATED: 2/19/2000
 *       LEGAL: Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.
 */

#if !defined(AFX_SERVERVIEW_H__2CE3C486_A77B_11D3_90F1_004095100085__INCLUDED_)
#define AFX_SERVERVIEW_H__2CE3C486_A77B_11D3_90F1_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ServerView.h"
#include "ViewOptionsData.h"
#include "ViewOptionsDialog.h"

typedef struct tagNodeInfo {
	long node_number;
	CString node_state;
	long helper_number;
	CString helper_name;
	vector<void*> children;
} NodeInfo;

/*
 * This is the view class.
 *
 */
class CServerView : public CEditView {

public:
	NodeInfo* TDSearchNode(long nNode, NodeInfo* pStart);
	void Refresh();
	CServerDoc* GetDocument();


protected:
		long lastCount;
		// create from serialization only
		DECLARE_DYNCREATE(CServerView)

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerView)
	protected:
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

	protected:
		CSemaphore viewLock;
		NodeInfo* TDFindNode(long nNode);
		void TDExtractTree(NodeInfo *pNode, int spacing, basic_string<char> *result);
		void TDDeleteNode(NodeInfo* pNode);
		basic_string<char> TDGetTrees();
		void TDAddRootNode(long nNode);
		void TDClear();
		void TDAddChildNode(long nParentNode, long nChildNode);
		void TDSetNodeHelper(long nNode, long nHelper, CString sHelper);
		void TDSetNodeStatus(long nNode, CString cStatus);
		void TDRemoveRootNode(long nNode);
		vector<NodeInfo*> knownTrees;

		ViewOptionsData options;
	//{{AFX_MSG(CServerView)
	afx_msg void OnViewoptions();
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnShowtree();
	afx_msg void OnShowlog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ServerView.cpp
inline CServerDoc* CServerView::GetDocument()
   { return (CServerDoc*)m_pDocument; }
#endif


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERVIEW_H__2CE3C486_A77B_11D3_90F1_004095100085__INCLUDED_)
