public class Board
{
    int board[];
    public void reset() {
        int a;
        board = new int[15];
        for (a = 3; a<=14; a++) board[a] = 4;
        board[0] = 0; // server will be up
        board[1] = 0; // our score is 0
        board[2] = 0; // server score is 0
        
        // custom set:
        /*
        board[0] = 0;
        board[1] = 3;
        board[2] = 7;
        board[3] = 5;
        board[4] = 0;
        board[5] = 0;
        board[6] = 7;
        board[7] = 2;
        board[8] = 7;
        board[9] = 6;
        board[10] = 0;
        board[11] = 0;
        board[12] = 6;
        board[13] = 0;
        board[14] = 5;
        */
    }
    public String getBoard() {
        int a;
        String s;
        Integer i;
        String result = "";
        for (a = 0; a<=14; a++) {
            i = new Integer(board[a]);            
            s = new String(i.toString());
            result = result + s;
            if (a < 14) result = result + ",";           
        }
        return result;
    }

    public boolean isOver() {        
        boolean over;
        over=true;
        int a;
        for (a = 9; a<=14; a++) 
            if (board[a]!=0) over=false;
        if (over) return true;
        over=true;
        for (a = 3; a<=8; a++) 
            if (board[a]!=0) over=false;
        return over;
    }    

    public void displayBoard() {
        int a;
        String s;
        Integer i;
        System.out.print("\n\n\n");                       
        System.out.print("\nCOMPUTER");                       
        System.out.print("\n--------------------------\n");                       
        System.out.print("     ");        
        for (a = 9; a<=14; a++) {
            i = new Integer(board[a]);            
            s = new String(i.toString());
            if (board[a]==0) System.out.print(".  "); 
                else System.out.print(s + "  ");        
        }        
        System.out.print("\n");          
        i = new Integer(board[2]);            
        s = new String(i.toString());
        System.out.print(" [" + s + "]");  
        System.out.print("                 ");  
        i = new Integer(board[1]);            
        s = new String(i.toString());
        System.out.print(" [" + s + "]");  
        System.out.print("\n");
        System.out.print("     ");        
        for (a = 3; a<=8; a++) {
            i = new Integer(board[a]);            
            s = new String(i.toString());
            if (board[a]==0) System.out.print(".  "); 
                else System.out.print(s + "  ");        
        }                
        System.out.print("\n--------------------------\n");                
        System.out.print("YOU: 1  2  3  4  5  6\n");   
    }    
    
    boolean makeMove(int position) {        
        int player=0, midx=0;
        if (position <= 8) {
            player = 1; // DOWN PLAYER
            midx = 6;
        } else {
            player = 0; // UP PLAYER
            midx = 13;
        }
        
        // rewrite the board:
        int p2 = 0;
        if (position==3) p2 = 0;
        if (position==4) p2 = 1;
        if (position==5) p2 = 2;
        if (position==6) p2 = 3;
        if (position==7) p2 = 4;
        if (position==8) p2 = 5;
        // 6 - down M
        if (position==9) p2 = 12;
        if (position==10) p2 = 11;
        if (position==11) p2 = 10;
        if (position==12) p2 = 9;
        if (position==13) p2 = 8;
        if (position==14) p2 = 7;
        // 13 - up M  
        
        int b2[];
        b2 = new int [20];
        // BOARD MAP
        b2[0] = board[3];
        b2[1] = board[4];
        b2[2] = board[5];
        b2[3] = board[6];
        b2[4] = board[7];
        b2[5] = board[8];        
        b2[6] = board[1]; // down M                
        b2[7]  = board[14];
        b2[8]  = board[13];
        b2[9]  = board[12];
        b2[10] = board[11];
        b2[11] = board[10];
        b2[12] = board[9]; 
        b2[13] = board[2]; // down M                
        board[position] = 0;
        
        int rocks = b2[p2]; // pick up the rocks
        b2[p2] = 0;
        
        int direction=1;
        while (rocks > 0) {
            // advance position:
            p2 = p2 + direction;
            if (p2 < 0) p2 = 13;
            if (p2 > 13) p2 = 0;
            b2[p2] = b2[p2] + 1;
            rocks = rocks - 1;
        }
        boolean rval;
        // one rock rule:
        if ((p2 != 6) && (p2 != 13)) {
            // check the count
            if (b2[p2] == 1) {
                // yap, steal the rocks from opposite side:                
                int opposite=0;
                if (p2==0) opposite = 12;
                if (p2==1) opposite = 11;
                if (p2==2) opposite = 10;
                if (p2==3) opposite = 9;
                if (p2==4) opposite = 8;
                if (p2==5) opposite = 7;
                if (p2==7) opposite = 5;
                if (p2==8) opposite = 4;
                if (p2==9) opposite = 3;
                if (p2==10) opposite = 2;
                if (p2==11) opposite = 1;
                if (p2==12) opposite = 0;
                b2[midx] = b2[midx] + b2[opposite];
                b2[opposite] = 0;
            }
            rval = false;
        } else rval = true;
 
        // BOARD UN-MAP
        board[3] = b2[0];
        board[4] = b2[1];
        board[5] = b2[2];
        board[6] = b2[3];
        board[7] = b2[4];
        board[8] = b2[5];        
        board[1] = b2[6]; // down M                
        board[14] = b2[7];
        board[13] = b2[8];
        board[12] = b2[9];
        board[11] = b2[10];
        board[10] = b2[11];
        board[9] = b2[12]; 
        board[2] = b2[13]; // down M                
        
        return rval;
    }
}