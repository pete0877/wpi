import java.util.*;
import java.awt.*;

public class DGTEServerMoveMessageText extends java.awt.TextField implements MessagePipeConnection
{
	public void addMessagePipeConnection(DGTEMessagePipe mp){}
	public void handleMessage(DGTEMessage m)
	{
	    String msg;
        if(m.getType().equals("SERVER_MOVE"))
        {
	        Enumeration e=m.getParts();
            e.nextElement();
            e.nextElement();
            e.nextElement();
            e.nextElement();
            msg = (String)e.nextElement();
            this.setText(msg);
	    }
	}
	public void pipeMessage(DGTEMessage m){}
}