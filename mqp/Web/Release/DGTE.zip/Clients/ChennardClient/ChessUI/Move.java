/////////////////////////////////////////////////////////////////////////////
//
// File Name:	Move.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class Move

public class Move
{
	//
	// Attributes
	//

	protected Square from;
	protected Square to;
	protected Move castledMove;
	protected Piece capturedPiece;
	protected Piece enpassantCapturedPiece;
	protected Square enpassantCapturedSquare;
	protected Piece promoteePiece;
	protected Piece promotedPiece;

	//
	// Constructors
	//

	public Move(Square from, Square to) {
		setFrom(from);
		setTo(to);
		setCastledMove(null);
		setCapturedPiece(null);
		setEnPassantCapturedPiece(null, null);
		setPromoteePiece(null);
		setPromotedPiece(null);
	}

	//
	// Properties
	//

	public Square getFrom() {
		return from;
	}

	public void setFrom(Square from) {
		if( from != null )
			this.from = from;
		else
			throw new IllegalArgumentException("Move: Invalid from square");
	}

	public Square getTo() {
		return to;
	}

	public void setTo(Square to) {
		if( to != null )
			this.to = to;
		else
			throw new IllegalArgumentException("Move: Invalid to square");
	}

	public Move getCastledMove() {
		return castledMove;
	}

	public void setCastledMove(Move move) {
		castledMove = move;
	}

	public Piece getCapturedPiece() {
		return capturedPiece;
	}

	public void setCapturedPiece(Piece piece) {
		capturedPiece = piece;
	}

	public Piece getEnPassantCapturedPiece() {
		return capturedPiece;
	}

	public void setEnPassantCapturedPiece(Piece piece, Square square) {
		enpassantCapturedPiece = piece;
		enpassantCapturedSquare = square;
	}

	public Piece getPromoteePiece() {
		return promoteePiece;
	}

	public void setPromoteePiece (Piece piece) {
		promoteePiece = piece;
	}

	public Piece getPromotedPiece() {
		return promotedPiece;
	}

	public void setPromotedPiece (Piece piece) {
		promotedPiece = piece;
	}

	//
	// Methods
	//

	public int columnOffset() {
		return to.columnOffset(from);
	}

	public int rowOffset() {
		return to.rowOffset(from);
	}

	//
	// Overrides
	//

	public String toString() {
		if( castledMove != null ) {
			if( columnOffset() == 2 )
				return "O-O";
			else
				return "O-O-O";
		}
		else {
			StringBuffer sb = new StringBuffer();

			sb.append(from.toString());

			if (capturedPiece != null) {
				sb.append (" x ");
				sb.append (capturedPiece.getType());
			} else
				sb.append (" ");

			sb.append(to.toString());

			if( promoteePiece != null )
				sb.append (": Pawn Promoted to " + promotedPiece.toString());

			if( capturedPiece != null )
				sb.append (": " + capturedPiece.toString() + " Captured");

			return sb.toString();
		}
	}
}

