/////////////////////////////////////////////////////////////////////////////
//
// File Name:	Queen.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class Queen

public class Queen extends Piece
{
	//
	// Constructors
	//

	public Queen(int color) {
		super(color, 'Q', "Queen");
	}

	//
	// Overrides
	//

	public final boolean canAttack(ChessBoard board, Square from, Square to) {

		if( to.equals(from) )
			return false;

		int rowoffset = Math.abs(from.rowOffset(to));
		int coloffset = Math.abs(from.columnOffset(to));

		if( !from.sameColumn(to) && !from.sameRow(to) &&
			!(rowoffset == coloffset))
			return false;

		if( !board.isClear(from, to) )
			return false;

		return true;
	}
}
