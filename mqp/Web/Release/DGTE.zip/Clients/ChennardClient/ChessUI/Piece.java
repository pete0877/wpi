/////////////////////////////////////////////////////////////////////////////
//
// File Name:	Piece.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class Piece

public abstract class Piece
{
	//
	// Constants
	//

	public final static int BLACK = 0;
	public final static int WHITE = 1;

	//
	// Attributes
	//

	private int color;
	private char type;
	private String description;
	private int moveIndex;

	//
	// Constructors
	//

	public Piece(int color, char type, String desc) {
		setColor(color);
		setType(type);
		setDescription(desc);
		setMoveIndex(-1);
	}

	//
	// Properties
	//

	public int getColor() {
		return color;
	}

	protected void setColor(int color) {
		if( (color == BLACK) || (color == WHITE) )
			this.color = color;
		else
			throw new IllegalArgumentException("Piece: Invalid color specified.");
	}

	public char getType() {
		return type;
	}

	protected void setType(char type) {
		this.type = type;
	}


	public String getDescription() {
		return description;
	}

	protected void setDescription(String description) {
		this.description = description;
	}

	public int getMoveIndex() {
		return moveIndex;
	}

	public void setMoveIndex(int moveIndex) {
		this.moveIndex = moveIndex;
	}

	//
	// Methods
	//

	public boolean hasMoved() {
		return (moveIndex != -1);
	}

	public boolean isWhite() {
		return (color == Piece.WHITE);
	}

	//
	// Implementation
	//

	protected boolean canCapture(ChessBoard board, Square target) {

		Piece capturedPiece = board.getPiece(target);

		if( (capturedPiece != null) && (getColor() == capturedPiece.getColor()))
			return false;
		else
			return true;
	}

	//
	// Overridables
	//

	public boolean isLegalMove(ChessBoard board, Move move) {

		Square from = move.getFrom();
		Square to = move.getTo();

		if( !canCapture(board, to) )
			return false;

		if( !canAttack(board, from, to) )
			return false;

		return true;
	}


	public void move(ChessBoard board, Move move) throws BadMoveException {

		if( isLegalMove(board, move) ) {
			board.movePiece(move);
			setMoveIndex(board.getMoveIndex());
		}
		else
			throw new BadMoveException(move.toString());
	}

	public abstract boolean canAttack(ChessBoard board, Square from, Square to);

	//
	// Overrides
	//

	public String toString() {
		StringBuffer sb = new StringBuffer();
		if( isWhite() )
			sb.append("W-");
		else
			sb.append("B-");
		sb.append(getDescription());
		return sb.toString();
	}
}
