/////////////////////////////////////////////////////////////////////////////
//
// File Name:	ChessSet.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

import java.awt.Component;
import java.awt.Image;
import java.awt.MediaTracker;

/////////////////////////////////////////////////////////////////////////////
// Class ChessSet

public class ChessSet
{
	//
	// Attributes
	//

	protected Component component;
	protected String setName;
	protected Image images[][];

	//
	// Constructors
	//

	public ChessSet(Component component, String setName) {

		this.component = component;
		this.setName = setName;
		this.images = new Image[7][2];

		loadImages();
	}

	//
	// Properties
	//

	public Image getImage(Piece piece) {

		int index = getIndex(piece);

		if(index == -1)
			return null;
		else
			return images[index][piece.getColor()];
	}

	public Image getBlankImage(int color) {

		return images[0][color];
	}

	//
	// Implementation
	//

	protected void loadImages() {

		images[0][Piece.WHITE] = getImage("WBlank.gif");
		images[1][Piece.WHITE] = getImage("WPawn.gif");
		images[2][Piece.WHITE] = getImage("WRook.gif");
		images[3][Piece.WHITE] = getImage("WKnight.gif");
		images[4][Piece.WHITE] = getImage("WBishop.gif");
		images[5][Piece.WHITE] = getImage("WQueen.gif");
		images[6][Piece.WHITE] = getImage("WKing.gif");

		images[0][Piece.BLACK] = getImage("BBlank.gif");
		images[1][Piece.BLACK] = getImage("BPawn.gif");
		images[2][Piece.BLACK] = getImage("BRook.gif");
		images[3][Piece.BLACK] = getImage("BKnight.gif");
		images[4][Piece.BLACK] = getImage("BBishop.gif");
		images[5][Piece.BLACK] = getImage("BQueen.gif");
		images[6][Piece.BLACK] = getImage("BKing.gif");

        MediaTracker mt = new MediaTracker(component);

        for( int i = 0; i < 7; i++ )
        	for( int j = 0; j < 2; j++ )
        		mt.addImage(images[i][j], 0);

		try {
			mt.waitForAll();
		} catch(InterruptedException e) {}

	}

	protected Image getImage(String fileName) {

        String imageFile = System.getProperty("user.dir") + "/Images/" + setName + "/" + fileName;
        Image image = component.getToolkit().getImage(imageFile);
        return image;
	}

	protected int getIndex(Piece piece) {

		if( piece instanceof Pawn )
			return 1;
		else if( piece instanceof Rook )
			return 2;
		else if( piece instanceof Knight )
			return 3;
		else if( piece instanceof Bishop )
			return 4;
		else if( piece instanceof Queen )
			return 5;
		else if( piece instanceof King )
			return 6;
		else
			return -1;
	}
}
