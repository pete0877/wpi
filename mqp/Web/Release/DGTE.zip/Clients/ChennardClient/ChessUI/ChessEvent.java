/////////////////////////////////////////////////////////////////////////////
//
// File Name:	ChessEvent.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

import java.util.EventObject;

/////////////////////////////////////////////////////////////////////////////
// Class ChessListener

public class ChessEvent extends EventObject
{
	//
	// Constants
	//

	public final static int MOVE = 0;

	//
	// Attributes
	//

	protected int id;
	protected Move move;

	//
	// Constructors
	//

	public ChessEvent(Object o, int id, Move move) {
		super(o);
		setID(id);
		setMove(move);
	}

	//
	// Properties
	//

	public Move getMove() {
		return move;
	}

	public void setMove(Move move) {
		this.move = move;
	}

	public int getID() {
		return id;
	}

	public void setID(int id) {
		this.id = id;
	}

	//
	// Overrides
	//

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(id);
		sb.append(move.toString());
		return sb.toString();
	}
}
