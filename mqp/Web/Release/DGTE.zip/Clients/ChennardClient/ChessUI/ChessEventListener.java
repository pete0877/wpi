/////////////////////////////////////////////////////////////////////////////
//
// File Name:	ChessEventListener.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

import java.util.EventListener;

/////////////////////////////////////////////////////////////////////////////
// Class ChessEventListener

public interface ChessEventListener extends EventListener
{
	void handleChessEvent(ChessEvent event);
}
