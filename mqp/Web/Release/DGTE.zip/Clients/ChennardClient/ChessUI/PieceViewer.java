/////////////////////////////////////////////////////////////////////////////
//
// File Name:	PieceViewer.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

import java.awt.Component;
import java.util.Observer;
import java.util.Observable;

/////////////////////////////////////////////////////////////////////////////
// Class PieceViewer

public class PieceViewer extends Component implements Observer
{
	//
	// Attributes
	//

	protected ObservableList pieces;

	//
	// Constructors
	//

	public PieceViewer() {
		pieces = null;
	}

	public PieceViewer(ObservableList list) {
		init(list);
	}

	//
	// Methods
	//

	public void init(ObservableList list) {
		pieces = list;
		pieces.addObserver(this);
	}

	public void update(Observable o, Object arg)  {
		// NOTE: Implement method.
	}
}
