/////////////////////////////////////////////////////////////////////////////
//
// File Name:	BadMoveException.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class BadMoveException

public class BadMoveException extends Exception {

	public BadMoveException() {
		super();
	}

	public BadMoveException(String s) {
		super(s);
	}
}
