/////////////////////////////////////////////////////////////////////////////
//
// File Name:	King.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class King

public class King extends Piece {

	//
	// Constructors
	//

	public King(int color) {
		super(color, 'K', "King");
		setCastlingFlag(false);
		setRookMove(null);
	}

	//
	// Overrides
	//

	public final boolean canAttack(ChessBoard board, Square from, Square to) {

		if( to.equals(from) )
		 	return false;

		int rowoffset = Math.abs(from.rowOffset(to));
		int coloffset = Math.abs(from.columnOffset(to));

		if( !(rowoffset <= 1) || !(coloffset <= 1) )
			return false;

		return true;
	}

	public final boolean isChecked(ChessBoard board) {
		Square kingSq = board.getKingSquare(getColor());
		if( !board.isSafe(kingSq, getColor()) )
			return true;
		else
			return false;
	}

	public final boolean isLegalMove (ChessBoard board, Move move) {

		setCastlingFlag(false);

		Square from = move.getFrom();
		Square to = move.getTo();

		int rowoffset = Math.abs(move.rowOffset());
		int coloffset = Math.abs(move.columnOffset());

		if( (rowoffset == 0) && (coloffset == 2) )
			return (checkCastling(board, from, to));

		if( !canCapture(board, to) )
			return false;

		if( !canAttack(board, from, to) )
			return false;

		if( !board.isSafe(to, getColor()) )
			return false;

		return true;
	}

	public final void move(ChessBoard board, Move move) throws BadMoveException {

		if( isLegalMove(board, move) ) {

			board.movePiece(move);
			setMoveIndex(board.getMoveIndex());

			if( getCastlingFlag() ) {
				Piece piece = board.getPiece(rookMove.getFrom());
				board.movePiece(rookMove, false);
				piece.setMoveIndex(board.getMoveIndex());
				move.setCastledMove(rookMove);
				setCastlingFlag(false);
				setRookMove(null);
			}
		}
		else
			throw new BadMoveException(move.toString());
	}

	//
	// Implementation
	//

	private Move rookMove;
	private boolean castlingFlag;

	private boolean getCastlingFlag() {
		return castlingFlag;
	}

	private void setCastlingFlag(boolean flag) {
		this.castlingFlag = flag;
	}

	private void setRookMove(Move move) {
		this.rookMove = move;
	}

	private boolean checkCastling(ChessBoard board, Square from, Square to) {

		int row = getOriginalRow();
		int color = getColor();

		if( (from.getColumn() == 'e') && (from.getRow() == row)) {
			if( to.getColumn() == 'g' ) {
				Piece rook = board.getPiece('h', row);

				if( rook == null)
					return false;

				if( hasMoved() || rook.hasMoved() )
					return false;

				if( !board.isSafe(new Square('e', row), color) )
					return false;

				if( !board.isSafe(new Square('f', row), color) )
					return false;

				if( !board.isSafe(new Square('g', row), color) )
					return false;

				if( board.getPiece('f', row) != null )
					return false;

				if( board.getPiece('g', row) != null )
					return false;

				// NOTE: Changed from - Square src = board.getSquare ('h', row);
				Square src = new Square('h', row);
				Square dest = new Square ('f', row);
				setCastlingFlag(true);
				setRookMove(new Move (src, dest));

				return true;
			}
			if( to.getColumn() == 'c' ) {
				Piece rook = board.getPiece ('a', row);

				if( rook == null)
					return false;

				if( hasMoved() || rook.hasMoved() )
					return false;

				if( !board.isSafe(new Square('e', row), color) )
					return false;

				if( !board.isSafe(new Square('d', row), color) )
					return false;

				if( !board.isSafe(new Square('c', row), color) )
					return false;

				if( !board.isSafe(new Square('b', row), color) )
					return false;

				if( board.getPiece('d', row) != null )
					return false;

				if( board.getPiece('c', row) != null )
					return false;

				if( board.getPiece('b', row) != null )
					return false;

				// NOTE: Changed from - Square src = board.getSquare('a', row);
				Square src = new Square('a', row);
				Square dest = new Square('d', row);
				setCastlingFlag(true);
				setRookMove(new Move(src, dest));

				return true;
			}
		}

		return false;
	}

	private int getOriginalRow() {
		if( isWhite() )
			return 1;
		else
			return 8;
	}
}
