/////////////////////////////////////////////////////////////////////////////
//
// File Name:	ChessRenderer.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

import java.awt.*;

/////////////////////////////////////////////////////////////////////////////
// Class ChessRenderer

public class ChessRenderer extends Canvas
{
	//
	// Attributes
	//

	protected ChessBoard board;
	protected ChessSet   chessSet;
	protected Font       font;
	protected Color      fgColor;
	protected Color      bgColor;
	protected Color      highlightColor;

	protected Dimension  boardSize;
	protected int        squareSize;
	protected int        borderSize;
	protected int        fontWidth, fontHeight;

	protected int        colorTable[];
	protected Rectangle  positionTable[];

	//
	// Constructors
	//

	public ChessRenderer() {
		board      = null;
		chessSet   = null;
		font       = new Font ("Helvetica", Font.BOLD, 12);
		fgColor    = Color.white;
		bgColor    = new Color(0, 0, 0);
		highlightColor = Color.red;
		fontWidth  = 8;
		fontHeight = 14;
		boardSize  = null;
		colorTable = null;
		positionTable = null;
		initColorTable();
	}

	public ChessRenderer(ChessBoard board, ChessSet chessSet) {
		this();
		init(board, chessSet);
	}

	//
	// Properties
	//

	public ChessBoard getChessBoard() {
		return board;
	}

	public void setChessBoard(ChessBoard board) {	// CHECK: What happens if board is null?
		this.board = board;
		updateBoard();
	}

	public ChessSet getChessSet() {
		return chessSet;
	}

	public void setChessSet(ChessSet chessSet) {	// CHECK: What happens if chessSet is null?
		this.chessSet = chessSet;
		updateMetrics();
		updateBoard();
	}

	public Color getBgColor() {
		return bgColor;
	}

	public void setBgColor(Color color) {
		bgColor = color;
		updateBoard();
	}

	public Color getFgColor() {
		return fgColor;
	}

	public void setFgColor(Color color) {
		fgColor = color;
		updateBoard();
	}

	public Color getHighlightColor() {
		return highlightColor;
	}

	public void setHighlightColor(Color color) {
		highlightColor = color;
		updateBoard();
	}

	//
	// Methods
	//

	public void init(ChessBoard board, ChessSet chessSet) {
		setChessBoard(board);
		setChessSet(chessSet);
	}

	public Square getSquare(Point point) {

		if( positionTable == null )
			return null;

		for( int i = 0; i < positionTable.length; i++ ) {

			Rectangle rect = positionTable[i];

			if( rect.contains(point) )
				return new Square(i);
		}

		return null;
	}

	// TODO: Select disappears once a different square is highlighted.
	public void selectSquare(Square square, boolean state) {

		Graphics g = getGraphics();

		if( (g == null) || (board == null) || (boardSize == null) )
			return;

		if( state == true )
			drawHighlight(g, square);
		else
			drawSquare(g, square, board.getPiece(square));
	}

	public void highlightSquare(Square square, boolean state) {

		Graphics g = getGraphics();

		if( (g == null) || (board == null) || (boardSize == null) )
			return;

		if( state == true )
			drawHighlight(g, square);
		else
			drawSquare(g, square, board.getPiece(square));
	}

	public void updateSquare(Square square, Piece piece) {

		Graphics g = getGraphics();

		if( (g == null) || (board == null) || (boardSize == null) )
			return;

		drawSquare(g, square, piece);
	}

	public void updateBoard() {

		Graphics g = getGraphics();

		if( (g == null) || (board == null) || (boardSize == null) )
			return;

		drawBorder(g);
		drawLegend(g);

		for(int i = 0; i < 64; i++) {
			Square square = new Square(i);
			drawSquare(g, square, board.getPiece(square));
		}
	}

	//
	// Implementation
	//

	protected void initColorTable() {
		int color;

		colorTable = new int[64];

		for( int row = 8; row >= 1; row-- ) {
			if( (row % 2) == 0 )
				color = Piece.WHITE;
			else
				color = Piece.BLACK;
			for( char col = 'a'; col <= 'h'; col++ ) {

				Square square = new Square(col, row);
				colorTable[square.getIndex()] = color;

				if( color == Piece.WHITE )
					color = Piece.BLACK;
				else
					color = Piece.WHITE;
			}
		}
	}

	protected void initPositionTable(int borderSize, int squareSize) {
		int x = borderSize;
		int y = borderSize;

		positionTable = new Rectangle[64];

		for( int row = 8; row >= 1; row-- ) {
			x = borderSize;
			for( char col = 'a'; col <= 'h'; col++ ) {

				Square square = new Square(col, row);
				Rectangle rect = new Rectangle(x, y, squareSize, squareSize);
				positionTable[square.getIndex()] = rect;

				x += squareSize;
			}
			y += squareSize;
		}
	}

	protected void drawBorder(Graphics g) {

		g.setColor(bgColor);

		g.fillRect(0, 0, (int) boardSize.width, borderSize);

		g.fillRect(0, boardSize.height - borderSize,
				boardSize.width, borderSize);

		g.fillRect(0, 0, borderSize, boardSize.height);

		g.fillRect(boardSize.width - borderSize, 0,
				borderSize, boardSize.height);
	}

	protected void drawHighlight(Graphics g, Square square) {

		g.setColor(highlightColor);

		Point point = positionTable[square.getIndex()].getLocation();

		g.drawRect(point.x, point.y, squareSize - 1, squareSize - 1);
		g.drawRect(point.x + 1, point.y + 1, squareSize - 3, squareSize - 3);
	}

	protected void drawLegend(Graphics g) {

		int x, y;

		g.setColor(fgColor);
		g.setFont(font);

		y = borderSize + 8 * squareSize + borderSize / 2 + fontHeight / 4;

		for( char col = 'a'; col <= 'h'; col++ ) {
			int offset = col - 'a';
			x = borderSize + offset*squareSize + squareSize/2 - fontWidth/2;
			g.drawString(new Character(col).toString(), x, y);
		}

		x = borderSize / 2 - fontWidth / 2;

		for( char row = '8'; row >= '1'; row-- ) {
			int offset = '8' - row;
			y = borderSize + offset*squareSize + squareSize/2 + fontHeight/4;
			g.drawString(new Character(row).toString(), x, y);
		}
	}

	protected void drawSquare(Graphics g, Square square, Piece piece) {

		Point point = positionTable[square.getIndex()].getLocation();

		int color = colorTable[square.getIndex()];
		Image blankImage = chessSet.getBlankImage(color);
		Image pieceImage = chessSet.getImage(piece);

		g.drawImage(blankImage, point.x, point.y, this);

		if( pieceImage != null )
			g.drawImage(pieceImage, point.x, point.y, this);
	}

	protected void invalidateBoard() {
		boardSize = null;
		positionTable = null;
	}

	protected void updateMetrics() {

		invalidateBoard();

		if( chessSet == null )
			return;

		Image square = chessSet.getBlankImage(Piece.WHITE);
		squareSize   = square.getWidth(null);
		borderSize   = fontHeight * 4 / 3;

		boardSize = new Dimension(squareSize * 8 + borderSize * 2, squareSize * 8 + borderSize * 2);

		initPositionTable(borderSize, squareSize);
	}

	//
	// Overrides
	//

	public Dimension getPreferredSize() {
		if( boardSize != null )
			return boardSize;
		else
			return new Dimension(436, 436);
	}

	public void paint(Graphics g) {
		updateBoard();
	}
}
