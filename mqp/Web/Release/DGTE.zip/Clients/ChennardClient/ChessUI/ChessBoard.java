/////////////////////////////////////////////////////////////////////////////
//
// File Name:	ChessBoard.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Observable;
import java.util.Vector;

/////////////////////////////////////////////////////////////////////////////
// Class ChessBoard

public class ChessBoard extends Observable
{
	//
	// Attributes
	//

	protected boolean whitesMoveFlag;
	protected Square kingSquare[];
	protected ObservableList moveList;
	protected ObservableList capturedList;

	protected Hashtable pieces;

	//
	// Constructors
	//

	public ChessBoard() {
		pieces       = new Hashtable(16);
		moveList     = new ObservableList();
		capturedList = new ObservableList();
		whitesMoveFlag = true;
		kingSquare     = new Square[2];
	}

	//
	// Properties
	//

	public Square getKingSquare(int color) {
		return kingSquare[color];
	}

	public void setKingSquare(int color, Square square) {
		kingSquare[color] = square;
	}

	public boolean isWhitesMove() {
		return whitesMoveFlag;
	}

	public void setWhitesMove(boolean flag) {
		whitesMoveFlag = flag;
	}

	//
	// Piece Methods
	//

	public void addPiece(Piece piece, Square sq) {

		sq.setPiece(piece);
		pieces.put(sq.toString(), sq);

		if( piece instanceof King )
			setKingSquare(piece.getColor(), sq);

		setChanged();
		notifyObservers(sq);
	}

	public Piece getPiece(Square location) {

		Square sq = (Square) pieces.get(location.toString());

		if( sq == null )
			return null;
		else
			return sq.getPiece();
	}


	public Piece getPiece(char col, int row) {
		return getPiece(new Square(col, row));
	}

	public void removePiece(Square location) {

		pieces.remove(location.toString());

		setChanged();
		notifyObservers(location);
	}

	public void capturePiece(Square location) {

		Square square = (Square) pieces.remove(location.toString());

		if( square != null ) {

			capturedList.add(square.getPiece());
			square.setPiece(null);

			setChanged();
			notifyObservers(square);
		}
	}

	public void movePiece(Move move) {
		movePiece(move, true);
	}

	public void movePiece(Move move, boolean addIt) {

		Square from = move.getFrom();
		Square to   = move.getTo();
		Piece piece = getPiece(from);

		if( move.getCapturedPiece() == null)
			move.setCapturedPiece(getPiece(to));

		if( move.getCapturedPiece() != null)
			capturePiece(to);

		if( move.getPromotedPiece() != null )
			piece = move.getPromotedPiece();

		// Remove piece from its original location
		removePiece(from);

		// Move piece to its new location
		addPiece(piece, to);

		if( piece instanceof King )
			setKingSquare(piece.getColor(), to);

		if( addIt )
			moveList.add(move);
	}

	//
	// Methods
	//

	public int getMoveIndex() {
		return moveList.size();
	}

	public boolean isClear(Square from, Square to) {

		int row1 = from.getRow();
		int row2 = to.getRow();
		char col1 = from.getColumn();
		char col2 = to.getColumn();

		if( from.sameColumn(to) ) {
			for( int row = row1 + 1; row < row2; row++) {
				if( getPiece(col1, row) != null )
					return false;
			}
			for( int row = row2 + 1; row < row1; row++) {
				if( getPiece(col1, row) != null )
					return false;
			}
		}
		else if( from.sameRow(to) ) {
			for (char col = (char) (col1 + 1); col < col2; col++) {
				if( getPiece(col, row1) != null )
					return false;
			}
			for (char col = (char) (col2 + 1); col < col1; col++) {
				if( getPiece(col, row1) != null )
					return false;
			}
		}
		else {
			int deltar = (row1 > row2) ? 1 : -1;
			char deltac = (col1 > col2) ? (char) 1 : (char) -1;
			int num = (row1 - row2) * deltar;
			int row, ct;
			char col;

			for (row = row2 + deltar, col = (char) (col2 + deltac), ct = 1;
				ct < num; row += deltar, col += deltac, ct++) {
				if( getPiece(col, row) != null )
					return false;
			}
		}

		return true;
	}

	public boolean isSafe(Square target, int color) {

		Enumeration enum = pieces.elements();

		while( enum.hasMoreElements() ) {

			Square square = (Square) enum.nextElement();
			Piece piece = square.getPiece();

			if( (piece.getColor() != color)
			  && (piece.canAttack(this, square, target)) )
				return false;
		}

		return true;
	}

	//
	// Methods
	//

	public void clear() {

		pieces.clear();

		setChanged();
		notifyObservers(null);
	}

	// TODO: Implement clone() method so that check may be processed correctly.
	/*
	public Object clonee() {
		try {
			return clone();
		}
		catch(CloneNotSupportedException e) {
			return null;
		}
	}
	*/

	public void init() {

		clear();

		addPiece(new Rook(Piece.WHITE)  , new Square('a', 1));
		addPiece(new Knight(Piece.WHITE), new Square('b', 1));
		addPiece(new Bishop(Piece.WHITE), new Square('c', 1));
		addPiece(new Queen(Piece.WHITE) , new Square('d', 1));
		addPiece(new King(Piece.WHITE)  , new Square('e', 1));
		addPiece(new Bishop(Piece.WHITE), new Square('f', 1));
		addPiece(new Knight(Piece.WHITE), new Square('g', 1));
		addPiece(new Rook(Piece.WHITE)  , new Square('h', 1));

		for( char c = 'a'; c <= 'h'; c++ ) {
			addPiece(new Pawn(Piece.WHITE), new Square(c, 2));
			addPiece(new Pawn(Piece.BLACK), new Square(c, 7));
		}

		addPiece(new Rook(Piece.BLACK)  , new Square('a', 8));
		addPiece(new Knight(Piece.BLACK), new Square('b', 8));
		addPiece(new Bishop(Piece.BLACK), new Square('c', 8));
		addPiece(new Queen(Piece.BLACK) , new Square('d', 8));
		addPiece(new King(Piece.BLACK)  , new Square('e', 8));
		addPiece(new Bishop(Piece.BLACK), new Square('f', 8));
		addPiece(new Knight(Piece.BLACK), new Square('g', 8));
		addPiece(new Rook(Piece.BLACK)  , new Square('h', 8));
	}

	public void load(String s) throws IllegalArgumentException {

		int offset = 0;
		int blanks = 0;

		clear();

		for( int row = 8; row >= 1; row-- ) {
			for( char col = 'a'; col <= 'h'; col++ ) {

				if( --blanks != 0 )
					continue;

				char token = s.charAt(offset++);

				if( token == ' ' )
					return;
				else if( token == '/' )
					col = 'h';
				else if( (token >= '1') && (token <= '8') )
					blanks = token - '0';
				else if( token == 'Q' )
					addPiece(new Queen(Piece.WHITE) , new Square(col, row));
				else if( token == 'q' )
					addPiece(new Queen(Piece.BLACK) , new Square(col, row));
				else if( token == 'K' )
					addPiece(new King(Piece.WHITE)  , new Square(col, row));
				else if( token == 'k' )
					addPiece(new King(Piece.BLACK)  , new Square(col, row));
				else if( token == 'B' )
					addPiece(new Bishop(Piece.WHITE), new Square(col, row));
				else if( token == 'b' )
					addPiece(new Bishop(Piece.BLACK), new Square(col, row));
				else if( token == 'N' )
					addPiece(new Knight(Piece.WHITE), new Square(col, row));
				else if( token == 'n' )
					addPiece(new Knight(Piece.BLACK), new Square(col, row));
				else if( token == 'R' )
					addPiece(new Rook(Piece.WHITE)  , new Square(col, row));
				else if( token == 'r' )
					addPiece(new Rook(Piece.BLACK)  , new Square(col, row));
				else if( token == 'P' )
					addPiece(new Pawn(Piece.WHITE)  , new Square(col, row));
				else if( token == 'p' )
					addPiece(new Pawn(Piece.BLACK)  , new Square(col, row));
				else
					throw new IllegalArgumentException("ChessBoard: Invalid board " + s);
			}
		}
	}

	public String save() {

		StringBuffer sb = new StringBuffer();
		int blanks = 0;

		for( int row = 8; row > 0; row-- ) {
			for( char col = 'a'; col <= 'h'; col++ ) {

				Piece piece = getPiece(col, row);

				// Another blank square.
				if( piece == null ) {
					blanks++;
					continue;
				}

				// Output preceding blanks, if any.
				if( blanks != 0 ) {
					sb.append(blanks);
					blanks = 0;
				}

				// Output the piece.
				if( piece.isWhite() )
					sb.append(piece.getType());
				else
					sb.append(Character.toLowerCase(piece.getType()));
			}

			// Output preceding blanks, if any.
			if( blanks != 0 ) {
				sb.append(blanks);
				blanks = 0;
			}

			// Output end of row.
			if( row != 1 )
				sb.append("/");
			else
				sb.append(" ");
		}

		if( isWhitesMove() )
			sb.append("w");
		else
			sb.append("b");

		return sb.toString();
	}

	//
	// Overrides
	//

	public String toString() {
		return save();
	}
}
