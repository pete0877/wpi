/////////////////////////////////////////////////////////////////////////////
//
// File Name:	Pawn.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class Pawn

public class Pawn extends Piece
{
	//
	// Constructors
	//

	public Pawn(int color) {
		super(color, 'P', "Pawn");
		setEnpassantFlag(false);
	}

	//
	// Overrides
	//

	public boolean canAttack(ChessBoard board, Square from, Square to) {

		if( to.equals(from) )
			return false;

		int rowoffset = to.rowOffset(from);
		int coloffset = Math.abs(to.columnOffset(from));

		if( rowoffset != getDirection() )
			return false;

		if( coloffset != 1 )
			return false;

		return true;
	}

	public boolean isLegalMove(ChessBoard board, Move move) {

		setEnpassantFlag (false);

		Square from = move.getFrom();
		Square to = move.getTo();

		int rowoffset = move.rowOffset();
		int coloffset = Math.abs(move.columnOffset());
		int direction = getDirection();

		Piece targetPiece = board.getPiece(to);

		if( coloffset == 0 ) {

			if( targetPiece != null )
				return false;

			if( rowoffset == 1 * direction )
				return true;

			if( rowoffset == 2 * direction ) {

				if( hasMoved() )
					return false;

				if( !board.isClear(from, to) )
					return false;

				return true;
			}
		}
		if( coloffset == 1 ) {

			if (rowoffset != 1 * direction)
				return false;

			if( (targetPiece != null) && canCapture(board, to) )
				return true;

			if( isEnpassant(board, move) ) {
				setEnpassantFlag(true);
				return true;
			}

			return false;
		}

		return false;
	}

	public void move(ChessBoard board, Move move) throws BadMoveException {

		if( isLegalMove(board, move) ) {

			board.movePiece(move);
			setMoveIndex(board.getMoveIndex());

			if( getEnpassantFlag() ) {
/*Man man = sq.getMan();
if (man == null)
{
Debug.println ("Unable to capture man");
return;
}

move.setEnPassantCapturedMan (sq, man);
captureMan (sq);*/
				setEnpassantFlag(false);
				setCapturedSquare(null);
			}

/*			if( isPromoted(move, board) ) {
				// this is a local operation -- still waiting for player to
				// select the piece to which to promote, so must return FALSE
				// to delay processing this request...
				if (move.promotedPiece() == null) return false;
				// Moved to "here"
				board.removePiece (move.to());
				// Networked move.  board.moveMan has handled promoted piece already
				board.addPiece (move.promotedMan(), move.to().getColumn(), move.to().getRow());
				return true;
			}

			return true;
*/
		}
		else
			throw new BadMoveException(move.toString());
	}

	//
	// Implementation
	//

	// TODO: Implement En Passant rule and promotion.
	private boolean isEnpassant(ChessBoard board, Move move) {

		Square to = move.getTo();

		if( to.getRow() != getEnpassantRow() )
			return false;

		// Uncomment the next line.
		//setCapturedSquare(board.getSquare(to.getColumn(), move.getFrom().getRow()));
		if (getCapturedSquare() == null)
			return false;

		Piece piece = capturedSquare.getPiece();
		if( (piece instanceof Pawn) &&	(board.getMoveIndex() == piece.getMoveIndex()) )
			return true;

		setCapturedSquare(null);

		return false;
	}

	private boolean enpassantFlag;
	private Square capturedSquare;

	private boolean getEnpassantFlag() {
		return enpassantFlag;
	}

	private void setEnpassantFlag(boolean flag) {
		this.enpassantFlag = flag;
	}

	private Square getCapturedSquare() {
		return capturedSquare;
	}

	private void setCapturedSquare(Square capturedSquare) {
		this.capturedSquare = capturedSquare;
	}

	private int getDirection() {
		if( isWhite() )
			return 1;
		else
			return -1;
	}

	private int getPromotionRow() {
		if( isWhite() )
			return 8;
		else
			return 1;
	}

	private int getOriginalRow() {
		if( isWhite() )
			return 2;
		else
			return 7;
	}

	private int getEnpassantRow() {
		if( isWhite() )
			return 6;
		else
			return 3;
	}

	// returns false if no promotion occurs
	// promotion.  Returns true for normal case.
	private boolean isPromoted (Move move, ChessBoard board) {
/*		Square  to = move.to();
		if (to.getRow() == getPromotionRow()) {

		  // only do this if a promoted Man has not already been selected
		  if (move.promotedMan() == null)
		board.promoteMan (move, this);

		  // in either event, now we remove pawn from the board, so it won't
		  // mistakenly be viewed as a captured piece...

		  // Moved to "here" above.
		  // board.removeMan (move.to());


		  return true;
		}
*/
		return false;
	}

	public boolean possiblePromotion (int row){ return row == getPromotionRow();}
}
