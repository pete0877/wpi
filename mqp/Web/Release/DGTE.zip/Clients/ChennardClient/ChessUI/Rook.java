/////////////////////////////////////////////////////////////////////////////
//
// File Name:	Rook.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class Rook

public class Rook extends Piece
{
	//
	// Constructors
	//

	public Rook(int color) {
		super(color, 'R', "Rook");
	}

	//
	// Overrides
	//

	public final boolean canAttack(ChessBoard board, Square from, Square to) {

		if( to.equals(from) )
		 	return false;

		if( !from.sameRow(to) && !from.sameColumn(to) )
		 	return false;

		if( !board.isClear(from, to) )
		 	return false;

		return true;
	}
}
