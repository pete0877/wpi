/////////////////////////////////////////////////////////////////////////////
//
// File Name:	Knight.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class Knight

public class Knight extends Piece
{
	//
	// Constructors
	//

	public Knight(int color) {
		super(color, 'N', "Knight");
	}

	//
	// Overrides
	//

	public final boolean canAttack(ChessBoard board, Square from, Square to) {

		if( to.equals(from) )
			return false;

		int rowoffset = Math.abs(from.rowOffset(to));
		int coloffset = Math.abs(from.columnOffset(to));

		if ((rowoffset == 1) && (coloffset == 2))
			return true;

		if ((rowoffset == 2) && (coloffset == 1))
			return true;

		return false;
	}
}
