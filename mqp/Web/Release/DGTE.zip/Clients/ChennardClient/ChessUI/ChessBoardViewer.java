/////////////////////////////////////////////////////////////////////////////
//
// File Name:	ChessBoardViewer.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

import java.awt.Dimension;
import java.awt.Panel;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

/////////////////////////////////////////////////////////////////////////////
// Class ChessBoardViewer

public class ChessBoardViewer extends Panel implements Observer,
													   MouseListener,
													   MouseMotionListener
{
	//
	// Attributes
	//

	protected Vector chessListeners;

	protected ChessBoard    board;
	protected ChessSet      chessSet;
	protected ChessRenderer chessRenderer;

	protected boolean activeFlag;
	protected int     playerColor;
	protected Square  selectedSquare;
	protected Square  highlightedSquare;

	//
	// Constructors
	//

	public ChessBoardViewer() {
		chessListeners    = new Vector();
		board             = null;
		chessSet          = null;
		chessRenderer     = null;
		selectedSquare    = null;
		highlightedSquare = null;
		setActive(false);
		setPlayerColor(Piece.WHITE);
	}

	public ChessBoardViewer(ChessBoard board,
							ChessSet chessSet,
							ChessRenderer chessRenderer) {
		this();
		init(board, chessSet, chessRenderer);
	}

	//
	// Properties
	//

	public boolean isActive() {
		return activeFlag;
	}

	public void setActive(boolean flag) {
		activeFlag = flag;
	}

	public ChessBoard getChessBoard() {
		return board;
	}

	public void setChessBoard(ChessBoard board) {

		if( this.board != null )
			this.board.deleteObserver(this);

		this.board = board;

		if( board != null )
			board.addObserver(this);
		if( chessRenderer != null )
			chessRenderer.setChessBoard(board);
	}

	public ChessSet getChessSet() {
		return chessSet;
	}

	public void setChessSet(ChessSet chessSet) {

		this.chessSet = chessSet;

		if( chessRenderer != null )
			chessRenderer.setChessSet(chessSet);
	}

	public ChessRenderer getChessRenderer() {
		return chessRenderer;
	}

	public void setChessRenderer(ChessRenderer chessRenderer) {

		if( this.chessRenderer != null ) {
			remove(chessRenderer);
			this.chessRenderer.removeMouseListener(this);
			this.chessRenderer.removeMouseMotionListener(this);
			this.chessRenderer.setChessBoard(null);
			this.chessRenderer.setChessSet(null);
		}

		this.chessRenderer = chessRenderer;

		if( chessRenderer != null ) {
			chessRenderer.addMouseListener(this);
			chessRenderer.addMouseMotionListener(this);
			chessRenderer.setChessBoard(board);
			chessRenderer.setChessSet(chessSet);
			add(chessRenderer);
		}
	}

	public int getPlayerColor() {
		return playerColor;
	}

	public void setPlayerColor(int playerColor) {
		if( (playerColor == Piece.BLACK) || (playerColor == Piece.WHITE) )
			this.playerColor = playerColor;
		else
			throw new
				IllegalArgumentException("Piece: Invalid color specified.");
	}

	//
	// Methods
	//

	public void init(ChessBoard board,
					 ChessSet chessSet,
					 ChessRenderer chessRenderer) {
		setChessBoard(board);
		setChessSet(chessSet);
		setChessRenderer(chessRenderer);
	}

	//
	// Observer Methods
	//

	public void update(Observable o, Object arg) {

		if( (board == null) || (chessRenderer == null) )
			return;

		ChessBoard notifier = (ChessBoard) o;
		Square square = (Square) arg;

		if( notifier == board ) {
			if( square != null )
				chessRenderer.updateSquare(square, board.getPiece(square));
			else
				chessRenderer.updateBoard();
		}
	}

	//
	// MouseListener Methods
	//

	public void mousePressed(MouseEvent e) {

		// Still accepting moves.
		if ( !isActive() )
			return;

		// Make sure that event came from one of the squares.
		if( e.getSource() != chessRenderer )
			return;

		Square from = selectedSquare;
		Square to   = chessRenderer.getSquare(e.getPoint());

		// Make sure that event came from one of the squares.
		if( to == null )
			return;

		if( (e.getModifiers() & MouseEvent.BUTTON1_MASK) == MouseEvent.BUTTON1_MASK ) {

			// Case: No selected square.
			if( from == null ) {
				Piece piece = board.getPiece(to);

				if( piece == null )
					return;

				if( piece.getColor() != getPlayerColor() )
					return;

				selectSquare(to);
			}
			// Case: Square already selected.
			else {
				Move move   = new Move(from, to);
				Piece piece = board.getPiece(from);

				// TODO: Changed for debugging.
				/*
				Square kingSq     = board.getKingSquare(playerColor);
				King king         = (King) board.getPiece(kingSq);
				ChessBoard board2 = (ChessBoard) board.clonee();

				try {
					piece.move(board2, move);
					if( king.isChecked(board2) )
						throw new BadMoveException();
					selectSquare(null);
					highlightSquare(null);
					ChessEvent event = new ChessEvent(this, ChessEvent.MOVE, move);
					fireAction(event);
				}
				catch(BadMoveException excp) {}
				*/

				if( piece.isLegalMove(board, move) ) {
					selectSquare(null);
					highlightSquare(null);
					fireAction(new ChessEvent(this, ChessEvent.MOVE, move));
				}
			}
		}
		if( (e.getModifiers() & MouseEvent.BUTTON3_MASK) == MouseEvent.BUTTON3_MASK ) {
			selectSquare(null);
			highlightSquare(null);
		}
	}

	public void mouseClicked (MouseEvent e) {}
	public void mouseEntered (MouseEvent e) {}
	public void mouseExited  (MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}

	//
	// MouseMotionListener Methods
	//

	public void mouseMoved(MouseEvent e) {

		// Still accepting moves.
		if ( !isActive() )
			return;

		// Make sure that event came from one of the squares.
		if( e.getSource() != chessRenderer )
			return;

		Square from = selectedSquare;
		Square to   = chessRenderer.getSquare(e.getPoint());

		// Make sure that event came from one of the squares.
		if( to == null )
			return;

		// Case: No selected square.
		if( from == null ) {
			Piece piece = board.getPiece(to);

			if( piece == null ) {
				highlightSquare(null);
				return;
			}

			if( piece.getColor() != playerColor ) {
				highlightSquare(null);
				return;
			}

			highlightSquare(to);
		}
		// Case: Square already selected.
		else {
			Move move   = new Move(from, to);
			Piece piece = board.getPiece(from);

			// TODO: Changed for debugging.
			/*
			Square kingSq     = board.getKingSquare(playerColor);
			King king         = (King) board.getPiece(kingSq);
			ChessBoard board2 = (ChessBoard) board.clonee();

			try {
				piece.move(board2, move);
				if( king.isChecked(board2) )
					throw new BadMoveException();
				highlightSquare(to);
			}
			catch(BadMoveException excp) {
				highlightSquare(null);
			}
			*/

			if( piece.isLegalMove(board, move) )
				highlightSquare(to);
			else
				highlightSquare(null);

		}
	}

	public void mouseDragged (MouseEvent e) {}

	//
	// ChessListener Methods
	//

	public synchronized void addChessEventListener(
											ChessEventListener listener) {

		chessListeners.addElement(listener);
	}

	public synchronized void removeChessEventListener(
											ChessEventListener listener) {

		chessListeners.removeElement(listener);
	}

	protected void fireAction(ChessEvent event) {
		Vector targets;

		synchronized (this) {
			targets = (Vector) chessListeners.clone();
		}

		for( int i = 0; i < targets.size(); i++ ) {
			ChessEventListener target =
				(ChessEventListener) targets.elementAt(i);
			target.handleChessEvent(event);
		}
	}

	//
	// Implementation
	//

	protected void highlightSquare(Square square) {

		if( highlightedSquare != null ) {
			if( highlightedSquare.equals(square) )
				return;
			else
				chessRenderer.highlightSquare(highlightedSquare, false);
		}

		if( square != null )
			chessRenderer.highlightSquare(square, true);

		highlightedSquare = square;
	}

	protected void selectSquare(Square square) {

		if( selectedSquare != null ) {
			if( selectedSquare.equals(square) )
				return;
			else
				chessRenderer.selectSquare(selectedSquare, false);
		}

		if( square != null )
			chessRenderer.selectSquare(square, true);

		selectedSquare = square;
	}

	// Overrides

	public Dimension getPreferredSize() {
		if( chessRenderer != null )
			return chessRenderer.getPreferredSize();
		else
			return new Dimension(436, 436);
	}
}
