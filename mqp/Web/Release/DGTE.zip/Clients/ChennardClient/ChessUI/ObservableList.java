/////////////////////////////////////////////////////////////////////////////
//
// File Name:	ObservableList.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

import java.util.Enumeration;
import java.util.Observable;
import java.util.Vector;

/////////////////////////////////////////////////////////////////////////////
// Class ObservableList

public class ObservableList extends Observable
{
	//
	// Attributes
	//

	protected Vector list;

	//
	// Constructors
	//

	public ObservableList() {
		list = new Vector();
	}

	//
	// Methods
	//

	public void add(Object element) {
		list.addElement(element);
		setChanged();
		notifyObservers();
	}

	public void clear() {
		list.removeAllElements();
		setChanged();
		notifyObservers();
	}

	public Enumeration elements() {
		return list.elements();
	}

	public Object get(int index) {
      	return list.elementAt(index);
	}

	public boolean isEmpty() {
		return list.isEmpty();
	}

	public void remove(Object element) {
		list.removeElement(element);
		setChanged();
		notifyObservers();
	}

	public void remove(int index) {
		list.removeElementAt(index);
		setChanged();
		notifyObservers();
	}

	public void set(int index, Object element) {
		list.setElementAt(element, index);
		setChanged();
		notifyObservers();
	}

	public int size() {
		return list.size();
	}
}
