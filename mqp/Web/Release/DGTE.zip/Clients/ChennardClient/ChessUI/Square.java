/////////////////////////////////////////////////////////////////////////////
//
// File Name:	Square.java
// Description:	Defines the class behaviors for the application.
// Date:		02/19/2000
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

package ChessUI;

/////////////////////////////////////////////////////////////////////////////
// Class Square

public class Square
{
	//
	// Attributes
	//

	protected char column;
	protected int row;
	protected Piece piece;

	//
	// Constructors
	//

	public Square(Square sq) {
		setColumn(sq.getColumn());
		setRow(sq.getRow());
		setPiece(sq.getPiece());
	}

	public Square(int idx) {
		char col = (char)('a' + idx % 8);
		int row = 8 - idx / 8;
		setColumn(col);
		setRow(row);
		setPiece(null);
	}

	public Square(char col, int row) {
		setColumn(col);
		setRow(row);
		setPiece(null);
	}

	public Square(Piece piece, Square sq) {
		setColumn(sq.getColumn());
		setRow(sq.getRow());
		setPiece(piece);
	}

	public Square(Piece piece, int idx) {
		char col = (char)('a' + idx % 8);
		int row = 8 - idx / 8;
		setColumn(col);
		setRow(row);
		setPiece(piece);
	}

	public Square(Piece piece, char col, int row) {
		setColumn(col);
		setRow(row);
		setPiece(piece);
	}

	//
	// Properties
	//

	public char getColumn() {
		return column;
	}

	public void setColumn(char col) {
		if( col >= 'a' && col <= 'h' )
			this.column = col;
		else
			throw new IllegalArgumentException("Square: Invalid column " + col);
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		if( row >= 1 && row <= 8 )
			this.row = row;
		else
			throw new IllegalArgumentException("Square: Invalid row " + row);
	}

	public Piece getPiece() {
		return piece;
	}

	public void setPiece(Piece piece) {
		this.piece = piece;
	}

	public int getIndex() {
		return (8 - row) * 8 + (column - 'a');
	}

	//
	// Methods
	//

	public int columnOffset (Square square) {
		return ((int) (column - square.column));
	}

	public int rowOffset (Square square) {
		return (row - square.row);
	}

	public boolean sameColumn(Square square) {
		return (column == square.column);
	}

	public boolean sameRow(Square square) {
		return (row == square.row);
	}

	//
	// Overrides
	//

	public boolean equals (Square square) {

		if( square == null )
			return false;

		if( (square.getRow() != row) || (square.getColumn() != column) )
			return false;

		return true;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(column);
		sb.append(row);
		return sb.toString();
	}
}
