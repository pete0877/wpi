import java.util.*;
import java.awt.*;
import java.beans.*;
import ChessUI.*;

public class ChessPlayer extends java.awt.Panel implements ChessEventListener, MessagePipeConnection
{
    private Vector messagePipes;
    private DGTEClientServerProtocol csp;
    private int humanColor;

	private ChessBoard theBoard;
	private ChessSet theChessSet;
	private ChessRenderer theChessRenderer;
	private ChessBoardViewer theBoardViewer;
	
	public ChessPlayer(DGTEClientServerProtocol c, int hc)
	{
        messagePipes = new Vector(1);
        csp = c;
        humanColor = hc;

	    theBoard = new ChessBoard();
	    theChessSet = new ChessSet(this, "Default");
	    theChessRenderer = new ChessRenderer();
	    theBoardViewer = new ChessBoardViewer();   
       
        theBoardViewer.init(theBoard, theChessSet, theChessRenderer);
		theBoard.init();

		//{{INIT_CONTROLS
		Insets ins = getInsets();
		setLayout(null);
		setBackground(java.awt.Color.gray);
		setSize(456,456);
		add(theBoardViewer);
		theBoardViewer.setLocation(10, 10);
		theBoardViewer.setSize(theBoardViewer.getPreferredSize());
		//}}

		//{{REGISTER_LISTENERS
		theBoardViewer.addChessEventListener(this);
		//}}
	}

	//{{DECLARE_CONTROLS
	//}}

    public void addMessagePipeConnection(DGTEMessagePipe mp)
    {
		messagePipes.addElement(mp);
	}

    public void pipeMessage(DGTEMessage m)
    {
		Vector targets;
		synchronized (this)
		{
			targets = (Vector) messagePipes.clone();
		}
		for(Enumeration e=targets.elements(); e.hasMoreElements();)
		{
			DGTEMessagePipe mp = (DGTEMessagePipe)e.nextElement();
			mp.handleMessage(m, this);
		}
    }

    public void handleMessage(DGTEMessage m)
    {
		if(csp.isValid(m))
		{
            if(m.getType().equals("CLIENT_CONNECTIONAVAILABLE"))
		    {
		        DGTEMessage n = new DGTEMessage();
                n.setPart("CLIENT_ENCODING");
                n.setPart("EPD");
   	            pipeMessage(n);
		    }
		    if(m.getType().equals("SERVER_STARTGAME"))
		    {
                theBoard.init();
                theBoardViewer.setActive(true);
		        //if computer goes first, send it state
		        //else wait for user to move
		        if((theBoard.isWhitesMove() && humanColor == Piece.BLACK) || (!theBoard.isWhitesMove() && humanColor == Piece.WHITE))
		        {
                    DGTEMessage n = new DGTEMessage();
                    n.setPart("CLIENT_GAMESTATE");
                    n.setPart(theBoard.save());
                    pipeMessage(n);
   	            }
		    }
		    if(m.getType().equals("SERVER_MOVE"))
		    {
                //if(!userTurn && gameStarted)
                //{
                boolean gameEnded = false;
                Enumeration e = m.getParts();
                if (((String)e.nextElement()).equals(new String("CONTINUE")))
                {
                    gameEnded = true;
                }
                e.nextElement();
                                    
                theBoardViewer.enable();
                                    
                makeMove((String)e.nextElement());
                if (gameEnded) theBoard.init();
                theBoard.setWhitesMove(!theBoard.isWhitesMove());
                //userTurn = !userTurn;
                //}
		    }
		    if(m.getType().equals("CLIENT_MOVE"))
		    {
                //if(userTurn && gameStarted)
                //{
                Enumeration e = m.getParts();
                e.nextElement();
                                    
                //makeMove((String)e.nextElement());
                                    
                //send new board to server
                DGTEMessage n = new DGTEMessage();
                n.setPart("CLIENT_GAMESTATE");
                n.setPart(theBoard.save());
                pipeMessage(n);
                //}
		    }
		}
    }
 
    public void handleChessEvent(ChessEvent event)
    {
        // This method is derived from interface ChessListener
        // to do: code goes here
        if((theBoard.isWhitesMove() && humanColor == Piece.WHITE) || (!theBoard.isWhitesMove() && humanColor == Piece.BLACK))
        {
            if( event.getID() == ChessEvent.MOVE ) 
            {
			    // Get the move.
			    Move move = event.getMove();
    
			    // Update the board.
                makeMove(event.getMove());
                theBoard.setWhitesMove(!theBoard.isWhitesMove());
                
                //send client move message
                DGTEMessage n = new DGTEMessage();
                n.setPart("CLIENT_MOVE");
                n.setPart(move.toString());
   	            pipeMessage(n);
   	            
                //send new board to server
                n = new DGTEMessage();
                n.setPart("CLIENT_GAMESTATE");
                n.setPart(theBoard.save());
                pipeMessage(n);
   	        }
		}
    }

    public void makeMove(Move move)
    {
		// Update the board.
		Piece piece = theBoard.getPiece(move.getFrom());
		try 
		{
			piece.move(theBoard, move);
		} 
    	catch(BadMoveException e) {}
	
		// Alternate sides.
		if( theBoardViewer.getPlayerColor() == Piece.WHITE )
			theBoardViewer.setPlayerColor(Piece.BLACK);
		else
			theBoardViewer.setPlayerColor(Piece.WHITE);
    }

    public void makeMove(String move)
    {
        Square fr,to;
            
        if(move.equals(new String("O-O")))
        {
            if(theBoard.isWhitesMove())
            {
                fr = new Square('e',1);
                to = new Square('f',1);
            }
            else
            {
                fr = new Square('e',8);
                to = new Square('f',8);
            }
            Move mv = new Move(fr,to);
            makeMove(mv);
        }
        else if (move.equals(new String("O-O-O")))
        {
            if(theBoard.isWhitesMove())
            {
                fr = new Square('e',1);
                to = new Square('b',1);
            }
            else
            {
                fr = new Square('e',8);
                to = new Square('f',8);
            }

            Move mv = new Move(fr,to);
            makeMove(mv);
        }
        else
        {
            fr = new Square(move.charAt(0),Integer.decode(move.substring(1, 2)).intValue());
            to = new Square(move.charAt(2),Integer.decode(move.substring(3, 4)).intValue());
            Move mv = new Move(fr,to);
            makeMove(mv);
        }
    }
}