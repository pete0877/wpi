import java.awt.*;

public class DGTEServerErrorDialog extends java.awt.Dialog
{
	public DGTEServerErrorDialog(Frame parent, String message)
	{
    	super(parent);
		//{{INIT_CONTROLS
		setLayout(null);
		setSize(312,168);
		setVisible(false);
		btnOK.setLabel("OK, But I Don\'t Like It...");
		add(btnOK);
		btnOK.setBackground(java.awt.Color.lightGray);
		btnOK.setBounds(12,138,288,24);
		lblError.setText("Server Error Occurred");
		add(lblError);
		lblError.setFont(new Font("Dialog", Font.BOLD, 12));
		lblError.setBounds(12,12,174,18);
		add(textArea1);
		textArea1.setBounds(12,30,288,102);
		setTitle("DGTEServerErrorDialog");
		setResizable(false);
		//}}

		//{{REGISTER_LISTENERS
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		SymMouse aSymMouse = new SymMouse();
		btnOK.addMouseListener(aSymMouse);
		//}}
		
		textArea1.append(message);
	}

	public DGTEServerErrorDialog(Frame parent, boolean modal)
	{
		this(parent);
		setModal(modal);;
	}

	public void addNotify()
	{
		// Record the size of the window prior to calling parents addNotify.
		Dimension d = getSize();

		super.addNotify();

		if (fComponentsAdjusted)
			return;

		// Adjust components according to the insets
		Insets ins = getInsets();
		setSize(ins.left + ins.right + d.width, ins.top + ins.bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(ins.left, ins.top);
			components[i].setLocation(p);
		}
		fComponentsAdjusted = true;
	}

	// Used for addNotify check.
	boolean fComponentsAdjusted = false;

	public DGTEServerErrorDialog(Frame parent, String title, boolean modal)
	{
		this(parent, modal);
		setTitle(title);
	}

	public void setVisible(boolean b)
	{
		if (b)
		{
			Rectangle bounds = getParent().getBounds();
			Rectangle abounds = getBounds();

			setLocation(bounds.x + (bounds.width - abounds.width)/ 2,
				bounds.y + (bounds.height - abounds.height)/2);
		}
		super.setVisible(b);
	}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == DGTEServerErrorDialog.this)
				DGTEServerErrorDialog_WindowClosing(event);
		}
	}

	void DGTEServerErrorDialog_WindowClosing(java.awt.event.WindowEvent event)
	{
		dispose();
	}
	//{{DECLARE_CONTROLS
	java.awt.Button btnOK = new java.awt.Button();
	java.awt.Label lblError = new java.awt.Label();
	java.awt.TextArea textArea1 = new java.awt.TextArea();
	//}}


	class SymMouse extends java.awt.event.MouseAdapter
	{
		public void mouseClicked(java.awt.event.MouseEvent event)
		{
			Object object = event.getSource();
			if (object == btnOK)
				btnOK_MouseClicked(event);
		}
	}

	void btnOK_MouseClicked(java.awt.event.MouseEvent event)
	{
		// to do: code goes here.
			 
		btnOK_MouseClicked_Interaction1(event);
	}

	void btnOK_MouseClicked_Interaction1(java.awt.event.MouseEvent event)
	{
		try {
			// DGTEServerErrorDialog Hide the DGTEServerErrorDialog
			this.setVisible(false);
		} catch (Exception e) {
		}
	}
}