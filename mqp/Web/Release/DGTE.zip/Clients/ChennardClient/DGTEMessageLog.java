import java.util.*;
import java.awt.*;
import java.beans.*;

public class DGTEMessageLog extends java.awt.Frame implements MessagePipeConnection
{
	public DGTEMessageLog()
	{
		//{{INIT_CONTROLS
		setLayout(null);
		setSize(648,498);
		setVisible(false);
		add(txtLog);
		txtLog.setBounds(12,12,624,474);
		setTitle("A Simple Frame");
		//}}

		//{{REGISTER_LISTENERS
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		//}}

		//{{INIT_MENUS
		//}}

	}

	public DGTEMessageLog(String title)
	{
		this();
		setTitle(title);
	}
	public void setVisible(boolean b)
	{
		if(b)
		{
			setLocation(50, 50);
		}
	super.setVisible(b);
	}

	static public void main (String args[])
	{
		(new DGTEMessageLog()).setVisible(true);
	}

	public void addNotify()
	{
		// Record the size of the window prior to calling parents addNotify.
		Dimension d = getSize();

		super.addNotify();

		if (fComponentsAdjusted)
			return;

		// Adjust components according to the insets
		Insets ins = getInsets();
		setSize(ins.left + ins.right + d.width, ins.top + ins.bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
			{
			Point p = components[i].getLocation();
			p.translate(ins.left, ins.top);
			components[i].setLocation(p);
		}
		fComponentsAdjusted = true;
	}

	// Used for addNotify check.
	boolean fComponentsAdjusted = false;

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
		Object object = event.getSource();
		if (object == DGTEMessageLog.this)
			DGTEMessageLog_WindowClosing(event);
		}
	}

	void DGTEMessageLog_WindowClosing(java.awt.event.WindowEvent event)
	{
		dispose();		 // dispose of the Frame.
	}
	//{{DECLARE_CONTROLS
	java.awt.TextArea txtLog = new java.awt.TextArea();
	//}}

	//{{DECLARE_MENUS
	//}}

    public void pipeMessage(DGTEMessage m)
    {
        // This method is derived from interface MessagePipeConnection
        // to do: code goes here
    }

    public void handleMessage(DGTEMessage m)
    {
        // This method is derived from interface MessagePipeConnection
        // to do: code goes here
        String msg = "";
	    for(Enumeration e=m.getParts(); e.hasMoreElements();)
	    {
            msg += (String)e.nextElement();
            msg += "  ";
	    }
	    msg += "\n";
	    txtLog.appendText(msg);
    }

    public void addMessagePipeConnection(DGTEMessagePipe mp)
    {
        // This method is derived from interface MessagePipeConnection
        // to do: code goes here
    }

}