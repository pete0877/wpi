import java.util.Vector;
import java.util.Enumeration;
import java.awt.*;

public class DGTEGamePlayer extends java.awt.TextArea implements MessagePipeConnection   
{
    int MOVEDECISION_CONTINUE = 0;
    int MOVEDECISION_WIN = 1;
    int MOVEDECISION_LOOSE = 2;
    int MOVEDECISION_DRAW = 3;
    
    private Vector messagePipes;
    private DGTEClientServerProtocol csp;
    
    private String epdState;
    private char[][] gamePieces;
    private String computerColor;
    private boolean WKINGCASTLE;
    private boolean WQUEENCASTLE;
    private boolean BKINGCASTLE;
    private boolean BQUEENCASTLE;
    
    private boolean userTurn;
    private boolean gameStarted;
        
    DGTEGamePlayer(DGTEClientServerProtocol c)
    {
        epdState = new String("");
        gamePieces = new char[8][8];
        csp = c;
        messagePipes = new Vector(1);
        init();
        
		//{{INIT_CONTROLS
		setEditable(false);
		setBackground(java.awt.Color.white);
		setForeground(java.awt.Color.black);
		setFont(new Font("MonoSpaced", Font.PLAIN, 10));
		setSize(0,0);
		//}}

	    //displayState();
	}

    public void init()
    {
        /*
        gamePieces[7][0] = 'r';
        gamePieces[7][1] = 'n';
        gamePieces[7][2] = 'b';
        gamePieces[7][3] = 'q';
        gamePieces[7][4] = 'k';
        gamePieces[7][5] = 'b';
        gamePieces[7][6] = 'n';
        gamePieces[7][7] = 'r';
        for(int i=0; i<8; i++) gamePieces[6][i] = 'p';
        for(int i=0; i<8; i++) { gamePieces[5][i] = ' '; gamePieces[4][i] = ' '; gamePieces[3][i] = ' '; gamePieces[2][i] = ' ';}
        for(int i=0; i<8; i++) gamePieces[1][i] = 'P';
        gamePieces[0][0] = 'R';
        gamePieces[0][1] = 'N';
        gamePieces[0][2] = 'B';
        gamePieces[0][3] = 'Q';
        gamePieces[0][4] = 'K';
        gamePieces[0][5] = 'B';
        gamePieces[0][6] = 'N';
        gamePieces[0][7] = 'R';
        */
        
        for(int i=0; i<8; i++) {for(int j=0; j<8; j++) gamePieces[i][j] = ' ';}
        gamePieces[7][7] = 'k';
        gamePieces[5][5] = 'R';
        gamePieces[4][5] = 'Q';
        gamePieces[6][5] = 'R';
        gamePieces[0][0] = 'K';
            
        //epdState = "r1bqkbnr/pppppppp/2n5/8/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - bm 1; id 1;";
        computerColor = new String("w");
        userTurn = true;
        WKINGCASTLE = false;
        WQUEENCASTLE = false;
        BKINGCASTLE = false;
        BQUEENCASTLE = false;
        gameStarted = false;
        
        ///displayState();
		///appendText("\nEPDState: ");
		//appendText(getState());
		//appendText("\nEPDState");
		//epdToBoard(getState());
		displayState();
    }
    
    public String boardToEPD()
    {
        int k;
        String tempString = new String("");
        for (int r = 7; r >= 0; r--)
        {
            k = 0;
            for (int c = 0; c < 8; c++)
            {
	            if (gamePieces[r][c] == ' ')
	                k++;
	            else
	            {
	                if (k !=0) 
	                    tempString = tempString.concat(String.valueOf(k));
	                k = 0;
	                //c1 = notation[cboard[sq]];
	                //if (BitPosArray[sq] & board.friends[black])
	                //    c1 = tolower (c1);
	                //fprintf (fp, "%c", c1);
	                tempString = tempString.concat(new String(gamePieces[r],c,1));
	            }
            }
            if (k!=0)
	            tempString = tempString.concat(String.valueOf(k));
	            //fprintf (fp, "%1d", k);
            if (r > 0)
                tempString = tempString.concat("/");
                //fprintf (fp, "/");
        }

        /* Print other stuff */
        tempString = tempString.concat(" " + computerColor + " ");
        //fprintf (fp, (board.side == white ? " w " : " b "));
    
        if (WKINGCASTLE)
            tempString = tempString.concat("K");
        if (WQUEENCASTLE)
            tempString = tempString.concat("Q");
        if (BKINGCASTLE)
            tempString = tempString.concat("k");
        if (BQUEENCASTLE)
            tempString = tempString.concat("q");
        if (!WKINGCASTLE || !BKINGCASTLE || !WQUEENCASTLE || !BQUEENCASTLE)
            tempString = tempString.concat("-");

        //fprintf (fp, " %s", (board.ep > -1 ? algbr[board.ep] : "-"));
        tempString = tempString.concat(" -");
        //fprintf (fp, " bm 1; id 1;");
        tempString = tempString.concat(" bm 1; id 1;");
        //fprintf (fp, "\n");
        tempString = tempString.concat("\n");
        return tempString;   
    }
    
    public void epdToBoard(String epd)
    {
        int r, c;
        r = 7;
        c = 0;
        int tempPos = 0;
        while (epd.charAt(tempPos) != ' ')
        {
            switch (epd.charAt(tempPos))
            {
                case 'P' : gamePieces[r][c] = 'P'; break;	
                case 'N' : gamePieces[r][c] = 'N'; break;	
                case 'B' : gamePieces[r][c] = 'B'; break;	
                case 'R' : gamePieces[r][c] = 'R'; break;	
                case 'Q' : gamePieces[r][c] = 'Q'; break;	
                case 'K' : gamePieces[r][c] = 'K'; break;	
                case 'p' : gamePieces[r][c] = 'p'; break;	
                case 'n' : gamePieces[r][c] = 'n'; break;	
                case 'b' : gamePieces[r][c] = 'b'; break;	
                case 'r' : gamePieces[r][c] = 'r'; break;	
                case 'q' : gamePieces[r][c] = 'q'; break;	
                case 'k' : gamePieces[r][c] = 'k'; break;	
                case '/' :  r--;
	 	            c = -1;
        		    break;  
                default  :  break;
            }
            if((int)epd.charAt(tempPos)>=48 && (int)epd.charAt(tempPos)<=57)
                c += ((int)epd.charAt(tempPos) - 48);
            else
                c++;
            tempPos++;
        }

           /*  Get side to move  */
        tempPos++;
        if (epd.charAt(tempPos) == 'w')
            computerColor = "w";
        else computerColor = "b";
        tempPos++;
        tempPos++;
        
        /*  Castling status  */
        while(epd.charAt(tempPos) != ' ')
        {
            switch(epd.charAt(tempPos))
            {
                case 'K': WKINGCASTLE = true; break;
                case 'Q': WQUEENCASTLE = true; break;
                case 'k': BKINGCASTLE = true; break;
                case 'q': BQUEENCASTLE = true; break;
            }
            tempPos++;
        }
        tempPos+=3;
        /*  En passant square */
        //sscanf (p, " %s %[^\n]", s, p);
        //if (s[0] != '-')
        //    board.ep = (s[0] - 'a') + (s[1] - '1')*8;
        //else
        //    board.ep = -1;
        
        /*  Read in best move; "bm" operator */
        //if (!strncmp (p, "bm", 2))
        //    sscanf (p, "%*s %[^;]; %[^\n]", solution, p); 
        
        /*  Read in the description; "id" operator */
        //if (!strncmp (p, "id", 2))
        //    sscanf (p, "%*s %[^;]; %[^\n]", id, p); 
    }
    
    
    public void makeMove(String move)
    {
        if(move.length() >= 4)
        {
            int frcol, tocol;
            switch (move.charAt(0))
            {
                case 'a': frcol = 0; break;
                case 'b': frcol = 1; break;
                case 'c': frcol = 2; break;
                case 'd': frcol = 3; break;
                case 'e': frcol = 4; break;
                case 'f': frcol = 5; break;
                case 'g': frcol = 6; break;
                case 'h': frcol = 7; break;
                default: frcol = 0; break;
            }
            switch (move.charAt(2))
            {
                case 'a': tocol = 0; break;
                case 'b': tocol = 1; break; 
                case 'c': tocol = 2; break;
                case 'd': tocol = 3; break;
                case 'e': tocol = 4; break;
                case 'f': tocol = 5; break;
                case 'g': tocol = 6; break;
                case 'h': tocol = 7; break;
                default: tocol = 0; break;
            }
                
            int frrow = Integer.decode(move.substring(1, 2)).intValue() - 1;
            int torow = Integer.decode(move.substring(3, 4)).intValue() - 1;
            gamePieces[torow][tocol] = gamePieces[frrow][frcol];
            gamePieces[frrow][frcol] = ' ';
            if (move.length() == 5)
            {
                if (move.charAt(4) == 'Q' || move.charAt(4) == 'q') gamePieces[torow][tocol] = move.charAt(4);
            }
        }
    }
        
    public void displayState()
    {
        //setText("");
        //appendText("\n");
        //appendText(epdState);
        
        setText("");
        appendText("\n  |---------------------------------------|\n");
        for(int i=7; i>=0; i--)
        {
            switch (i)
            {
                case 0: appendText("1"); break;
                case 1: appendText("2"); break; 
                case 2: appendText("3"); break;
                case 3: appendText("4"); break;
                case 4: appendText("5"); break;
                case 5: appendText("6"); break;
                case 6: appendText("7"); break;
                case 7: appendText("8"); break;
            }
            appendText(" |");
            for(int j=0; j<8; j++)
            {
                appendText(" ");
                if (gamePieces[i][j] == 'p' || gamePieces[i][j] == 'q' || gamePieces[i][j] == 'k' || gamePieces[i][j] == 'n' || gamePieces[i][j] == 'b' || gamePieces[i][j] == 'r')
                    appendText(new String("*"));
                else appendText(new String(" "));
                appendText(new String(gamePieces[i],j,1));
                
                /*
                char piece = gamePieces.charAt(i*8 + j);
                if(piece == '6') appendText("K");
                else if(piece == '5') appendText("Q");
                else if(piece == '4') appendText("R");
                else if(piece == '3') appendText("B");
                else if(piece == '2') appendText("N");
                else if(piece == '1') appendText("P");
                else if(piece == '0')
                {
                    if ((i % 2) == (j % 2)) appendText(" ");
                    else appendText(":");
                }
                
                char color = gameColors.charAt(i*8 + j);
                if(color == '0')
                {
                    if ((i % 2) == (j % 2)) appendText(" ");
                    else appendText(":");
                }
                else if(color == '1') appendText("w");
                else if(color == '2') appendText("b");
                */
                appendText(" |");
            }
            appendText("\n  |---------------------------------------|\n");
        }
        appendText("     a    b    c    d    e    f    g    h  \n");
        
    }

    public String getState()
    {
        return boardToEPD();
    }

    public void setState(String state)
    {
        epdState = state;
        //if(state.length() == 129)
        //{
        //    gamePieces = state.substring(1, 65);
        //    gameColors = state.substring(65, 129);
        //}
    }
        
    public void pipeMessage(DGTEMessage m)
    {
		Vector targets;
		synchronized (this)
		{
			targets = (Vector) messagePipes.clone();
		}
		for(Enumeration e=targets.elements(); e.hasMoreElements();)
		{
			DGTEMessagePipe mp = (DGTEMessagePipe)e.nextElement();
			mp.handleMessage(m, this);
		}
    }

    public void handleMessage(DGTEMessage m)
    {
		if(csp.isValid(m))
		{
            if(m.getType().equals("CLIENT_CONNECTIONAVAILABLE"))
		    {
		        DGTEMessage n = new DGTEMessage();
                n.setPart("CLIENT_ENCODING");
                n.setPart("EPD");
   	            pipeMessage(n);
		    }
		    if(m.getType().equals("SERVER_STARTGAME"))
		    {
                init();
                gameStarted = true;
		        displayState();
		        //if computer goes first, send it state
		        //else wait for user to move
		        if(!userTurn)
		        {
		            DGTEMessage n = new DGTEMessage();
                    n.setPart("CLIENT_GAMESTATE");
                    n.setPart(getState());
   	                pipeMessage(n);
   	            }
		    }
		    if(m.getType().equals("SERVER_MOVE"))
		    {
                if(!userTurn && gameStarted)
                {
                    Enumeration e = m.getParts();
                    e.nextElement();
                    e.nextElement();
                    makeMove((String)e.nextElement());
                    displayState();
                    userTurn = !userTurn;
                }
		    }
		    if(m.getType().equals("CLIENT_MOVE"))
		    {
                if(userTurn && gameStarted)
                {
                    Enumeration e = m.getParts();
                    e.nextElement();
                    
                    makeMove((String)e.nextElement());
                    displayState();
                    userTurn = !userTurn;
                    
                    //send new board to server
                    DGTEMessage n = new DGTEMessage();
                    n.setPart("CLIENT_GAMESTATE");
                    n.setPart(getState());
   	                pipeMessage(n);
                }
		    }
		}
	}

    public void addMessagePipeConnection(DGTEMessagePipe mp)
    {
		messagePipes.addElement(mp);
	}
	//{{DECLARE_CONTROLS
	//}}
}