import java.awt.*;
import java.util.Enumeration;

public class DGTEStatusArea extends java.awt.TextArea implements MessagePipeConnection
{
	public void addMessagePipeConnection(DGTEMessagePipe mp){}
	public void handleMessage(DGTEMessage m)
	{
	    String msg = "";
	    for(Enumeration e=m.getParts(); e.hasMoreElements();)
	    {
            msg += (String)e.nextElement();
            msg += "  ";
	    }
	    msg += "\n";
	    appendText(msg);
	}
	public void pipeMessage(DGTEMessage m){}
}
