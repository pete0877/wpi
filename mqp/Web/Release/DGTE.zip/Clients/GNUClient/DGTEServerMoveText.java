import java.awt.*;
import java.util.*;

public class DGTEServerMoveText extends java.awt.TextField implements MessagePipeConnection
{
	public void addMessagePipeConnection(DGTEMessagePipe mp){}
	public void handleMessage(DGTEMessage m)
	{
	    String msg;
        if(m.getType().equals("SERVER_MOVE"))
        {
	        for(Enumeration e=m.getParts(); e.hasMoreElements();)
    	    {   
                e.nextElement();
                e.nextElement();
                msg = (String)e.nextElement();
                this.setText(msg);
	        }
	    }
	}
	public void pipeMessage(DGTEMessage m){}
}