#if !defined(AFX_STDAFX_H__7D853258_E4C4_11D3_91CF_004095100085__INCLUDED_)
#define AFX_STDAFX_H__7D853258_E4C4_11D3_91CF_004095100085__INCLUDED_

#if _MSC_VER > 1000
	#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components

#include <Vector>
using namespace std;
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.


// !defined(AFX_STDAFX_H__7D853258_E4C4_11D3_91CF_004095100085__INCLUDED_)

#endif

 