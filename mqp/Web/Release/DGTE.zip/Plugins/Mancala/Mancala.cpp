#include "Mancala.h"
#include "SimpleDateTime.h"
#include "StringTool.h"

typedef struct tagNode {
	vector<tagNode*>	children;
	vector<int>			board;
	bool				max_level;
	int					ply;
	long				nodes_below;
	int					status;
} Node;

/////////////////////////////////////////////////////////////////////////////

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

/////////////////////////////////////////////////////////////////////////////

GameTypeData gameTypeData =
{
	"Mancala",
	"1.0",
	"Acient game",
	"Worcester Polytechnic Institute",
	"Copyright � 1999-2000 Worcester Polytechnic Institute",
	"", 
	"MANCALA",
	MAXGSTATE, 
	MAXMOVE, 
	100,
	MAXBRANCH
};


CString encodeBoard(vector<int> board)
{
	CString result;
	char tmp[10];
	for (int a=0; a<=14; a++) {
		sprintf(tmp,"%d",board[a]);
		result = result + tmp;
		if (a!=14) result = result + ",";
	}
	return result;
}


vector<int> generateBoard(vector<int> board, int position, int* final_status, bool* again)
{
	// MOVEDECISION_CONTINUE 
	// MOVEDECISION_WIN      
	// MOVEDECISION_LOOSE    
	// MOVEDECISION_DRAW     

	vector<int> new_board = board;
	int rocks = new_board [position];
	new_board [position] = 0;
	bool up_level;
	bool up_player;
	int position_change;
	if (position <= 8)  {
		up_level = false;
		position_change = 1;
	} else {
		up_level = true;
		position_change = -1;
	}
	up_player = up_level;
	bool just_gained_rock;
	// put all the rocks down:
	for (int rock=1; rock<=rocks; rock++) {
		just_gained_rock = false;
		// go to the next hole:
		position += position_change;		
		if (position == 9) {
			// check if we switched position
			if (up_level==false) {
				// yap, we were down, and now we are up:
				position = 14;
				position_change = -1;
				up_level=true;
				// mark the fact that we just put one rock in the right mankala:
				rock++;
				new_board [1]++;
				just_gained_rock = true;
			}
		} else if (position == 8) {
			// check if we switched position
			if (up_level==true) {
				// yap, we were down, and now we are up:
				position = 3;
				position_change = 1;
				up_level=false;
				// mark the fact that we just put one rock in the left mankala:
				rock++;
				new_board [2]++;
				just_gained_rock = true;
			}
		} 		
		// put the rock down:
		if (!just_gained_rock) new_board [position]++;
		else if (rock<=rocks) {
			new_board [position]++;
			just_gained_rock = false;
		}
	}
	// ADDON: START
	// see if we get to take another move:
	if (just_gained_rock) *again = true; else *again = false;
	// ADDON: END

	// see if we ended with one rock on our side:
	if (new_board[position]==1 && !just_gained_rock) {
		// yes, place rocks from opposite hole in the right mankala:		
		int opposite;
		if (position <= 8)	opposite = position + 6; 
					else	opposite = position - 6; 
		// see who gets the rocks:
		if (up_player) {
			// left mankala
			new_board [2] += new_board [opposite];
		} else {
			// right mankala
			new_board [1] += new_board [opposite];
		}
		new_board [opposite] = 0;
	}
	// check if it is the end of the game:
	*final_status = MOVEDECISION_CONTINUE; // continue
	int count_up = 0, count_down = 0; 
	int a;
	for (a = 3; a <= 8; a++)  count_down += new_board [a];
	for (a = 9; a <= 14; a++) count_up   += new_board [a];
	if ((count_down == 0) || (count_up == 0)) {
		// game over state		
		new_board [1] += count_down;
		new_board [2] += count_up;
		for (a = 3; a <= 8; a++)  new_board [a] = 0;
		for (a = 9; a <= 14; a++) new_board [a] = 0;
		// check who won:
		if (new_board [1] > new_board [2] ) {
			// bottom won
			if (new_board[0]==1)
				*final_status = MOVEDECISION_WIN;
			else
				*final_status = MOVEDECISION_LOOSE;
		} else if (new_board [1] < new_board [2] ) {
			// top won
			if (new_board[0]==1)
				*final_status = MOVEDECISION_LOOSE;
			else
				*final_status = MOVEDECISION_WIN;
		} else {
			// draw
			*final_status = MOVEDECISION_DRAW;
		}
	}
	return new_board;
}




void possibleEnds(vector<int> board, int mv_pos, vector<void*>* set)
{
	bool again;
	int final_status;
	vector<int> new_board = generateBoard(board, mv_pos, &final_status, &again);	
	if (again) {
		int loop_low = 3;
		int loop_high = 8;
		if (mv_pos >=9) {
			loop_low = 9;
			loop_high = 14;
		}
		for (int bpos=loop_low; bpos<=loop_high; bpos++) 
			if (new_board[bpos]>0) 
				possibleEnds(new_board, bpos, set);
	} else {
		// this move does not lead to any other moves
		vector<int>* pBoard = new vector<int>;
		*pBoard = new_board;
		set->push_back((void*) pBoard);
	}
}

int findStatus(vector<int> new_board)
{
	int final_status = MOVEDECISION_CONTINUE; // continue
	int count_up = 0, count_down = 0; 
	int a;
	for (a = 3; a <= 8; a++)  count_down += new_board [a];
	for (a = 9; a <= 14; a++) count_up   += new_board [a];
	if ((count_down == 0) || (count_up == 0)) {
		// game over state		
		new_board [1] += count_down;
		new_board [2] += count_up;
		for (a = 3; a <= 8; a++)  new_board [a] = 0;
		for (a = 9; a <= 14; a++) new_board [a] = 0;
		// check who won:
		if (new_board [1] > new_board [2] ) {
			// bottom won
			if (new_board[0]==1)
				final_status = MOVEDECISION_WIN;
			else
				final_status = MOVEDECISION_LOOSE;
		} else if (new_board [1] < new_board [2] ) {
			// top won
			if (new_board[0]==1)
				final_status = MOVEDECISION_LOOSE;
			else
				final_status = MOVEDECISION_WIN;
		} else {
			// draw
			final_status = MOVEDECISION_DRAW;
		}
	}
	return final_status;
}


int evaluateTree(Node *node, SimpleDateTime *deadline)
{	
	node->nodes_below = 1;	
	int MAX_IDX, MIN_IDX;
	if (node->board[0] == 0) {
		MAX_IDX = 2;
		MIN_IDX = 1;
	} else {
		MAX_IDX = 1;
		MIN_IDX = 2;
	}
	if ((node->ply==1) || (node->status!=MOVEDECISION_CONTINUE)) return (node->board[MAX_IDX] - node->board[MIN_IDX]);		
	// check if it is a board in end-game state:
	if (node->status!=MOVEDECISION_CONTINUE) return (node->board[MAX_IDX] - node->board[MIN_IDX]); // end of game
	// check if we have time to evaluate children:
	SimpleDateTime now;
	now.setToNow();
	if ((deadline->operator-(now)) < 0) return (node->board[MAX_IDX] - node->board[MIN_IDX]); // no time left

	int loop_low, loop_high;
	if (node->max_level) {
		if (node->board[0]==1) {
			// server is down and this is maximizing level
			loop_low = 3;
			loop_high = 8;
		} else {
			// server is up and this is maximizing level
			loop_low = 9;
			loop_high = 14;
		}		
	} else {
		if (node->board[0]==1) {
			// server is down and this is maximizing level
			loop_low = 9;
			loop_high = 14;
		} else {
			// server is up and this is maximizing level			
			loop_low = 3;
			loop_high = 8;
		}	
	}
	// create direct child nodes:
	for (int bpos=loop_low; bpos<=loop_high; bpos++) {
			if (node->board[bpos]>0) {				
				// generate the board assiming move [bpos]
				int final_status=0;
				
				vector<void*>* possibilities = new vector<void*>;
				possibleEnds(node->board, bpos, possibilities);
				vector<void*>::iterator ib;
				vector<int>* da_board;
				for(ib = possibilities->begin(); ib !=possibilities->end(); ib++) {
					da_board = (vector<int>*) *ib;					
					Node* child = new Node;
					child->board = *da_board;
					child->max_level = !node->max_level;
					child->nodes_below = 1;
					child->status = findStatus(child->board);
					child->ply = node->ply - 1;	
					node->children.push_back(child);	
					delete da_board;
				}
				delete possibilities;
			}
	}
	// evaluate child nodes:
	int best_quality = (node->board[MAX_IDX] - node->board[MIN_IDX]);
	int child_quality;
	vector<Node*>::iterator ppKid;
	Node* pKid;
	for (ppKid=node->children.begin(); ppKid!=node->children.end(); ppKid++) {
		pKid = *ppKid; 
		child_quality = evaluateTree(pKid, deadline);
		if (node->max_level) {
			// trying to maximize the score
			if (child_quality > best_quality) best_quality = child_quality;
		} else {
			// trying to minizime the score
			if (child_quality < best_quality) best_quality = child_quality;
		}		
		node->nodes_below += pKid->nodes_below;	
		delete pKid;
	}
	return best_quality;
}




void getQuickMove(GameState gs, LevelType level, int maxSize, int *actualSize, Move *moves, int *gameOver)
{
	// parse the board
	char szBoard[500];
	strcpy(szBoard, (char*) gs.gamestate);
	CString s;
	char *sz;
	char sVal[20];

	vector<int> board;
	long val;
	bool first = true;
	do {
		if (first) {
			sz = strtok(szBoard, ",");
			first = false;
		} else sz = strtok(NULL, ",");
		if (sz != NULL) {	
			strcpy(sVal, sz);
			StringTool str;
			str.set(sVal);			
			val = str.toLong();
			board.push_back(val);
		}
	} while (sz != NULL);

	// find quick move:
	bool open = true;
	bool game_over = false;
	int count;
	*actualSize = 0;		
	*gameOver = 0;

	int a;

	// check if the board is just opened:
	for (a=3; a<=14; a++) if (board[a] != 3) open = false;

	// check if the game is over:
	count = 0;
	for (a=3; a<=8; a++)  count += board[a];
	if (count == 0) game_over = true;
	count = 0;
	for (a=9; a<=14; a++)  count += board[a];
	if (count == 0) game_over = true;
	if (game_over) *gameOver = 1;
	if (open) {
		// yes, we can make a quick move	
		char m[10];
		int q;
		if (board[0] == 0) {
			strcpy(m, "9"); // server is at the top
			q = -1;
		} else {
			strcpy(m, "8"); // server is at the bottom
			q = 1;
		}
		moves->status = 0; // continue
		strcpy((char *) moves->move, m);
		moves->actualSize = 2;
		moves->quality = q;
	} 
}



void split(GameState gs, LevelType level, int maxSize, int *actualSize, Move *moves)
{
	// parse the board
	char szBoard[500];
	strcpy(szBoard, (char*) gs.gamestate);
	CString s;
	char *sz;
	char sVal[20];

	vector<int> board;
	long val;
	bool first = true;
	do {
		if (first) {
			sz = strtok(szBoard, ",");
			first = false;
		} else sz = strtok(NULL, ",");
		if (sz != NULL) {	
			strcpy(sVal, sz);
			StringTool str;
			str.set(sVal);			
			val = str.toLong();
			board.push_back(val);
		}
	} while (sz != NULL);

	int loop_low, loop_high;
	int MAX_IDX, MIN_IDX;
	if (level == MAXIMAXING) {
		if (board[0]==1) {
			// server is down and this is maximizing level
			loop_low = 3;
			loop_high = 8;
			MAX_IDX = 1;
			MIN_IDX = 2;
		} else {
			// server is up and this is maximizing level
			loop_low = 9;
			loop_high = 14;
			MAX_IDX = 2;
			MIN_IDX = 1;
		}		
	} else {
		if (board[0]==1) {
			// server is down and this is minimizing level
			loop_low = 9;
			loop_high = 14;
			MAX_IDX = 1;
			MIN_IDX = 2;
		} else {
			// server is up and this is minimizing level			
			loop_low = 3;
			loop_high = 8;
			MAX_IDX = 2;
			MIN_IDX = 1;
		}	
	}
	int found_boards = 0;
	for (int bpos=loop_low; bpos<=loop_high; bpos++) 
			if (board[bpos]>0) {				
				char m[10];
				sprintf(m, "%d", bpos);
				strcpy((char*) moves[found_boards].move, m);

				// generate the board assiming move [bpos]
				int final_status=0;
				bool again;				 
				vector<int> new_board = generateBoard(board, bpos, &final_status, &again);
				if (final_status!=MOVEDECISION_CONTINUE) again = false;
				if (again) {
					// we are not done. this is a board after we just droppped a
					// rock into one of the makalas. We have to generate boards below us
					// as well and 

					GameState other_gs;
					other_gs.gamestate = new unsigned char[MAXGSTATE];
					strcpy((char*) other_gs.gamestate, encodeBoard(new_board).GetBuffer(0));
					int other_size=MAXBRANCH;
					Move* other_moves = new Move[MAXBRANCH];
					for (int aa=0; aa<MAXBRANCH; aa++) {
						other_moves[aa].move = new unsigned char [MAXMOVE];
						other_moves[aa].maxSize = MAXMOVE;
						other_moves[aa].actualSize = MAXMOVE;
						other_moves[aa].gamestate.gamestate = new unsigned char [MAXGSTATE];
						other_moves[aa].gamestate.maxSize = MAXGSTATE;
						other_moves[aa].gamestate.actualSize = MAXGSTATE;
					}					
					split(other_gs, level, MAXBRANCH, &other_size, other_moves);

					for (aa=0; aa<other_size; aa++) {
						strcpy(
							(char*) moves[found_boards].gamestate.gamestate, 
							(char*) other_moves[aa].gamestate.gamestate);
						moves[found_boards].gamestate.actualSize = other_moves[aa].gamestate.actualSize;
						sprintf((char*) moves[found_boards].move, "%s,%s",m,(char*) other_moves[aa].move);
						moves[found_boards].actualSize = strlen((char*) moves[found_boards].move) + 1; 
						moves[found_boards].quality = other_moves[aa].quality;
						moves[found_boards].status = other_moves[found_boards].status;
						if (found_boards < (maxSize - 1)) found_boards++;
					}

					for (aa=0; aa<MAXBRANCH; aa++) {
						delete other_moves[aa].move;
						delete other_moves[aa].gamestate.gamestate;
					}
					delete other_moves;
					delete other_gs.gamestate;

				} else {
					// fill in game state data
					CString encoding = encodeBoard(new_board);
					strcpy((char*) moves[found_boards].gamestate.gamestate, encoding.GetBuffer(0));
					moves[found_boards].gamestate.actualSize = strlen(encoding.GetBuffer(0)) + 1;
					// fill in move data					
					moves[found_boards].actualSize = strlen((char*) moves[found_boards].move) + 1; 
					// find the raugh-estimate quiality
					moves[found_boards].quality = new_board[MAX_IDX] - new_board[MIN_IDX];
					// record the status:
					moves[found_boards].status = final_status;
					found_boards++;
				}
			}
	*actualSize = found_boards;
	int st;
	for (int count=0; count<found_boards; count++) {		
		st = moves[count].status;
		if (st!=MOVEDECISION_CONTINUE && st!=MOVEDECISION_WIN && st!=MOVEDECISION_LOOSE && st!=MOVEDECISION_DRAW) moves[count].status = MOVEDECISION_CONTINUE;
	}
}


void evaluate(GameState gs, LevelType level, int ply, int timelimit, int *quality, HelperPerformanceData *data)
{
	SimpleDateTime t0, t1, deadline;
	t0.setToNow();
	deadline.setToNow();
	deadline.add(timelimit);

	// parse the board
	char szBoard[500];
	strcpy(szBoard, (char*) gs.gamestate);
	CString s;
	char *sz;
	char sVal[20];

	vector<int> board;
	long val;
	bool first = true;
	do {
		if (first) {
			sz = strtok(szBoard, ",");
			first = false;
		} else sz = strtok(NULL, ",");
		if (sz != NULL) {	
			strcpy(sVal, sz);
			StringTool str;
			str.set(sVal);			
			val = str.toLong();
			board.push_back(val);
		}
	} while (sz != NULL);

	// create the tree:
	Node* root = new Node;
	root->board = board;
	if (level==MAXIMAXING) root->max_level = true;
	else root->max_level = false;
	root->ply = ply;
	root->status = MOVEDECISION_CONTINUE;
	int qty = 0;
	qty = evaluateTree(root, &deadline);
	*quality = qty;

	// done processing:
	t1.setToNow();
	
	data->averageBranchingFactor = 6; 
	long work_time = t1 - t0; // milisec
	data->totalWorkTime  = work_time; 
	data->nodesEvaluated = root->nodes_below; 
	if (work_time>0)
		data->nodesEvaluatedPerSecond = root->nodes_below / ((float) work_time / 1000); 
	else 
		data->nodesEvaluatedPerSecond = 0;
	data->pctCompleted   = 1;
	delete root;
	
}
