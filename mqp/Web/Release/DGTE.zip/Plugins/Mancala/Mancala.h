#ifndef MANCALA_INCLUDED
#define MANCALA_INCLUDED

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include "stdafx.h"

#include "../../Idl/Types.h"

#define MAXGSTATE	100
#define MAXMOVE		1000
#define MAXBRANCH	100

#define MOVEDECISION_CONTINUE 0
#define MOVEDECISION_WIN      1
#define MOVEDECISION_LOOSE    2
#define MOVEDECISION_DRAW     3

#ifdef MANCALA_EXPORTS
	#define MANCALA_API __declspec(dllexport)
#else
	#define MANCALA_API __declspec(dllimport)
#endif

/////////////////////////////////////////////////////////////////////////////
// PrimeNumbers API

extern "C" MANCALA_API GameTypeData gameTypeData;

extern "C" MANCALA_API void evaluate (/*[in]*/ GameState gs, /*[in]*/ LevelType level, /*[in]*/ int ply, /*[in]*/ int timelimit, /*[out]*/ int *quality, /*[out]*/ HelperPerformanceData *data);

extern "C" MANCALA_API void split(/*[in]*/ GameState gs, /*[in]*/ LevelType level,/*[in]*/ int maxSize,/*[out]*/ int *actualSize,/*[out]*/ Move *moves);

extern "C" MANCALA_API void getQuickMove(/*[in]*/ GameState gs, /*[in]*/ LevelType level,/*[in]*/ int maxSize,/*[out]*/ int *actualSize,/*[out]*/ Move *moves, /*[out]*/ int *gameOver);



/////////////////////////////////////////////////////////////////////////////

#endif // MANCALA_INCLUDED
