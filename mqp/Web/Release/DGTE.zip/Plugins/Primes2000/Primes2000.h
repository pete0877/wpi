/////////////////////////////////////////////////////////////////////////////
//
// File Name:	PRIMES2000.h
// Description:	Interface of the PRIMES2000 class.
// Date:		11/15/99
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

#ifndef PRIMES2000_INCLUDED
#define PRIMES2000_INCLUDED

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <windows.h>
#include <string.h>
#include <stdio.h>

#include "../../Idl/Types.h"

#ifdef PRIMES2000_EXPORTS
	#define PRIMES2000_API __declspec(dllexport)
#else
	#define PRIMES2000_API __declspec(dllimport)
#endif

/////////////////////////////////////////////////////////////////////////////
// PRIMES2000 API

extern "C" PRIMES2000_API GameTypeData gameTypeData;

extern "C" PRIMES2000_API void evaluate (/*[in]*/ GameState gs, /*[in]*/ LevelType level, /*[in]*/ int ply, /*[in]*/ int timelimit, /*[out]*/ int *quality, /*[out]*/ HelperPerformanceData *data);

extern "C" PRIMES2000_API void split(/*[in]*/ GameState gs, /*[in]*/ LevelType level,/*[in]*/ int maxSize,/*[out]*/ int *actualSize,/*[out]*/ Move *moves);

extern "C" PRIMES2000_API void getQuickMove(/*[in]*/ GameState gs, /*[in]*/ LevelType level,/*[in]*/ int maxSize,/*[out]*/ int *actualSize,/*[out]*/ Move *moves, /*[out]*/ int *gameOver);

/////////////////////////////////////////////////////////////////////////////

#endif // PRIMES2000_INCLUDED
