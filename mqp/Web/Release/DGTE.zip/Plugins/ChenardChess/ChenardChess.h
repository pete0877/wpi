
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CHENARDCHESS_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// CHENARDCHESS_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef CHENARDCHESS_EXPORTS
#define CHENARDCHESS_API __declspec(dllexport)
#else
#define CHENARDCHESS_API __declspec(dllimport)
#endif

extern "C" CHENARDCHESS_API GameTypeData gameTypeData;
extern "C" CHENARDCHESS_API void evaluate(/*[in]*/GameState gs, /*[in]*/LevelType level,	/*[in]*/int ply, /*[in]*/int timelimit, /*[out]*/int *quality, /*[out]*/HelperPerformanceData *data);
extern "C" CHENARDCHESS_API void split(/*[in]*/GameState gs, /*[in]*/LevelType level, /*[in]*/int maxSize, /*[in, out]*/int *actualSize, /*[in, out, size_is(maxSize), length_is(*actualSize)]*/DGTEMove *moves);
extern "C" CHENARDCHESS_API void getQuickMove(/*[in]*/GameState gs, /*[in]*/LevelType level, /*[in]*/int maxSize, /*[in, out]*/int *actualSize, /*[in, out, size_is(maxSize), length_is(*actualSize)]*/DGTEMove *move, /*[out]*/int *gameOver);



