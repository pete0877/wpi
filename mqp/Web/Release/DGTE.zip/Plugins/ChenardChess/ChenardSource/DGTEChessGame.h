// DGTEChessGame.h: interface for the DGTEChessGame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DGTECHESSGAME_H__CBD215C9_CED0_4619_984B_BC112B094002__INCLUDED_)
#define AFX_DGTECHESSGAME_H__CBD215C9_CED0_4619_984B_BC112B094002__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CHESS.H"
#include "NullChessUI.h"
#include "../types.h"

class DGTEChessGame : public ChessGame  
{
public:
	// The following constructor automatically creates players.
	DGTEChessGame(ChessBoard theBoard, NullChessUI theUI): ChessGame(theBoard,theUI) {}

    // The following constructor refrains from creating players,
    // but is told what kind of player objects to expect.
    // Each of the cBOOLEAN parameters should be set to cTRUE iff
    // its respective player is an instance of the C++ class HumanPlayer.
    // Otherwise, the value should be cFALSE.
	DGTEChessGame(ChessBoard theBoard, 
			  NullChessUI theUI, 
			  cBOOLEAN whiteIsHuman,
			  cBOOLEAN blackIsHuman, 
			  ChessPlayer *_whitePlayer,
			  ChessPlayer *_blackPlayer):
				ChessGame(theBoard,theUI,whiteIsHuman,blackIsHuman,_whitePlayer,_blackPlayer) {}

    ~DGTEChessGame();

    void Play();

	
	void Evaluate(/*[in]*/	GameState gs,
				  /*[in]*/	LevelType level, 
				  /*[in]*/	int ply, 
				  /*[in]*/	int timelimit, 
				  /*[out]*/ int *quality, 
				  /*[out]*/ HelperPerformanceData *data);

	
				  
	void split(/*[in]*/	GameState gs, 
			   /*[in]*/	LevelType level,
			   /*[in]*/	int maxSize,
			   /*[out]*/int *actualSize,
			   /*[out]*/DGTEMove *moves);
	
	

	void getQuickMove(/*[in]*/ GameState gs, 
					  /*[in]*/ LevelType level,
					  /*[in]*/ int maxSize,
				  	  /*[out]*/ int *actualSize,
					  /*[out]*/ DGTEMove *moves, 
					  /*[out]*/ int *gameOver);


	// The following function tells the ChessGame to save the state
    // of the game in the given file after each move.
    // If filename == NULL, any existing auto-save is canceled.
    // The function returns cFALSE if any errors occur (e.g. out of memory).
    cBOOLEAN AutoSaveToFile ( const char *filename );

    void SetPlayers ( ChessPlayer * _white,  ChessPlayer * _black )
    {
        whitePlayer = _white;
        blackPlayer = _black;
    }
};

#endif // !defined(AFX_DGTECHESSGAME_H__CBD215C9_CED0_4619_984B_BC112B094002__INCLUDED_)
