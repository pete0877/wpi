// DGTEChessGame.cpp: implementation of the DGTEChessGame class.
//
//////////////////////////////////////////////////////////////////////

#include "DGTEChessGame.h"
#include <time.h>
#include <sys/timeb.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DGTEChessGame::~DGTEChessGame()
{

}

void DGTEChessGame::Play()
{
}

    // The following function tells the ChessGame to save the state
    // of the game in the given file after each move.
    // If filename == NULL, any existing auto-save is canceled.
    // The function returns cFALSE if any errors occur (e.g. out of memory).
cBOOLEAN DGTEChessGame::AutoSaveToFile ( const char *filename )
{
	return false;
}



void DGTEChessGame::Evaluate(/*[in]*/	GameState gs,
							 /*[in]*/	LevelType level, 
							 /*[in]*/	int ply, 
							 /*[in]*/	int timelimit, 
							 /*[out]*/	int *quality, 
							 /*[out]*/	HelperPerformanceData *data)
{
	_timeb _startTime, _endTime;
	_ftime(&_startTime);


	ChessBoard theBoard;
	NullChessUI theUI;
	ComputerChessPlayer thePlayer(theUI);
	Move theMove;
	INT32 timeSpent;
	int id;
	_timeb initTime1, initTime2;
	
	
	_ftime(&initTime1);
	srand(initTime1.millitm);
	id = rand();

/*
	FILE *logBook;
	logBook = fopen("ChenardChessLog.txt", "a+");
	fprintf(logBook,"[%i]InitEval: %s TimeLimit:%i PlyLimit:%i\n", id, gs.gamestate, timelimit, ply);
	fclose(logBook);
*/
	_ftime(&initTime1);
	theBoard.LoadEPD((char *)gs.gamestate);
	thePlayer.SetOpeningBookEnable(cFALSE);
	//loading the EPD might do this but not sure...
	//if white is moving, score will be +, if black -
	//so if maximizing, mult black by -1
	//   if minimizing, mult white by -1
	//if (level == MAXIMAXING) theBoard.SetWhiteToMove(cFALSE);
	//else theBoard.SetWhiteToMove(cTRUE);
	
	int scoreMultiplier = 1;
	if ((level == MAXIMIZING && theBoard.WhiteToMove() == cFALSE) || (level == MINIMIZING && theBoard.WhiteToMove() == cTRUE)) scoreMultiplier = -1;
	
	thePlayer.SetTimeLimit((INT32)(timelimit/10));
	thePlayer.SetSearchDepth(ply);
	_ftime(&initTime2);

	long initTime = ((initTime2.time*1000) + (initTime2.millitm)) - ((initTime1.time*1000) + (initTime1.millitm));
	
/*
	logBook = fopen("ChenardChessLog.txt", "a+");
	fprintf(logBook,"[%i]BeforeGetMove", id);
	fclose(logBook);
*/
	thePlayer.GetMove(theBoard,theMove,timeSpent);
	
/*
	logBook = fopen("ChenardChessLog.txt", "a+");
	fprintf(logBook,"[%i]AfterGetMove", id);
	fclose(logBook);
*/

	*quality = theMove.score * scoreMultiplier;

	data->averageBranchingFactor = theBoard.GetAvgBranching();
	data->nodesEvaluated = thePlayer.queryNodesEvaluated();
	data->pctCompleted = (float)((float)thePlayer.GetPrevCompletedLevel()/(float)ply);
	data->totalWorkTime = ((float)initTime + (float)(timeSpent*(float)10))/(float)1000.0;
	data->nodesEvaluatedPerSecond = (long)(data->nodesEvaluated / data->totalWorkTime);
	
	
	//HANDLE hIOMutex = CreateMutex (NULL, FALSE, NULL);
	//WaitForSingleObject(hIOMutex, INFINITE);

/*
	logBook = fopen("ChenardChessLog.txt", "a+");
	fprintf(logBook,"[%i]FinishEval: Quality:%i InitTime:%i EvalTime:%i\n", id, *quality, initTime, (timeSpent*10));
	fclose(logBook);
*/	
	//ReleaseMutex(hIOMutex);

	_ftime(&_endTime);
	long _totalWork = 
			((_endTime.time*1000) + (_endTime.millitm)) - 
			((_startTime.time*1000) + (_startTime.millitm));
	data->totalWorkTime = (((float) _totalWork) / 1000);	
}

	
				  
void DGTEChessGame::split(/*[in]*/	GameState gs, 
						  /*[in]*/	LevelType level,
						  /*[in]*/	int maxSize,
						  /*[out]*/	int *actualSize,
						  /*[out]*/	DGTEMove *moves)
{
	MoveList theMoveList;
	ChessBoard theBoard;
	NullChessUI theUI;
	ComputerChessPlayer thePlayer(theUI);
	thePlayer.SetOpeningBookEnable(cFALSE);
	theBoard.LoadEPD((char *)gs.gamestate);
	
	//theUI.DrawBoard(theBoard);
	
	//loading the EPD sets who moves
	//give leveltype to moveListToD....so that score is adjusted properly
	
	//theBoard.GenMoves(theMoveList);
	
	if (theBoard.WhiteToMove()==cTRUE) 
	{
		theBoard.GenWhiteMoves(theMoveList, &thePlayer);
		//thePlayer.GetPGMoves(theBoard,theMoveList);
	}
	else 
	{
		theBoard.GenBlackMoves(theMoveList, &thePlayer);
		//thePlayer.GetPGMoves(theBoard,theMoveList);
	}
	
	*actualSize = theMoveList.num;
	theBoard.MoveListToDGTEMoves(theMoveList, moves, actualSize, level);

	
/*	
	FILE *logBook;
	logBook = fopen("ChenardChessLog.txt", "a+");
	
	for(int i=0; i<theMoveList.num; i++)
	{
		fprintf(logBook,"Split: Move:%s GameState:%s[%i] Quality:%i Status:%s\n", moves[i].move, moves[i].gamestate.gamestate, moves[i].gamestate.actualSize, moves[i].quality, (moves[i].status==MOVEDECISION_CONTINUE ? "CONTINUE" : (moves[i].status==MOVEDECISION_WIN ? "WIN" : (moves[i].status==MOVEDECISION_LOOSE ? "LOOSE" : "DRAW"))));
	}
	fclose(logBook);
*/		
}
	
	

void DGTEChessGame::getQuickMove(/*[in]*/	GameState gs, 
								 /*[in]*/	LevelType level,
								 /*[in]*/	int maxSize,
				  				 /*[out]*/	int *actualSize,
								 /*[out]*/	DGTEMove *moves, 
								 /*[out]*/	int *gameOver)
{
	*actualSize = 0;
	*gameOver = MOVEDECISION_CONTINUE;
	return;
	
	ChessBoard theBoard;
	NullChessUI theUI;
	ComputerChessPlayer thePlayer(theUI);
	Move theMove;

	thePlayer.SetOpeningBookEnable(cTRUE);
	theBoard.LoadEPD((char *)gs.gamestate);



	/*
	if (theBoard.WhiteToMove())
    {
		if(!theBoard.WhiteCanMove())
		{
			// The game is over...
			if ((level == MAXIMAXING) && theBoard.WhiteInCheck()) *gameOver = MOVEDECISION_LOOSE;
			else if ((level == MINIMAZING) && theBoard.WhiteInCheck()) *gameOver = MOVEDECISION_WIN;
			else *gameOver = MOVEDECISION_DRAW;
		}
		else *gameOver = MOVEDECISION_CONTINUE;
	}
	else   // Black's turn to move...
	{
		if(!theBoard.BlackCanMove())
		{
            // The game is over...
			if ((level == MAXIMAXING) && theBoard.BlackInCheck()) *gameOver = MOVEDECISION_LOOSE;
			else if ((level == MINIMAZING) && theBoard.BlackInCheck()) *gameOver = MOVEDECISION_WIN;
			else *gameOver = MOVEDECISION_DRAW;
		}
		else *gameOver = MOVEDECISION_CONTINUE;
	}
	*/


	theBoard.SetDGTEGameOverStatus(gameOver, level);
	
	//only do it for starting gameState
	if (memcmp((char *)gs.gamestate, "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR", 43) != 0) return;

	if (*gameOver != MOVEDECISION_LOOSE)
	{
		if (theBoard.WhiteToMove() == cTRUE) 
		{
			if(thePlayer.GetWhiteOpening(theBoard,theMove))
			{
				*actualSize = 1;
				//theBoard.SetWhiteToMove(cTRUE);
				theBoard.MoveToDGTEMove(theMove,moves,level);
				//theBoard.SetDGTEGameOverStatus(gameOver);
			}
		}
		else 
		{
			if(thePlayer.GetBlackOpening(theBoard,theMove))
			{
				*actualSize = 1;
				//theBoard.SetWhiteToMove(cFALSE);
				theBoard.MoveToDGTEMove(theMove,moves,level);
				//theBoard.SetDGTEGameOverStatus(gameOver);
			}
		}
	}
/*
	FILE *logBook;
	logBook = fopen("ChenardChessLog.txt", "a+");
	
	fprintf(logBook,"QuickMoves[%i]: Move:%s GameState:%s[%i] Status:%s\n", &actualSize, moves[0].move, moves[0].gamestate.gamestate, moves[0].gamestate.actualSize, moves[0].quality, (moves[0].status==MOVEDECISION_CONTINUE ? "CONTINUE" : (moves[0].status==MOVEDECISION_WIN ? "WIN" : (moves[0].status==MOVEDECISION_LOOSE ? "LOOSE" : "DRAW"))));

	fclose(logBook);
*/
}
