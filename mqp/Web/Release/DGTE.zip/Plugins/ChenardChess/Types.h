/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Feb 13 23:39:25 2000
 */
/* Compiler settings for Types.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __Types_h__
#define __Types_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_Types_0000 */
/* [local] */ 

typedef struct  tagGameState
    {
    int actualSize;
    int maxSize;
    /* [length_is][size_is][ref] */ unsigned char __RPC_FAR *gamestate;
    }	GameState;

typedef struct  tagMove
    {
    int actualSize;
    int maxSize;
    /* [length_is][size_is][ref] */ unsigned char __RPC_FAR *move;
    int quality;
    int status;
    GameState gamestate;
    }	DGTEMove;

typedef 
enum tagLevelType
    {	MAXIMIZING	= 1,
	MINIMIZING	= 2
    }	LevelType;

typedef struct  tagGameTypeData
    {
    unsigned char gameName[ 64 ];
    unsigned char gameVersion[ 64 ];
    unsigned char gameDescription[ 256 ];
    unsigned char companyName[ 128 ];
    unsigned char legalCopyright[ 256 ];
    unsigned char legalTrademarks[ 256 ];
    unsigned char gameEncoding[ 256 ];
    int gameStateSize;
    int moveSize;
    int moveListSize;
    float averageBranchingFactor;
    }	GameTypeData;

typedef struct  tagHelperPerformanceData
    {
    float pctCompleted;
    float totalWorkTime;
    long nodesEvaluated;
    long nodesEvaluatedPerSecond;
    float averageBranchingFactor;
    }	HelperPerformanceData;



extern RPC_IF_HANDLE __MIDL_itf_Types_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_Types_0000_v0_0_s_ifspec;

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
