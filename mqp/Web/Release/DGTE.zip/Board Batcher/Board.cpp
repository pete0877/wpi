// Board.cpp: implementation of the Board class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Contest Batcher.h"
#include "Board.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Board::Board() { reset(); }

Board::~Board() { }

void Board::recordMove(CString move, bool white)
{
	lastMove = move;
	if (move == "O-O-O" || move == "o-o-o") {
		// QUEEN-SIDE CASTILING
		if (white) {
				WQUEENCASTLE = false;
				state[0][0] = ' ';
				state[0][3] = 'R';
				state[0][4] = ' ';
				state[0][2] = 'K';
		} else {
				BQUEENCASTLE = false;
				state[7][0] = ' ';
				state[7][3] = 'r';
				state[7][4] = ' ';
				state[7][2] = 'k';				
		}
	} else if (move == "O-O" || move == "o-o") {
		// KING-SIDE CASTILING
		if (white) {
			WKINGCASTLE = false;			
			state[0][7] = ' ';
			state[0][5] = 'R';
			state[0][4] = ' ';
			state[0][6] = 'K';				
		} else {
			BKINGCASTLE = false;
			state[7][7] = ' ';
			state[7][5] = 'r';
			state[7][4] = ' ';
			state[7][6] = 'k';				
		}
	} else {
		char *m = move.GetBuffer(0);
		int	 c1 = (int) m[0] - 'a';
		int	 c2 = (int) m[2] - 'a';
		int	 r1 = (int) m[1] - '1';
		int	 r2 = (int) m[3] - '1';
		char pon = state[r1][c1];
		// check castling
		if (pon == 'K') {
			WQUEENCASTLE = false;
			WKINGCASTLE  = false;
		}
		if (pon == 'k') {
			BQUEENCASTLE = false;
			BKINGCASTLE  = false;
		}
		if ((pon == 'R') && (c1 == 0)) WQUEENCASTLE = false;
		if ((pon == 'R') && (c1 == 7)) WKINGCASTLE = false;
		if ((pon == 'r') && (c1 == 0)) BQUEENCASTLE = false;
		if ((pon == 'r') && (c1 == 7)) BKINGCASTLE = false;
		state[r1][c1] = ' ';
		state[r2][c2] = pon;
	}
}

CString Board::getGameState(bool whiteWillMove)
{
	CString result;
	char tmp[50];
	int spaces;
	for (int r=7; r>=0; r--) {	
		spaces = 0;
		for (int c=0; c<8; c++) {
			if (state[r][c] == ' ') spaces++;
			else {
				if (spaces>0) {
					sprintf(tmp ,"%d", spaces);
					result = result + tmp;
					spaces = 0;
				}
				tmp[0] = state[r][c];
				tmp[1] = '\0';
				result = result	+ tmp;
			}
		}
		if (spaces>0) {
			sprintf(tmp ,"%d", spaces);
			result = result + tmp;
			spaces = 0;
		}
		if (r > 0) result = result + "/";
	}
	if (whiteWillMove) 
		result = result + " w ";
	else
		result = result + " b ";

	if (WKINGCASTLE) result = result + "K";
	if (WQUEENCASTLE) result = result + "Q";
    if (BKINGCASTLE) result = result + "k";
    if (BQUEENCASTLE) result = result + "q";
	if (!WKINGCASTLE || !BKINGCASTLE || !WQUEENCASTLE || !BQUEENCASTLE) result = result + "-";
	result = result + " bm 1; id 1;";
	return result;
}

void Board::reset()
{
	for (int r=0; r<8; r++) 
		for (int c=0; c<8; c++) 
			if (r == 1)
				state[r][c] = 'P';
			else if (r == 6)
				state[r][c] = 'p';
			else
				state[r][c] = ' ';
	state[0][0] = 'R';  // WHITE - TOP
    state[0][1] = 'N';
    state[0][2] = 'B';
    state[0][3] = 'Q';
    state[0][4] = 'K';
    state[0][5] = 'B';
    state[0][6] = 'N';
    state[0][7] = 'R';
	state[7][0] = 'r';  // BLACK - BOTTOM
    state[7][1] = 'n';
    state[7][2] = 'b';
    state[7][3] = 'q';
    state[7][4] = 'k';
    state[7][5] = 'b';
    state[7][6] = 'n';
    state[7][7] = 'r';	

	WKINGCASTLE = false;
    WQUEENCASTLE = false;
    BKINGCASTLE = false;
    BQUEENCASTLE = false;

	/*
	for (r=0; r<8; r++) for (int c=0; c<8; c++) state[r][c] = ' ';
    state[0][0] = 'K';
    state[7][7] = 'k';
    state[7][6] = 'r';	
    state[7][5] = 'r';	
	*/

}

CString Board::getView(CString wplayer, CString bplayer)
{
	CString result = "";		
	result = result + "Last move: ";
	result = result + lastMove;
	result = result + "\x00D\x00A\x00D\x00A";
	result = result + bplayer + " (blacks)\x00D\x00A\x00D\x00A";	
	result = result + "  .A.B.C.D.E.F.G.H.\x00D\x00A";	
	CString line;
	char sztmp[50];
	for (int r=7; r>=0; r--) {		
		sprintf(sztmp, "%d ", r + 1);
		line = sztmp;
		for (int c=0; c<8; c++) {
			line = line + "|";
			line = line + state[r][c];
		}
		line = line + "|\x00D\x00A";
		result = result + line;
	}	
	result = result +  "\x00D\x00A";
	result = result + wplayer + " (whites)\x00D\x00A\x00D\x00A";
	
	return result;
}
