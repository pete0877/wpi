// Contest BatcherDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Contest Batcher.h"
#include "Contest BatcherDlg.h"
#include "GameOverException.h"
#include "StringTool.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContestBatcherDlg dialog

CContestBatcherDlg::CContestBatcherDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CContestBatcherDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CContestBatcherDlg)
	m_server1 = _T("");
	m_encoding = _T("");
	m_time_limit = 0;
	m_max_ply = 0;
	m_games_count = 0;
	m_server1port = 0;
	m_fixed = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	this->m_server1 = "localhost";
	this->m_max_ply = 6;
	this->m_time_limit = 6000; 
	this->m_encoding = "EPD";
	this->m_games_count = 10;
	this->m_server1port = 23;
}

void CContestBatcherDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CContestBatcherDlg)
	DDX_Text(pDX, IDC_EDIT1, m_server1);
	DDX_Text(pDX, IDC_EDIT3, m_encoding);
	DDX_Text(pDX, IDC_EDIT4, m_time_limit);
	DDX_Text(pDX, IDC_EDIT5, m_max_ply);
	DDX_Text(pDX, IDC_EDIT6, m_games_count);
	DDX_Text(pDX, IDC_EDIT8, m_server1port);
	DDX_Text(pDX, IDC_EDIT11, m_fixed);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CContestBatcherDlg, CDialog)
	//{{AFX_MSG_MAP(CContestBatcherDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnStart)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	ON_EN_CHANGE(IDC_EDIT3, OnChangeEdit3)
	ON_EN_CHANGE(IDC_EDIT4, OnChangeEdit4)
	ON_EN_CHANGE(IDC_EDIT5, OnChangeEdit5)
	ON_EN_CHANGE(IDC_EDIT6, OnChangeEdit6)
	ON_EN_CHANGE(IDC_EDIT8, OnChangeEdit8)
	ON_EN_CHANGE(IDC_EDIT11, OnChangeEdit11)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContestBatcherDlg message handlers

BOOL CContestBatcherDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CContestBatcherDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CContestBatcherDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CContestBatcherDlg::OnStart() 
{	
	char str[500];

	CSocket* socket = new CSocket();	
	CString command;
	CString argument;
	CString argument2;
	CString argument3;
	CString argument4;
	CString argument5;
	 
	socket->Create();
	if (socket->Connect(m_server1.GetBuffer(0), m_server1port) == 0) {		
		AfxMessageBox("Could not connect");
	}					
	quickReceive(socket, command);
	quickReceive(socket, argument);
	quickSend(socket, "CLIENT_ENCODING");
	quickSend(socket, "EPD");
	quickReceive(socket, command);
	quickReceive(socket, argument); 
	quickReceive(socket, command);
	quickReceive(socket, argument); 
	quickReceive(socket, argument2); 
	quickSend(socket, "CLIENT_GAMETYPE");
	quickSend(socket, "0");
	sprintf(str, "%d", this->m_max_ply);
	quickSend(socket, "CLIENT_PLY");
	quickSend(socket, str);
	sprintf(str, "%d", this->m_time_limit);
	quickSend(socket, "CLIENT_EVALTIME");
	quickSend(socket, str);
	quickReceive(socket, command);

	for (int game_number = 1; game_number<=m_games_count; game_number++) {
	
		quickSend(socket, "CLIENT_GAMESTATE");
		CString tmpGameState = m_fixed;
		quickSend(socket, tmpGameState);		
		quickReceive(socket, command);
		quickReceive(socket, argument); 
		quickReceive(socket, command); 
		quickReceive(socket, argument); 
		quickReceive(socket, argument2); 
		quickReceive(socket, argument3);
		quickReceive(socket, argument4);
	}
	socket->Close();
	delete socket;
	AfxMessageBox("Done!");
}

void CContestBatcherDlg::quickSend(CSocket *sock, CString str)
{
	if (sock->Send(str.GetBuffer(0), str.GetLength() + 1)==SOCKET_ERROR ) throw new CException();			
}

void CContestBatcherDlg::quickReceive(CSocket *sock, CString &str)
{
	str = "";		
	char tmp[10];
	char delimiter = 0;
	int size;		
	do {
		if ((size=sock->Receive(tmp, 1))==0) throw new CException;			
		if (GetLastError()!=0) throw new CException;			
		if ((size==1) && (tmp[0]!=delimiter)) str = str + tmp[0];
	} while (tmp[0]!=delimiter);	
}


void CContestBatcherDlg::OnChangeEdit1() 
{
	CString s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT1);
	textbox->GetWindowText(s);
	this->m_server1 = s;	
}

void CContestBatcherDlg::OnChangeEdit3() 
{
	CString s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT3);
	textbox->GetWindowText(s);
	this->m_encoding = s;
}

void CContestBatcherDlg::OnChangeEdit4() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT4);
	textbox->GetWindowText(s);		
	this->m_time_limit = s.toLong();	
}

void CContestBatcherDlg::OnChangeEdit5() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT5);
	textbox->GetWindowText(s);
	this->m_max_ply = s.toLong();	
}

void CContestBatcherDlg::OnChangeEdit6() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT6);
	textbox->GetWindowText(s);
	this->m_games_count = s.toLong();	
}

void CContestBatcherDlg::OnChangeEdit8() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT8);
	textbox->GetWindowText(s);
	this->m_server1port = s.toLong();	
}

void CContestBatcherDlg::OnChangeEdit11() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT11);
	textbox->GetWindowText(s);
	m_fixed = s;	
}
