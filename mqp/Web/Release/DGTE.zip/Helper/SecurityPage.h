#if !defined(AFX_SECURITYPAGE_H__AFF6838A_1988_4861_8317_B37D01395A4C__INCLUDED_)
#define AFX_SECURITYPAGE_H__AFF6838A_1988_4861_8317_B37D01395A4C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SecurityPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// SecurityPage dialog

class SecurityPage : public CDialog
{
// Construction
public:
	SecurityPage(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(SecurityPage)
	enum { IDD = IDD_PROPPAGE_LARGE };
	CString	m_username;
	CString	m_password;
	CString	m_domain;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SecurityPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(SecurityPage)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SECURITYPAGE_H__AFF6838A_1988_4861_8317_B37D01395A4C__INCLUDED_)
