/////////////////////////////////////////////////////////////////////////////
//
// File Name:	HelperApp.h
// Description:	Interface of the HelperApp class.
// Date:		11/15/99
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

#ifndef HELPERAPP_INCLUDED
#define HELPERAPP_INCLUDED

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "Resource.h"
#include "Plugin.h"
#include "StatusDlg.h"
#include "StatusWnd.h"	// Added by ClassView

/////////////////////////////////////////////////////////////////////////////
// Class HelperApp

class HelperApp : public CWinApp
{
// Construction
public:
	HelperApp();

// Attributes
public:
	CString m_serverAddress;
	BOOL m_autoRegister;
	BOOL m_autoUnregister;
	BOOL m_enableVars;
	int m_timeMTTF;
	int m_timeMDT;
	int m_factorSDF;
	CString m_pluginName;
	CString m_username;
	CString m_password;
	CString m_domain;

	bool m_registered;

// Operations
public:
	void Activate(bool active);
	void ActivateVars(int active);
	Plugin * GetPlugin();
	bool IsActive();
	bool IsRegistered();
	void LogMessage(CString message);
	void Register();
	void Unregister();
	void SetPlugin(CString pluginName);
	void ShowStatus();
	void ShutdownATL();
	void LoadSettings();
	void SaveSettings();
	CString GetStatus();
	void SetStatus(CString status);

// Overridables
public:

// Implementation
public:
	StatusWnd *m_window;
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	CSemaphore m_helperLock;
	CString m_helperAddress;
	Plugin *m_plugin;
	StatusDlg *m_status;

// Overrides
public:
	//{{AFX_VIRTUAL(CMyClass)
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Generated message map functions
protected:
	//{{AFX_MSG(HelperApp)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bATLInited;
private:
	BOOL InitATL();
};

//{{AFX_INSERT_LOCATION}}

extern HelperApp theApp;

/////////////////////////////////////////////////////////////////////////////

#endif // HELPERAPP_INCLUDED
