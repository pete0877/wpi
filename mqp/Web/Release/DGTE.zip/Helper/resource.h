//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Helper.rc
//
#define ID_CLOSE                        2
#define ID_CLEAR                        3
#define IDD_ABOUTBOX                    100
#define IDD_ABOUT_DIALOG                103
#define IDD_STATUS_DIALOG               105
#define IDS_PROPSHT_CAPTION             106
#define IDD_SECURITY_PAGE               107
#define IDS_PROPSHT_CAPTION1            109
#define IDD_CONNECTION_PAGE             110
#define IDD_GENERAL_PAGE                110
#define IDD_PLUGINS_PAGE                111
#define IDD_GAMEPROPERTIES_DIALOG       112
#define IDR_HELPER                      113
#define IDR_HELPEROBJ                   114
#define IDD_STATUSDLG_DIALOG            115
#define IDR_MAINFRAME                   128
#define IDR_HELPERTYPE                  129
#define IDB_SPLASH                      130
#define IDR_POPUP_MENU                  131
#define IDB_ABOUT_IMG                   132
#define IDC_HAND                        134
#define IDB_ABOUT                       136
#define IDC_HOMEPAGE                    1002
#define IDC_ABOUT_HYPERLINK             1002
#define IDC_SERVER                      1003
#define IDC_SERVERADDRESS               1003
#define IDC_PLUGINS                     1004
#define IDC_TIMEMTTF                    1004
#define IDC_PASSWORD                    1004
#define IDC_ABOUT                       1005
#define IDC_FACTORSDF                   1005
#define IDC_GET_PLUGINS                 1006
#define IDC_GETPLUGINS                  1006
#define IDC_TIMEMDT                     1006
#define IDC_EDIT1                       1007
#define IDC_GAMENAME                    1007
#define IDC_OUTPUT                      1007
#define IDC_GAMEVERSION                 1008
#define IDC_GAMEDESCRIPTION             1009
#define IDC_COMPANYNAME                 1010
#define IDC_LEGALCOPYRIGHT              1011
#define IDC_LEGALTRADEMARKS             1012
#define IDC_AVGALPHABETAGAIN            1013
#define IDC_AVGBRANCHINGFACTOR          1014
#define IDC_AUTOREGISTER                1015
#define IDC_VERSION                     1016
#define IDC_AUTOUNREGISTER              1016
#define IDC_ENABLEVARS                  1017
#define IDC_USERNAME                    1017
#define IDC_DOMAIN                      1018
#define ID_HELPER_SHOWSTATUS            32771
#define ID_HELPER_CONNECT               32772
#define ID_HELPER_REGISTER              32772
#define ID_HELPER_ABOUT                 32773
#define ID_HELPER_PROPERTIES            32774
#define ID_HELPER_CLOSE                 32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           116
#endif
#endif
