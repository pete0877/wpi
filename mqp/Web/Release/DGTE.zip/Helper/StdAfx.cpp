/////////////////////////////////////////////////////////////////////////////
//
// File Name:	StdAfx.h
// Description:	Source file that includes just the standard includes.
// Date:		11/15/99
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

#include "StdAfx.h"

#ifdef _ATL_STATIC_REGISTRY
	#include <statreg.h>
#endif

#include <atlimpl.cpp>
