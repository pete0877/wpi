/////////////////////////////////////////////////////////////////////////////
//
// File Name:	PropertyPages.cpp
// Description:	Defines the class behaviors for the application.
// Date:		11/15/99
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

#include "StdAfx.h"
#include "PluginProperties.h"
#include "PropertyPages.h"
#include "..\Include\Exceptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(GeneralPage, CPropertyPage)
IMPLEMENT_DYNCREATE(PluginsPage, CPropertyPage)
IMPLEMENT_DYNCREATE(SecurityPage, CPropertyPage)

/////////////////////////////////////////////////////////////////////////////
// GeneralPage message map

BEGIN_MESSAGE_MAP(GeneralPage, CPropertyPage)
	//{{AFX_MSG_MAP(GeneralPage)
	ON_BN_CLICKED(IDC_ENABLEVARS, OnEnableVars)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// GeneralPage property page

GeneralPage::GeneralPage() : CPropertyPage(GeneralPage::IDD)
{
	//{{AFX_DATA_INIT(GeneralPage)
	m_serverAddress = _T("");
	m_autoRegister = FALSE;
	m_autoUnregister = FALSE;
	m_enableVars = FALSE;
	m_timeMTTF = 0;
	m_timeMDT = 0;
	m_factorSDF = 0;
	//}}AFX_DATA_INIT
}

void GeneralPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(GeneralPage)
	DDX_Text(pDX, IDC_SERVERADDRESS, m_serverAddress);
	DDX_Check(pDX, IDC_AUTOREGISTER, m_autoRegister);
	DDX_Check(pDX, IDC_AUTOUNREGISTER, m_autoUnregister);
	DDX_Check(pDX, IDC_ENABLEVARS, m_enableVars);
	DDX_Text(pDX, IDC_TIMEMTTF, m_timeMTTF);
	DDV_MinMaxInt(pDX, m_timeMTTF, 0, 1000000000);
	DDX_Text(pDX, IDC_TIMEMDT, m_timeMDT);
	DDV_MinMaxInt(pDX, m_timeMDT, 0, 1000000000);
	DDX_Text(pDX, IDC_FACTORSDF, m_factorSDF);
	DDV_MinMaxInt(pDX, m_factorSDF, 0, 10000);
	//}}AFX_DATA_MAP
}

BOOL GeneralPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	if( m_enableVars == FALSE ) {
		EnableVars(false);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void GeneralPage::OnEnableVars()
{
	bool enables = false;

	CButton enableVars;
	enableVars.Attach(GetDlgItem(IDC_ENABLEVARS)->m_hWnd);
	
	if( enableVars.GetCheck() == TRUE )
		EnableVars(true);
	else
		EnableVars(false);

	enableVars.Detach();
}

/////////////////////////////////////////////////////////////////////////////
// GeneralPage implementation

void GeneralPage::EnableVars(bool state)
{
	CEdit control;
	control.Attach(GetDlgItem(IDC_TIMEMTTF)->m_hWnd);
	control.EnableWindow(state);
	control.Detach();
	control.Attach(GetDlgItem(IDC_TIMEMDT)->m_hWnd);
	control.EnableWindow(state);
	control.Detach();
	control.Attach(GetDlgItem(IDC_FACTORSDF)->m_hWnd);
	control.EnableWindow(state);
	control.Detach();
}

/////////////////////////////////////////////////////////////////////////////
// PluginsPage message map

BEGIN_MESSAGE_MAP(PluginsPage, CPropertyPage)
	//{{AFX_MSG_MAP(PluginsPage)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_LBN_DBLCLK(IDC_PLUGINS, OnDblclkPlugins)
	ON_LBN_SELCHANGE(IDC_PLUGINS, OnSelchangePlugins)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// PluginsPage property page

PluginsPage::PluginsPage() : CPropertyPage(PluginsPage::IDD)
{
	//{{AFX_DATA_INIT(PluginsPage)
	m_selectedPlugin = _T("");
	m_selectedPluginIndex = -1;
	//}}AFX_DATA_INIT

	// Initialize the plugins vector
	InitPlugins();
}

void PluginsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);

	//{{AFX_DATA_MAP(PluginsPage)
	DDX_Control(pDX, IDC_GETPLUGINS, m_hyperLink);
	DDX_LBIndex(pDX, IDC_PLUGINS, m_selectedPluginIndex);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// PluginsPage message handlers

void PluginsPage::OnAbout() 
{
	if( m_selectedPluginIndex == -1 ) {
		AfxMessageBox(_T("Please select one of the plugins first."));
		return;
	}
	
	Plugin &plugin = m_plugins.at(m_selectedPluginIndex);
	GameTypeData data = *(plugin.gameTypeData);

	PluginProperties propSheet(data);
	propSheet.DoModal();
}

void PluginsPage::OnDblclkPlugins() 
{
	OnAbout();
}

BOOL PluginsPage::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Initialize the plugin URL.
	m_hyperLink.SetURL(_T("http://www.wpi.edu/~peterg/MQP/Plugins/"));
	m_hyperLink.SetColours(m_hyperLink.GetLinkColour(), m_hyperLink.GetLinkColour());
	m_hyperLink.SetLinkCursor(AfxGetApp()->LoadCursor(IDC_HAND));
	::SetCursor(::LoadCursor(NULL, IDC_ARROW));
	
	// Initialize the plugins listbox.
	CListBox listBox;
	listBox.Attach(GetDlgItem(IDC_PLUGINS)->m_hWnd);

	for(int i = 0; i < m_plugins.size(); i++)
	{
		Plugin &plugin = m_plugins.at(i);
		CString pluginDll = plugin.m_pluginDll;
		CString gameName = plugin.gameTypeData->gameName;
		if( m_selectedPluginIndex == -1 ) {
			if( m_selectedPlugin == pluginDll )
				m_selectedPluginIndex = i;
		}
		listBox.AddString(gameName);
	}

	if( m_selectedPluginIndex != -1)
		listBox.SetCurSel(m_selectedPluginIndex);

	listBox.Detach();

	return TRUE;
}

void PluginsPage::OnOK() 
{
	CPropertyPage::OnOK();

	if(m_selectedPluginIndex != -1) {
		Plugin &plugin = m_plugins.at(m_selectedPluginIndex);
		m_selectedPlugin = plugin.m_pluginDll;
	}
	else
		m_selectedPlugin = _T("");
}

void PluginsPage::OnSelchangePlugins() 
{
	CListBox listBox;

	listBox.Attach(GetDlgItem(IDC_PLUGINS)->m_hWnd);
	m_selectedPluginIndex = listBox.GetCurSel();
	listBox.Detach();	
}

/////////////////////////////////////////////////////////////////////////////
// PluginsPage implementation

void PluginsPage::InitPlugins() 
{
	WIN32_FIND_DATA fd;

	HANDLE hFind = ::FindFirstFile(_T("Plugins\\*.dll"), &fd);
	
	if( hFind != INVALID_HANDLE_VALUE ) {
		do {
			if( !(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ) {
				CString pluginDll = fd.cFileName;
				try {
					Plugin plugin(pluginDll);
					m_plugins.push_back(plugin);
				}
				catch(PluginNotFoundException e) {
					TRACE(e.getMessage());
				}
				catch(InvalidPluginException e) {
					TRACE(e.getMessage());
				}
			}
		} while( ::FindNextFile(hFind, &fd) );
		
		FindClose(hFind);
	}
}

/////////////////////////////////////////////////////////////////////////////
// SecurityPage message map

BEGIN_MESSAGE_MAP(SecurityPage, CPropertyPage)
	//{{AFX_MSG_MAP(SecurityPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SecurityPage dialog

SecurityPage::SecurityPage() : CPropertyPage(SecurityPage::IDD)
{
	//{{AFX_DATA_INIT(SecurityPage)
	m_username = _T("");
	m_password = _T("");
	m_domain = _T("");
	//}}AFX_DATA_INIT
}


void SecurityPage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SecurityPage)
	DDX_Text(pDX, IDC_USERNAME, m_username);
	DDX_Text(pDX, IDC_PASSWORD, m_password);
	DDX_Text(pDX, IDC_DOMAIN, m_domain);
	//}}AFX_DATA_MAP
}

/////////////////////////////////////////////////////////////////////////////
// SecurityPage message handlers
