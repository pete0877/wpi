// SecurityPage.cpp : implementation file
//

#include "stdafx.h"
#include "helper.h"
#include "SecurityPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// SecurityPage dialog


SecurityPage::SecurityPage(CWnd* pParent /*=NULL*/)
	: CDialog(SecurityPage::IDD, pParent)
{
	//{{AFX_DATA_INIT(SecurityPage)
	m_username = _T("");
	m_password = _T("");
	m_domain = _T("");
	//}}AFX_DATA_INIT
}


void SecurityPage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(SecurityPage)
	DDX_Text(pDX, IDC_USERNAME, m_username);
	DDX_Text(pDX, IDC_PASSWORD, m_password);
	DDX_Text(pDX, IDC_DOMAIN, m_domain);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(SecurityPage, CDialog)
	//{{AFX_MSG_MAP(SecurityPage)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// SecurityPage message handlers
