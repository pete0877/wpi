/////////////////////////////////////////////////////////////////////////////
//
// File Name:	HelperApp.cpp
// Description:	Defines the class behaviors for the application.
// Date:		11/15/99
// Author:		sjastrzebski
//
// Copyright � 1999 Worcester Polytechnic Institute, All Rights Reserved.

#include "StdAfx.h"
#include "Helper.h"
#include "Splash.h"
#include "..\Include\Exceptions.h"
#include "..\Idl\Helper_i.h"
#include "..\Idl\Helper_i.c"
#include "..\Idl\Server_i.h"
#include "..\Idl\Server_i.c"

#include <comdef.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only HelperApp object

HelperApp theApp;

/////////////////////////////////////////////////////////////////////////////
// HelperApp message map

BEGIN_MESSAGE_MAP(HelperApp, CWinApp)
	//{{AFX_MSG_MAP(StatusWnd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// HelperApp implementation

HelperApp::HelperApp() 
{
	// Initialize data members.
	//
	m_serverAddress = _T("");
	m_autoRegister = false;
	m_autoUnregister = false;
	m_enableVars = false;
	m_timeMTTF = 0;
	m_timeMDT = 0;
	m_factorSDF = 0;
	m_plugin = NULL;
	m_username = _T("");
	m_password = _T("");
	m_domain = _T("");
	m_pluginName = _T("");

	m_registered = false;

	// Obtain helper's IP address
	//
	TCHAR address[256];
	DWORD addressSize = sizeof(address);
	GetComputerName(address, &addressSize);
	m_helperAddress = address;
}

BOOL HelperApp::InitInstance()
{
	// Set process priority.
	HANDLE hProcess = ::GetCurrentProcess();
	::SetPriorityClass(hProcess, IDLE_PRIORITY_CLASS);

	// Initialize COM layer.
	//
	if (!InitATL())
		return FALSE;

	// Set COM security level to low.
	//
	HRESULT hr;

	hr = CoInitializeSecurity(NULL, -1, NULL, NULL,
                 RPC_C_AUTHN_LEVEL_NONE, 
                 RPC_C_IMP_LEVEL_IMPERSONATE,
                 NULL, 
                 EOAC_NONE, 
                 NULL);

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated)
	{
		return TRUE;
	}

	// Load the settings from the windows registry.
	//
	SetRegistryKey(_T("DGTE"));
	LoadSettings();

	// Create the status dialog.
	//
	m_status = new StatusDlg;
	m_status->Create(IDD_STATUSDLG_DIALOG);

	LogMessage(_T("Helper started."));

	// Initialize the plugin and register the helper.
	//
	if( m_pluginName != "" ) {
		SetPlugin(m_pluginName);
	}
	if( m_plugin != NULL && m_autoRegister ) {
		try {
			Register();
		}
		catch(ConnectionException e) {
			AfxMessageBox(_T("Failed to register with the server:\n\n" + e.getMessage()));
		}
	}

	// Finish the rest of the initialization.
	//
	Splash::EnableSplashScreen();

	// Create the main window.
	//
	m_window = new StatusWnd;
	m_window->LoadFrame(IDR_MAINFRAME);
	m_pMainWnd = m_window;

	// Activate Controls Variables
	//
	if( m_enableVars )
		ActivateVars(m_enableVars);

	return TRUE;
}

int HelperApp::ExitInstance()
{
	LogMessage(_T("Closing helper..."));

	// Let the server know that you no longer want to play.
	//
	if( m_autoUnregister && IsRegistered() ) {
		try {
			Unregister();
		}
		catch(ConnectionException e) {
			TRACE(_T("In HelperApp.ExitInstance: " + e.getMessage()));
		}
	}

	// Remove the trayicon from the task bar.
	if( m_window != NULL )
			m_window->m_TrayIcon.RemoveIcon();

	// Destroy the main window.
	if( m_window != NULL )
		delete m_window;

	// Unload the plugin.
	//
	if( m_plugin != NULL )
		delete m_plugin;

	// Destroy the status dialog.
	//
	if( m_status != NULL )
		delete m_status;

	// Save the settings in the windows registry.
	//
	SaveSettings();

	// Uninitialize COM layer.
	//
	if( m_bATLInited )
		ShutdownATL();

	return CWinApp::ExitInstance();
}

void HelperApp::Activate(bool state)
{
	if( state == false ) {
		LogMessage(_T("Deactivating helper..."));

		if( IsActive() && IsRegistered() ) {
			ShutdownATL();
		}
	}
	else {
		LogMessage(_T("Activating helper..."));

		if( !IsActive() ) {
			InitATL();
			try {
				Register();
			}	
			catch(ConnectionException e) {
				AfxMessageBox(_T("Activate: Failed to register with the server:\n\n" + e.getMessage()));
			}
		}
	}
}

void HelperApp::ActivateVars(int state)
{
	if( state )
		if( m_timeMTTF > 0 )
			m_window->SetTimer(1, m_timeMTTF * 1000, NULL);
	else
		m_window->KillTimer(1);
}

Plugin *HelperApp::GetPlugin()
{
	return m_plugin;
}

bool HelperApp::IsActive()
{
	return (m_bATLInited ? true : false);
}

bool HelperApp::IsRegistered()
{
	return m_registered;
}

void HelperApp::LogMessage(CString message)
{
	m_helperLock.Lock();

	if( m_status != NULL )
		m_status->AddMessage(message);
	
	m_helperLock.Unlock();
}

void HelperApp::Register()
{
	LogMessage(_T("Registering with '") + m_serverAddress + _T("'..."));

	if( m_serverAddress == "" ) {
		CString msg = _T("No server address specified.");
		LogMessage(msg);
		throw ConnectionException(msg);
	}

	if( m_plugin == NULL ) {
		CString msg = _T("No plugin module loaded.");
		LogMessage(msg);
		throw ConnectionException(msg);
	}
	
	HelperSecurity helperSecurity;
	
	strcpy((char *)helperSecurity.helperUsername, m_username);
	strcpy((char *)helperSecurity.helperPassword, m_password);
	strcpy((char *)helperSecurity.helperDomain, m_domain);

	IHelperRegistrar *pRegisterHelper;
	HRESULT hr;

    COSERVERINFO cs;
    memset(&cs, 0, sizeof(cs));
    cs.pwszName = _bstr_t(m_serverAddress);

    MULTI_QI qi[1];
    memset(qi, 0, sizeof(qi)); 

    qi[0].pIID = &IID_IHelperRegistrar;

	hr = CoCreateInstanceEx(CLSID_HelperRegistrar, NULL, CLSCTX_SERVER, &cs, 1, qi);

	if( FAILED(hr) ) {
		_com_error e(hr);
		CString msg = e.ErrorMessage();
		msg = msg + _T(".");
		LogMessage(msg);
		throw ConnectionException(msg);
	}

	pRegisterHelper = (IHelperRegistrar *) qi[0].pItf;
     
	hr = pRegisterHelper->registerHelper((unsigned char *)LPCTSTR(m_helperAddress), *m_plugin->gameTypeData, 15, helperSecurity);
	
	pRegisterHelper->Release();

	if( SUCCEEDED(hr) ) {
		m_registered = true;
		if( m_window != NULL )
			m_window->m_TrayIcon.SetTooltipText(_T("DGTE Helper: Registered"));
	}
	else {
		CString msg = _T("Could not register the helper with the server.");
		LogMessage(msg);
		throw ConnectionException(msg);
	}
}

void HelperApp::Unregister()
{
	LogMessage(_T("Unregistering with '") + m_serverAddress + _T("'..."));

	IHelperRegistrar *pRegisterHelper;
	HRESULT hr;

    COSERVERINFO cs;
    memset(&cs, 0, sizeof(cs));
    cs.pwszName = _bstr_t(m_serverAddress);

    MULTI_QI qi[1];
    memset(qi, 0, sizeof(qi)); 

    qi[0].pIID = &IID_IHelperRegistrar;

	hr = CoCreateInstanceEx(CLSID_HelperRegistrar, NULL, CLSCTX_LOCAL_SERVER | CLSCTX_REMOTE_SERVER, &cs, 1, qi);

	if( FAILED(hr) ) {
		_com_error e(hr);
		CString msg = e.ErrorMessage();
		msg = msg + _T(".");
		LogMessage(msg);
		throw ConnectionException(msg);
	}

	pRegisterHelper = (IHelperRegistrar *) qi[0].pItf;

	hr = pRegisterHelper->unregisterHelper((unsigned char *)LPCTSTR(m_helperAddress));
	
	pRegisterHelper->Release();

	if( SUCCEEDED(hr) ) {
		m_registered = false;
		if( m_window != NULL )
			m_window->m_TrayIcon.SetTooltipText(_T("DGTE Helper: Not registered"));
	}
	else {
		CString msg = _T("Could not unregister the helper with the server.");
		LogMessage(msg);
		throw ConnectionException(msg);
	}

	if( m_bATLInited ) {
		ShutdownATL();
		InitATL();
	}
}

void HelperApp::SetPlugin(CString pluginName)
{
	LogMessage(_T("Loading plugin ") + pluginName + _T("..."));

	try {
		Plugin *plugin = new Plugin(pluginName);
		if( m_plugin != NULL )
			delete m_plugin;
		m_plugin = plugin;
	}
	catch(Exception e) {
		CString msg = e.getMessage();
		LogMessage(msg);
	}
}

void HelperApp::ShowStatus()
{
	m_status->ShowWindow(SW_SHOW);
}

void HelperApp::ShutdownATL()
{
	_Module.RevokeClassObjects();
	_Module.Term();
	CoUninitialize();
}

void HelperApp::LoadSettings()
{
	m_pluginName = GetProfileString(_T("Settings"), _T("PluginName"), m_pluginName);
	m_serverAddress = GetProfileString(_T("Settings"), _T("ServerAddress"), m_serverAddress);
	m_autoRegister = GetProfileInt(_T("Settings"), _T("AutoRegister"), m_autoRegister);
	m_autoUnregister = GetProfileInt(_T("Settings"), _T("AutoUnregister"), m_autoUnregister);
	m_enableVars = GetProfileInt(_T("Settings"), _T("EnableVars"), m_enableVars);
	m_timeMTTF = GetProfileInt(_T("Settings"), _T("TimeMTTF"), m_timeMTTF);
	m_timeMDT = GetProfileInt(_T("Settings"), _T("TimeMDT"), m_timeMDT);
	m_factorSDF = GetProfileInt(_T("Settings"), _T("FactorSDF"), m_factorSDF);
	m_username = GetProfileString(_T("Settings"), _T("UserName"), m_username);
	m_password = GetProfileString(_T("Settings"), _T("Password"), m_password);
	m_domain = GetProfileString(_T("Settings"), _T("Domain"), m_domain);
}

void HelperApp::SaveSettings()
{
	WriteProfileString(_T("Settings"), _T("PluginName"), m_pluginName);
	WriteProfileString(_T("Settings"), _T("ServerAddress"), m_serverAddress);
	WriteProfileInt(_T("Settings"), _T("AutoRegister"), m_autoRegister);
	WriteProfileInt(_T("Settings"), _T("AutoUnregister"), m_autoUnregister);
	WriteProfileInt(_T("Settings"), _T("EnableVars"), m_enableVars);
	WriteProfileInt(_T("Settings"), _T("TimeMTTF"), m_timeMTTF);
	WriteProfileInt(_T("Settings"), _T("TimeMDT"), m_timeMDT);
	WriteProfileInt(_T("Settings"), _T("FactorSDF"), m_factorSDF);
	WriteProfileString(_T("Settings"), _T("UserName"), m_username);
	WriteProfileString(_T("Settings"), _T("Password"), m_password);
	WriteProfileString(_T("Settings"), _T("Domain"), m_domain);
}

CString HelperApp::GetStatus()
{
	return m_window->m_TrayIcon.GetTooltipText();
}

void HelperApp::SetStatus(CString status)
{
	m_helperLock.Lock();

	m_window->m_TrayIcon.SetTooltipText(status);

	m_helperLock.Unlock();
}

/////////////////////////////////////////////////////////////////////////////
// HelperApp message handlers

BOOL HelperApp::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following lines were added by the Splash Screen component.
	if (Splash::PreTranslateAppMessage(pMsg))
		return TRUE;

	return CWinApp::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////
// HelperApp COM support

#include "HelperObj.h"

BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY(CLSID_Helper, HelperObj)
END_OBJECT_MAP()

BOOL HelperApp::InitATL()
{
	m_bATLInited = TRUE;

#if _WIN32_WINNT >= 0x0400
	HRESULT hRes = CoInitializeEx(NULL, COINIT_MULTITHREADED);
#else
	HRESULT hRes = CoInitialize(NULL);
#endif

	if (FAILED(hRes))
	{
		m_bATLInited = FALSE;
		return FALSE;
	}

	_Module.Init(ObjectMap, AfxGetInstanceHandle());
	_Module.dwThreadID = GetCurrentThreadId();

	LPTSTR lpCmdLine = GetCommandLine(); //this line necessary for _ATL_MIN_CRT
	TCHAR szTokens[] = _T("-/");

	BOOL bRun = TRUE;
	LPCTSTR lpszToken = _Module.FindOneOf(lpCmdLine, szTokens);
	while (lpszToken != NULL)
	{
		if (lstrcmpi(lpszToken, _T("UnregServer"))==0)
		{
			_Module.UpdateRegistryFromResource(IDR_HELPER, FALSE);
			_Module.UnregisterServer(TRUE); //TRUE means typelib is unreg'd
			bRun = FALSE;
			break;
		}
		if (lstrcmpi(lpszToken, _T("RegServer"))==0)
		{
			_Module.UpdateRegistryFromResource(IDR_HELPER, TRUE);
			_Module.RegisterServer(TRUE);
			bRun = FALSE;
			break;
		}
		lpszToken = _Module.FindOneOf(lpszToken, szTokens);
	}

	if (!bRun)
	{
		m_bATLInited = FALSE;
		_Module.Term();
		CoUninitialize();
		return FALSE;
	}

	hRes = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER, 
		REGCLS_MULTIPLEUSE);
    //hRes = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER, 
	//        REGCLS_MULTIPLEUSE | REGCLS_SUSPENDED);
    //_ASSERTE(SUCCEEDED(hRes));
    //hRes = CoResumeClassObjects();

	if (FAILED(hRes))
	{
		m_bATLInited = FALSE;
		CoUninitialize();
		return FALSE;
	}	

	return TRUE;
}
