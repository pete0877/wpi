// Contest Batcher.h : main header file for the CONTEST BATCHER application
//

#if !defined(AFX_CONTESTBATCHER_H__30395804_E3EE_11D3_91CB_004095100085__INCLUDED_)
#define AFX_CONTESTBATCHER_H__30395804_E3EE_11D3_91CB_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "Contest BatcherDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CContestBatcherApp:
// See Contest Batcher.cpp for the implementation of this class
//

class CContestBatcherApp : public CWinApp
{
public:
	CContestBatcherApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContestBatcherApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CContestBatcherApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
	CContestBatcherDlg* theDialog;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTESTBATCHER_H__30395804_E3EE_11D3_91CB_004095100085__INCLUDED_)
