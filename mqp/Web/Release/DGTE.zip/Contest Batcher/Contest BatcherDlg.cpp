// Contest BatcherDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Contest Batcher.h"
#include "Contest BatcherDlg.h"
#include "GameOverException.h"
#include "StringTool.h"
#include "SimpleDateTime.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContestBatcherDlg dialog

CContestBatcherDlg::CContestBatcherDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CContestBatcherDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CContestBatcherDlg)
	m_server1 = _T("");
	m_server2 = _T("");
	m_encoding = _T("");
	m_time_limit = 0;
	m_max_ply = 0;
	m_games_count = 0;
	m_server1port = 0;
	m_server2port = 0;
	m_time_limit_black = 0;
	m_max_ply_black = 0;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	this->m_server1 = "localhost";
	this->m_server2 = "localhost";
	this->m_max_ply = 10;
	this->m_time_limit = 20; 
	this->m_max_ply_black = 10;
	this->m_time_limit_black = 20; 
	this->m_encoding = "EPD";
	this->m_games_count = 3;
	this->m_server1port = 23;
	this->m_server2port = 23;
}

void CContestBatcherDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CContestBatcherDlg)
	DDX_Text(pDX, IDC_EDIT1, m_server1);
	DDX_Text(pDX, IDC_EDIT2, m_server2);
	DDX_Text(pDX, IDC_EDIT3, m_encoding);
	DDX_Text(pDX, IDC_EDIT4, m_time_limit);
	DDX_Text(pDX, IDC_EDIT5, m_max_ply);
	DDX_Text(pDX, IDC_EDIT6, m_games_count);
	DDX_Text(pDX, IDC_EDIT8, m_server1port);
	DDX_Text(pDX, IDC_EDIT9, m_server2port);
	DDX_Text(pDX, IDC_EDIT44, m_time_limit_black);
	DDX_Text(pDX, IDC_EDIT55, m_max_ply_black);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CContestBatcherDlg, CDialog)
	//{{AFX_MSG_MAP(CContestBatcherDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnStart)
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	ON_EN_CHANGE(IDC_EDIT2, OnChangeEdit2)
	ON_EN_CHANGE(IDC_EDIT3, OnChangeEdit3)
	ON_EN_CHANGE(IDC_EDIT4, OnChangeEdit4)
	ON_EN_CHANGE(IDC_EDIT5, OnChangeEdit5)
	ON_EN_CHANGE(IDC_EDIT6, OnChangeEdit6)
	ON_EN_CHANGE(IDC_EDIT8, OnChangeEdit8)
	ON_EN_CHANGE(IDC_EDIT9, OnChangeEdit9)
	ON_EN_CHANGE(IDC_EDIT44, OnChangeEdit44)
	ON_EN_CHANGE(IDC_EDIT55, OnChangeEdit55)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContestBatcherDlg message handlers

BOOL CContestBatcherDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CContestBatcherDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CContestBatcherDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CContestBatcherDlg::OnStart() 
{	

	clearLog();
	CSocket* socket_white = new CSocket();	
	CSocket* socket_black = new CSocket();
	CString command;
	CString argument;
	CString argument2;
	CString argument3;
	CString argument4;
	CString argument5;
	 
	int server_1_wins	= 0;
	int server_2_wins	= 0;
	int draws			= 0;

	CString socket_white_address, socket_black_address;
	socket_white_address = m_server1;
	socket_black_address = m_server2;

	int socket_white_port, socket_black_port;
	socket_white_port = m_server1port;
	socket_black_port = m_server2port;


	bool fliped = false;
	SimpleDateTime now;

	char str[1000];
	int last_count = 1;
	bool loop_again = true;
while (loop_again) {
	try {
		for (int game_number = last_count; game_number<=m_games_count; game_number++) {
			// half way through we have to switch the sides:
			if (!fliped && (game_number == ((m_games_count/2) +1))) {
				fliped = true;
				CString tmp_address = socket_white_address;
				socket_white_address = socket_black_address;
				socket_black_address = tmp_address;
				int tmp_port; 
				tmp_port = socket_white_port;
				socket_white_port = socket_black_port;
				socket_black_port = tmp_port;
			}

			// connect server 1:
			socket_white->Create();
			if (socket_white->Connect(socket_white_address.GetBuffer(0), socket_white_port) == 0) {		
				addToLog(socket_white_address + " connection failed", true);			
				throw new CException();
			}					
			quickReceive(socket_white, command);
			quickReceive(socket_white, argument);
			quickSend(socket_white, "CLIENT_ENCODING");
			quickSend(socket_white, "EPD");
			quickReceive(socket_white, command);
			quickReceive(socket_white, argument); 
			quickReceive(socket_white, command);
			quickReceive(socket_white, argument); 
			quickReceive(socket_white, argument2); 
			quickSend(socket_white, "CLIENT_GAMETYPE");
			quickSend(socket_white, "0");
			sprintf(str, "%d", this->m_max_ply);
			quickSend(socket_white, "CLIENT_PLY");
			quickSend(socket_white, str);
			sprintf(str, "%d", this->m_time_limit);
			quickSend(socket_white, "CLIENT_EVALTIME");
			quickSend(socket_white, str);
			quickReceive(socket_white, command);
			addToLog(socket_white_address + " connected (whites)", true);					
			
			// connect to server with blacks
			socket_black->Create();
			if (socket_black->Connect(socket_black_address.GetBuffer(0), socket_black_port) == 0) {		
				addToLog(socket_black_address + " connection failed", true);					
				throw new CException();
			}					
			quickReceive(socket_black, command);
			quickReceive(socket_black, argument);
			quickSend(socket_black, "CLIENT_ENCODING");
			quickSend(socket_black, "EPD");
			quickReceive(socket_black, command);
			quickReceive(socket_black, argument); 
			quickReceive(socket_black, command);
			quickReceive(socket_black, argument); 
			quickReceive(socket_black, argument2); 
			quickSend(socket_black, "CLIENT_GAMETYPE");
			quickSend(socket_black, "0");
			sprintf(str, "%d", this->m_max_ply_black);
			quickSend(socket_black, "CLIENT_PLY");
			quickSend(socket_black, str);
			sprintf(str, "%d", this->m_time_limit_black);
			quickSend(socket_black, "CLIENT_EVALTIME");
			quickSend(socket_black, str);
			quickReceive(socket_black, command);
			addToLog(socket_black_address + " connected (blacks)", true);				

			CString game_winner;
			CString tmpBoardView;
			
			game_winner = "NA";
			sprintf(str, "Started game number %d", game_number);
			addToLog(str, true);

			board.reset();
			tmpBoardView = board.getView(socket_white_address, socket_black_address);			
			showBoard(tmpBoardView);									
			history.push_back(tmpBoardView);			
			CString theStatus;

			bool nextMoveIsWhite = true;
			CString tmpGameState;
			try {
				do {

					// send the game state to server white:
					quickSend(socket_white, "CLIENT_GAMESTATE");
					tmpGameState = board.getGameState(nextMoveIsWhite);
					quickSend(socket_white, tmpGameState);		
					quickReceive(socket_white, command);
					quickReceive(socket_white, argument); 
					// receive the move from server white
					quickReceive(socket_white, command); 
					quickReceive(socket_white, argument); 
					theStatus = argument;					
					quickReceive(socket_white, argument2); 
					quickReceive(socket_white, argument3);
					quickReceive(socket_white, argument4);
					board.recordMove(argument2, nextMoveIsWhite);
					nextMoveIsWhite = !nextMoveIsWhite;

					now.setToNow();
					CString _tmp = "   ";
					_tmp = _tmp + now.toString();
					_tmp = _tmp + " (white: ";
					_tmp = _tmp + argument2;
					_tmp = _tmp + ")";
					addToLog(_tmp, false);
			
					// show the board
					tmpBoardView = board.getView(socket_white_address, socket_black_address);			
					showBoard(tmpBoardView);									
					history.push_back(tmpBoardView);			

					if (theStatus == "DRAW") throw new GameOverException("NA");
					if (theStatus == "WIN") throw new GameOverException(socket_white_address);
					if (theStatus == "LOOSE") throw new GameOverException(socket_black_address);

					// send the game state to server black:
					quickSend(socket_black, "CLIENT_GAMESTATE");
					tmpGameState = board.getGameState(nextMoveIsWhite);
					quickSend(socket_black, tmpGameState);		
					quickReceive(socket_black, command);
					quickReceive(socket_black, argument); 
					// receive the move from server black
					quickReceive(socket_black, command); 
					quickReceive(socket_black, argument); 
					theStatus = argument;					
					quickReceive(socket_black, argument2); 
					quickReceive(socket_black, argument3);
					quickReceive(socket_black, argument4);
					board.recordMove(argument2, nextMoveIsWhite);
					nextMoveIsWhite = !nextMoveIsWhite;

					now.setToNow();
					_tmp = "   ";
					_tmp = _tmp + now.toString();
					_tmp = _tmp + " (black: ";
					_tmp = _tmp + argument2;
					_tmp = _tmp + ")";
					addToLog(_tmp, false);

					// show the board
					tmpBoardView = board.getView(socket_white_address, socket_black_address);			
					showBoard(tmpBoardView);									
					history.push_back(tmpBoardView);			

					if (theStatus == "DRAW") throw new GameOverException("NA");
					if (theStatus == "WIN") throw new GameOverException(socket_black_address);
					if (theStatus == "LOOSE") throw new GameOverException(socket_white_address);


				} while (true);
			} catch (GameOverException* e) {
				// game was completed fine:
				last_count++;
				// check if we need to loop again:
				if (game_number==m_games_count) {
					// it was the last game
					loop_again = false;
				}
				game_winner = e->winner;
				e->Delete();
			}

			if (game_winner == m_server1) server_1_wins++;
			if (game_winner == m_server2) server_2_wins++;
			if (game_winner == "NA")	  draws++;

			saveGame(game_number, game_winner);

			sprintf(str, "Game %d winner: %s", game_number, game_winner.GetBuffer(0));
			addToLog(str, true);

			// disconnect and do another game
			socket_white->Close();
			socket_black->Close();
		}
		addToLog("-------------------------", true);
		sprintf(str, "%s wins: %d", m_server1.GetBuffer(0),server_1_wins);
		addToLog(str, true);
		sprintf(str, "%s wins: %d", m_server2.GetBuffer(0),server_2_wins);
		addToLog(str, true);
		sprintf(str, "Draws: %d", draws);
		addToLog(str, true);
	} catch (CException* e) {
		e->Delete();		
	}
	delete socket_white;
	delete socket_black;
	if (loop_again) {
		addToLog("RETRY!!!", true);
	}
}
	addToLog("Ending contest", true);
}

void CContestBatcherDlg::quickSend(CSocket *sock, CString str)
{
	if (sock->Send(str.GetBuffer(0), str.GetLength() + 1)==SOCKET_ERROR ) throw new CException();			
}

void CContestBatcherDlg::quickReceive(CSocket *sock, CString &str)
{
	str = "";		
	char tmp[10];
	char delimiter = 0;
	int size;		
	do {
		if ((size=sock->Receive(tmp, 1))==0) throw new CException;			
		if (GetLastError()!=0) throw new CException;			
		if ((size==1) && (tmp[0]!=delimiter)) str = str + tmp[0];
	} while (tmp[0]!=delimiter);	
}

void CContestBatcherDlg::clearLog()
{
	CString s = "";
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT7);
	textbox->SetWindowText(s);	
}

void CContestBatcherDlg::addToLog(CString event, bool window)
{
	if (window) {
		CString s = "";
		CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT7);
		textbox->GetWindowText(s);
		event = event + "\x00D\x00A";
		s = event + s;
		textbox->SetWindowText(s);
		textbox->Invalidate();
		textbox->UpdateWindow();
	}

	FILE *logBook;
	logBook = fopen("contest.txt", "a+");
	fprintf(logBook,"%s\n", event.GetBuffer(0));
	fclose(logBook);
}

void CContestBatcherDlg::showBoard(CString view)
{
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT10);
	textbox->SetWindowText(view);
}

void CContestBatcherDlg::OnChangeEdit1() 
{
	CString s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT1);
	textbox->GetWindowText(s);
	this->m_server1 = s;	
}

void CContestBatcherDlg::OnChangeEdit2() 
{
	CString s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT2);
	textbox->GetWindowText(s);
	this->m_server2 = s;
}

void CContestBatcherDlg::OnChangeEdit3() 
{
	CString s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT3);
	textbox->GetWindowText(s);
	this->m_encoding = s;
}

void CContestBatcherDlg::OnChangeEdit4() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT4);
	textbox->GetWindowText(s);		
	this->m_time_limit = s.toLong();	
}

void CContestBatcherDlg::OnChangeEdit5() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT5);
	textbox->GetWindowText(s);
	this->m_max_ply = s.toLong();	
}

void CContestBatcherDlg::OnChangeEdit6() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT6);
	textbox->GetWindowText(s);
	this->m_games_count = s.toLong();	
}

void CContestBatcherDlg::OnChangeEdit8() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT8);
	textbox->GetWindowText(s);
	this->m_server1port = s.toLong();	
}

void CContestBatcherDlg::OnChangeEdit9() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT9);
	textbox->GetWindowText(s);
	this->m_server2port = s.toLong();	
}

void CContestBatcherDlg::saveGame(int n, CString winner)
{
	char tmp[5000];
	sprintf(tmp, "game%d.txt", n);
	CFile f;
	f.Open(tmp, CFile::modeWrite | CFile::modeCreate);
	
	vector<CString>::iterator enHist;
	CString tmpState;
	for (enHist=history.begin(); enHist!=history.end(); enHist++) {
		tmpState = *enHist;
		strcpy(tmp,tmpState.GetBuffer(0));
		f.Write((const void *) tmp, strlen(tmp));
	}
	sprintf(tmp,"GAME WINNER: %s", winner.GetBuffer(0));
	f.Write((const void *) tmp, strlen(tmp));
	f.Close();
}

void CContestBatcherDlg::OnChangeEdit44() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT44);
	textbox->GetWindowText(s);		
	this->m_time_limit_black = s.toLong(); 
}

void CContestBatcherDlg::OnChangeEdit55() 
{
	StringTool s;
	CEdit* textbox = (CEdit*) GetDlgItem(IDC_EDIT55);
	textbox->GetWindowText(s);
	this->m_max_ply_black = s.toLong();	
}

