// GameOverException.cpp: implementation of the GameOverException class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Contest Batcher.h"
#include "GameOverException.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

GameOverException::GameOverException(CString the_winner)
{
	winner = the_winner;
}

GameOverException::~GameOverException()
{

}
