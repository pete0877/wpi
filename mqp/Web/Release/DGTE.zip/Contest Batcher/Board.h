// Board.h: interface for the Board class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOARD_H__30395813_E3EE_11D3_91CB_004095100085__INCLUDED_)
#define AFX_BOARD_H__30395813_E3EE_11D3_91CB_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Board  
{
public:
	CString getView(CString wplayer, CString bplayer);
	void reset();
	CString getGameState(bool  whiteWillMove);
	void recordMove(CString move, bool white);
	Board();
	virtual ~Board();

protected:
	CString lastMove;
	char state[8][8];
	bool WKINGCASTLE;
	bool WQUEENCASTLE;
    bool BKINGCASTLE;
    bool BQUEENCASTLE;
};

#endif // !defined(AFX_BOARD_H__30395813_E3EE_11D3_91CB_004095100085__INCLUDED_)
