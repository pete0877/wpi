// GameOverException.h: interface for the GameOverException class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEOVEREXCEPTION_H__30395816_E3EE_11D3_91CB_004095100085__INCLUDED_)
#define AFX_GAMEOVEREXCEPTION_H__30395816_E3EE_11D3_91CB_004095100085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class GameOverException : public CException
{
public:
	CString winner;
	GameOverException(CString the_winner);
	virtual ~GameOverException();
};

#endif // !defined(AFX_GAMEOVEREXCEPTION_H__30395816_E3EE_11D3_91CB_004095100085__INCLUDED_)
