// Contest BatcherDlg.h : header file
//

#if !defined(AFX_CONTESTBATCHERDLG_H__30395806_E3EE_11D3_91CB_004095100085__INCLUDED_)
#define AFX_CONTESTBATCHERDLG_H__30395806_E3EE_11D3_91CB_004095100085__INCLUDED_

#include "Board.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CContestBatcherDlg dialog

class CContestBatcherDlg : public CDialog
{
// Construction
public:
	void saveGame(int n, CString winner);
	void showBoard(CString view);
	void addToLog(CString event, bool window);
	void clearLog();
	void quickReceive(CSocket *sock, CString& str);
	void quickSend(CSocket* sock, CString str);
	CContestBatcherDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CContestBatcherDlg)
	enum { IDD = IDD_CONTESTBATCHER_DIALOG };
	CString	m_server1;
	CString	m_server2;
	CString	m_encoding;
	int		m_time_limit;
	int		m_max_ply;
	int		m_games_count;
	int		m_server1port;
	int		m_server2port;
	int		m_time_limit_black;
	int		m_max_ply_black;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContestBatcherDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	vector<CString> history;
	Board board;
	
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CContestBatcherDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	afx_msg void OnChangeEdit1();
	afx_msg void OnChangeEdit2();
	afx_msg void OnChangeEdit3();
	afx_msg void OnChangeEdit4();
	afx_msg void OnChangeEdit5();
	afx_msg void OnChangeEdit6();
	afx_msg void OnChangeEdit8();
	afx_msg void OnChangeEdit9();
	afx_msg void OnChangeEdit44();
	afx_msg void OnChangeEdit55();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTESTBATCHERDLG_H__30395806_E3EE_11D3_91CB_004095100085__INCLUDED_)
