// ChenardChess.cpp : Defines the entry point for the DLL application.
//

#include "ChenardSource/chess.h"
#include "ChenardSource/NullChessUI.h"
#include "ChenardSource/DGTEChessGame.h"
#include "stdafx.h"
#include "ChenardChess.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

void ChessFatal ( const char *message ) {}

GameTypeData gameTypeData =
//GNUCHESSMT_API GameTypeData gameTypeData =
{
	"Chenard Chess Evaluator",
	"1.0",
	"Generates and evaluates chess moves.",
	"Worcester Polytechnic Institute",
	"Copyright � 1999-2000 Worcester Polytechnic Institute",
	"", 
	"EPD",
	1024, 
	100, 
	150,
	30
};

void evaluate(/*[in]*/GameState gs, /*[in]*/LevelType level,	/*[in]*/int ply, /*[in]*/int timelimit, /*[out]*/int *quality, /*[out]*/HelperPerformanceData *data)
{
	//HANDLE  hIOMutex= CreateMutex (NULL, FALSE, NULL);

	//WaitForSingleObject( hIOMutex, INFINITE );

	ChessBoard theBoard;
	NullChessUI theUI;
	DGTEChessGame theGame(theBoard, theUI);
	
	theGame.Evaluate(gs,level, ply, timelimit, quality, data);
	
	//ReleaseMutex( hIOMutex);
}

void split(/*[in]*/GameState gs, /*[in]*/LevelType level, /*[in]*/int maxSize, /*[in, out]*/int *actualSize, /*[in, out, size_is(maxSize), length_is(*actualSize)]*/DGTEMove *moves)
{
	ChessBoard theBoard;
	NullChessUI theUI;
	DGTEChessGame theGame(theBoard, theUI);
	
	theGame.split(gs, level, maxSize, actualSize, moves);
}

void getQuickMove(/*[in]*/GameState gs, /*[in]*/LevelType level, /*[in]*/int maxSize, /*[in, out]*/int *actualSize, /*[in, out, size_is(maxSize), length_is(*actualSize)]*/DGTEMove *move, /*[out]*/int *gameOver)
{
	ChessBoard theBoard;
	NullChessUI theUI;
	DGTEChessGame theGame(theBoard, theUI);
	
	theGame.getQuickMove(gs, level, maxSize, actualSize, move, gameOver);
}

