// NullChessUI.h: interface for the NullChessUI class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NULLCHESSUI_H__E827A269_163B_4405_AF28_F00292F36DEE__INCLUDED_)
#define AFX_NULLCHESSUI_H__E827A269_163B_4405_AF28_F00292F36DEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CHESS.H"
#include <stdio.h>

class NullChessUI : public ChessUI  
{
public:
	NullChessUI();
	~NullChessUI();

	ChessPlayer *CreatePlayer ( ChessSide ) {return NULL;}

    // NOTE:  The following is called only when there is a
    //        checkmate, stalemate, or draw by attrition.
    //        The function is NOT called if a player resigns.
    void ReportEndOfGame ( ChessSide winner ) {}

    void Resign ( ChessSide iGiveUp, QuitGameReason ) {}

    //--------------------------------------------------------------//
    //  The following function should return cTRUE if the Move      //
    //  was read successfully, or cFALSE to abort the game.         //
    //  The move does not have to be legal; if an illegal move      //
    //  is returned, the caller will repeatedly call until a        //
    //  legal move is obtained.                                     //
    //--------------------------------------------------------------//
    cBOOLEAN ReadMove ( ChessBoard &, int &source, int &dest ) {return 0;}

    SQUARE PromotePawn ( int PawnDest, ChessSide ) {return 0;}

	//--------------------------------------------------------------
	//  The following member function is called bracketing
	//  when a ComputerChessPlayer object is deciding upon a move.
	//  The parameter 'entering' is cTRUE when the computer is
	//  starting to think, and cFALSE when the thinking is done.
	//--------------------------------------------------------------
	void ComputerIsThinking ( cBOOLEAN entering ) {}

    //--------------------------------------------------------------
    //  The following function should display the given Move
    //  in the context of the given ChessBoard.  The Move
    //  passed to this function will always be legal for the
    //  given ChessBoard.
    //
    //  The purpose of this function is for a non-human ChessPlayer
    //  to have a chance to animate the chess board.
    //  The ChessGame does not call this function; it is up
    //  to a particular kind of ChessPlayer to do so if needed.
    //--------------------------------------------------------------
    void DisplayMove ( ChessBoard &, Move ) {}

    //----------------------------------------------------------------
    //  The following function is called by the ChessGame after
    //  each player moves, so that the move can be displayed
    //  in standard chess notation, if the UI desires.
    //  It is helpful to use the ::FormatChessMove() function
    //  for this purpose.
    //  The parameter 'thinkTime' is how long the player thought
    //  about the move, expressed in hundredths of seconds.
    //
    //  NOTE:  This function is called BEFORE the move
    //  has been made on the given ChessBoard.
    //  This is necessary for ::FormatChessMove() to work.
    //----------------------------------------------------------------
    void RecordMove ( ChessBoard &, Move, INT32 thinkTime ) {}

    //----------------------------------------------------------------
    //   The following function is called when a method other than
    //   searching has been used to choose a move, e.g.
    //   opening book or experience database.
    //----------------------------------------------------------------
    virtual void ReportSpecial ( const char *msg )  {}

    virtual void ReportComputerStats (
        INT32   thinkTime,
        UINT32  nodesVisited,
        UINT32  nodesEvaluated,
        UINT32  nodesGenerated,
        int     fwSearchDepth,
        UINT32  vis [NODES_ARRAY_SIZE],
        UINT32  gen [NODES_ARRAY_SIZE] ) {}

    //--------------------------------------------------------------//
    //  The following function should display the given ChessBoard  //
    //  to the user.                                                //
    //  In a GUI, this means updating the board display to the      //
    //  given board's contents.                                     //
    //  In TTY-style UI, this means printing out a new board.       //
    //--------------------------------------------------------------//
    void DrawBoard ( const ChessBoard &board ) 
	{
		/*
		cBOOLEAN whiteView = cFALSE;
		if ( board.WhiteToMove() )
	        whiteView = whitePlayerType==PT_HUMAN;
	    else
			whiteView = blackPlayerType!=PT_HUMAN;
	
	    if ( rotateBoard )
    		whiteView = !whiteView;
		*/
	    int x, y;
	
	    printf ( "\n    +--------+\n" );
	
	    /*
		if ( whiteView )
	    {
			for ( y=7; y >= 0; y-- )
			{
	            printf ( "    |" );
				for ( x=0; x <= 7; x++ )
				{
	                SQUARE square = board.GetSquareContents ( x, y );
					printf ( "%c", PieceRepresentation(square) );
				}
	
				printf ( "|%d\n", y + 1 );
			}
			printf ( "    +--------+\n" );
			printf ( "     abcdefgh\n\n\n" );
		}
		else
		*/
		{
	        for ( y=0; y <= 7; y++ )
			{
	            printf ( "    |" );
				for ( x=7; x >= 0; x-- )
				{
	                SQUARE square = board.GetSquareContents ( x, y );
					printf ( "%c", PieceRepresentation(square) );
				}
	
				printf ( "|%d\n", y + 1 );
			}
			printf ( "    +--------+\n" );
			printf ( "     hgfedcba\n\n\n" );
		}
	}
	
	//----------------------------------------------------------------
	//  The following member function displays a prompt and waits
	//  for acknowledgement from the user.
	//----------------------------------------------------------------
	void NotifyUser ( const char *message ) {}
	
    void DisplayBestMoveSoFar (
        const ChessBoard &,
        Move,
        int level ) {}

    void DisplayCurrentMove (
        const ChessBoard &,
        Move,
        int level ) {}

    void DisplayBestPath (
        const ChessBoard &,
        const BestPath & )  {}

    // The ComputerChessPlayer calls this to announce that it
    // has found a forced mate.

    void PredictMate ( int numMovesFromNow ) {}

    // The following function is a hook for debugging every move in a
    // search.  The board is given before the move is made in it, so
    // that correct move notation can be calculated.

    void DebugPly ( int depth, ChessBoard &, Move ) {}

    // The following function is called whenever a level is exited.
    void DebugExit ( int depth, ChessBoard &, SCORE ) {}
};

#endif // !defined(AFX_NULLCHESSUI_H__E827A269_163B_4405_AF28_F00292F36DEE__INCLUDED_)
