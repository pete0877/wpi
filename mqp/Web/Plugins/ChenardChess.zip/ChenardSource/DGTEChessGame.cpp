// DGTEChessGame.cpp: implementation of the DGTEChessGame class.
//
//////////////////////////////////////////////////////////////////////

#include "DGTEChessGame.h"
#include <time.h>
#include <sys/timeb.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DGTEChessGame::~DGTEChessGame()
{

}

void DGTEChessGame::Play()
{
}

    // The following function tells the ChessGame to save the state
    // of the game in the given file after each move.
    // If filename == NULL, any existing auto-save is canceled.
    // The function returns cFALSE if any errors occur (e.g. out of memory).
cBOOLEAN DGTEChessGame::AutoSaveToFile ( const char *filename )
{
	return false;
}



void DGTEChessGame::Evaluate(/*[in]*/	GameState gs,
							 /*[in]*/	LevelType level, 
							 /*[in]*/	int ply, 
							 /*[in]*/	int timelimit, 
							 /*[out]*/	int *quality, 
							 /*[out]*/	HelperPerformanceData *data)
{
	ChessBoard theBoard;
	NullChessUI theUI;
	ComputerChessPlayer thePlayer(theUI);
	Move theMove;
	INT32 timeSpent;
	
	_timeb initTime1, initTime2;
	
	_ftime(&initTime1);
	theBoard.LoadEPD((char *)gs.gamestate);
	thePlayer.SetOpeningBookEnable(cFALSE);
	//loading the EPD might do this but not sure...
	//if white is moving, score will be +, if black -
	//so if maximizing, mult black by -1
	//   if minimizing, mult white by -1
	//if (level == MAXIMAXING) theBoard.SetWhiteToMove(cFALSE);
	//else theBoard.SetWhiteToMove(cTRUE);
	
	int scoreMultiplier = 1;
	if ((level == MAXIMAXING && theBoard.WhiteToMove() == cFALSE) || (level == MINIMAZING && theBoard.WhiteToMove() == cTRUE)) scoreMultiplier = -1;
	
	thePlayer.SetTimeLimit((INT32)(timelimit/10));
	thePlayer.SetSearchDepth(ply);
	_ftime(&initTime2);

	long initTime = ((initTime2.time*1000) + (initTime2.millitm)) - ((initTime1.time*1000) + (initTime1.millitm));
	thePlayer.GetMove(theBoard,theMove,timeSpent);
	*quality = theMove.score * scoreMultiplier;

	data->averageBranchingFactor = theBoard.GetAvgBranching();
	data->nodesEvaluated = thePlayer.queryNodesEvaluated();
	data->pctCompleted = (float)((float)thePlayer.GetPrevCompletedLevel()/(float)ply);
	data->totalWorkTime = ((float)initTime + (float)(timeSpent*(float)10))/(float)1000.0;
	data->nodesEvaluatedPerSecond = (long)(data->nodesEvaluated / data->totalWorkTime);

	
	HANDLE    hIOMutex= CreateMutex (NULL, FALSE, NULL);
	WaitForSingleObject( hIOMutex, INFINITE );

		FILE *logBook;
		logBook = fopen("ChenardChessLog.txt", "a+");
		fprintf(logBook,"Eval: %s %i \n\tTimeLimit:%i PlyLimit:%i InitTime:%i EvalTime:%i\n", gs.gamestate, *quality, timelimit, ply, initTime, (timeSpent*10));
		fclose(logBook);
	
	ReleaseMutex( hIOMutex);
	
}

	
				  
void DGTEChessGame::split(/*[in]*/	GameState gs, 
						  /*[in]*/	LevelType level,
						  /*[in]*/	int maxSize,
						  /*[out]*/	int *actualSize,
						  /*[out]*/	DGTEMove *moves)
{
	MoveList theMoveList;
	ChessBoard theBoard;
	//NullChessUI theUI;
	//ComputerChessPlayer thePlayer(theUI);
	//thePlayer.SetOpeningBookEnable(cFALSE);
	theBoard.LoadEPD((char *)gs.gamestate);
	
	//theUI.DrawBoard(theBoard);
	
	//loading the EPD sets who moves
	//give leveltype to moveListToD....so that score is adjusted properly
	
	theBoard.GenMoves(theMoveList);
	/*
	if (level == MAXIMAXING) 
	{
		theBoard.SetWhiteToMove(cTRUE);
		theBoard.GenWhiteMoves(theMoveList, &thePlayer);
	}
	else 
	{
		theBoard.SetWhiteToMove(cFALSE);
		theBoard.GenBlackMoves(theMoveList, &thePlayer);
	}
	*/
	*actualSize = theMoveList.num;
	theBoard.MoveListToDGTEMoves(theMoveList, moves, actualSize, level);


	//FILE *logBook;
	//logBook = fopen("ChenardChessLog.txt", "a+");
	
	//for(int i=0; i<theMoveList.num; i++)
	//{
	//	fprintf(logBook,"Split: %s %i %i\n", moves[i].move, moves[i].quality, moves[i].status);
	//}
	//fclose(logBook);
}
	
	

void DGTEChessGame::getQuickMove(/*[in]*/	GameState gs, 
								 /*[in]*/	LevelType level,
								 /*[in]*/	int maxSize,
				  				 /*[out]*/	int *actualSize,
								 /*[out]*/	DGTEMove *moves, 
								 /*[out]*/	int *gameOver)
{
	ChessBoard theBoard;
	NullChessUI theUI;
	ComputerChessPlayer thePlayer(theUI);
	Move theMove;

	thePlayer.SetOpeningBookEnable(cTRUE);
	theBoard.LoadEPD((char *)gs.gamestate);

	*actualSize = 0;
	*gameOver = MOVEDECISION_CONTINUE;

	if (theBoard.WhiteToMove())
    {
		if(!theBoard.WhiteCanMove())
		{
			// The game is over...
			if (theBoard.WhiteInCheck()) *gameOver = MOVEDECISION_LOOSE;
			else *gameOver = MOVEDECISION_DRAW;
		}
		else *gameOver = MOVEDECISION_CONTINUE;
	}
	else   // Black's turn to move...
	{
		if(!theBoard.BlackCanMove())
		{
            // The game is over...
			if (theBoard.BlackInCheck()) *gameOver = MOVEDECISION_LOOSE;
			else *gameOver = MOVEDECISION_DRAW;
		}
		else *gameOver = MOVEDECISION_CONTINUE;
	}	
	
	if (*gameOver != MOVEDECISION_LOOSE)
	{
		if (theBoard.WhiteToMove() == cTRUE) 
		{
			if(thePlayer.WhiteOpening(theBoard,theMove))
			{
				*actualSize = 1;
				//theBoard.SetWhiteToMove(cTRUE);
				theBoard.MoveToDGTEMove(theMove,moves,level);
				theBoard.SetDGTEGameOverStatus(gameOver);
			}
		}
		else 
		{
			if(thePlayer.BlackOpening(theBoard,theMove))
			{
				*actualSize = 1;
				//theBoard.SetWhiteToMove(cFALSE);
				theBoard.MoveToDGTEMove(theMove,moves,level);
				theBoard.SetDGTEGameOverStatus(gameOver);
			}
		}
	}
}
